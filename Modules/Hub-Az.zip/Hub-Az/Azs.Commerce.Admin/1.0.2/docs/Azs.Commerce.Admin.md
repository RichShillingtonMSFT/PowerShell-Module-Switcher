---
Module Name: Azs.Commerce.Admin
Module Guid: 2011051d-d6e3-4bbf-890d-d8c2750029cf
Download Help Link: https://docs.microsoft.com/en-us/powershell/module/azs.commerce.admin
Help Version: 1.0.0.0
Locale: en-US
---

# Azs.Commerce.Admin Module
## Description
Microsoft AzureStack PowerShell: Commerce Admin cmdlets

## Azs.Commerce.Admin Cmdlets
### [Get-AzsSubscriberUsage](Get-AzsSubscriberUsage.md)
Gets a collection of SubscriberUsageAggregates, which are UsageAggregates from users.

