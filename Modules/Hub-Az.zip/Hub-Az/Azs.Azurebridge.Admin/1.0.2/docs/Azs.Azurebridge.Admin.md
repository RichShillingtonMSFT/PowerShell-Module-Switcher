---
Module Name: Azs.Azurebridge.Admin
Module Guid: 7e8b6f46-2bd4-48fb-b4f9-c7fc5e97247f
Download Help Link: https://docs.microsoft.com/en-us/powershell/module/azs.azurebridge.admin
Help Version: 1.0.0.0
Locale: en-US
---

# Azs.Azurebridge.Admin Module
## Description
Microsoft AzureStack PowerShell: AzureBridge Admin cmdlets

## Azs.Azurebridge.Admin Cmdlets
### [Get-AzsAzureBridgeActivation](Get-AzsAzureBridgeActivation.md)
Returns activation name.

### [Get-AzsAzureBridgeDownloadedProduct](Get-AzsAzureBridgeDownloadedProduct.md)
Get a downloaded product.

### [Get-AzsAzureBridgeProduct](Get-AzsAzureBridgeProduct.md)
Return product name.

### [Invoke-AzsAzureBridgeProductDownload](Invoke-AzsAzureBridgeProductDownload.md)
Downloads a product from azure marketplace.

### [Remove-AzsAzureBridgeDownloadedProduct](Remove-AzsAzureBridgeDownloadedProduct.md)
Delete a downloaded product.

