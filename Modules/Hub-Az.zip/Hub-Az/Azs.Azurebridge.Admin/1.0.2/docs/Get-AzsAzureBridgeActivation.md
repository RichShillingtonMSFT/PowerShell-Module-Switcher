---
external help file:
Module Name: Azs.Azurebridge.Admin
online version: https://docs.microsoft.com/en-us/powershell/module/azs.azurebridge.admin/get-azsazurebridgeactivation
schema: 2.0.0
---

# Get-AzsAzureBridgeActivation

## SYNOPSIS
Returns activation name.

## SYNTAX

### List (Default)
```
Get-AzsAzureBridgeActivation -ResourceGroupName <String> [-SubscriptionId <String[]>]
 [-DefaultProfile <PSObject>] [<CommonParameters>]
```

### Get
```
Get-AzsAzureBridgeActivation -Name <String> -ResourceGroupName <String> [-SubscriptionId <String[]>]
 [-DefaultProfile <PSObject>] [<CommonParameters>]
```

### GetViaIdentity
```
Get-AzsAzureBridgeActivation -InputObject <IBridgeAdminIdentity> [-DefaultProfile <PSObject>]
 [<CommonParameters>]
```

## DESCRIPTION
Returns activation name.

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```powershell
Get-AzsAzureBridgeActivation -ResourceGroupName "azurestack-activation"

AzureRegistrationResourceIdentifier : /subscriptions/5c17413c-1135-479b-a046-847e1ef9fbeb/resourceGroups/AzureStack-s31r21/providers/Microsoft.AzureStack/registrations/AzureStackCIRegistration-s31r2104
DisplayName                         : Azure Stack Activation
Expiration                          : 2022-03-22T02:56:11.024982Z
Id                                  : /subscriptions/4d6112db-c97e-47d6-abd9-97ce61f62f2e/resourceGroups/azurestack-activation/providers/Microsoft.AzureBridge.Admin/activations/default
Location                            : redmond
MarketplaceSyndicationEnabled       : True
Name                                : default
ProvisioningState                   : Succeeded
Tag                                 : Microsoft.Azure.PowerShell.Cmdlets.BridgeAdmin.Models.Api201601.ResourceTags
Type                                : Microsoft.AzureBridge.Admin/activations
UsageReportingEnabled               : True
```

Get a list of Azure Bridge Activations under the resource group "activationRG"

### -------------------------- EXAMPLE 2 --------------------------
```powershell
Get-AzsAzureBridgeActivation -ResourceGroupName "azurestack-activation" -Name "default"

AzureRegistrationResourceIdentifier : /subscriptions/5c17413c-1135-479b-a046-847e1ef9fbeb/resourceGroups/AzureStack-s31r21/providers/Microsoft.AzureStack/registrations/AzureStackCIRegistration-s31r2104
DisplayName                         : Azure Stack Activation
Expiration                          : 2022-03-22T02:56:11.024982Z
Id                                  : /subscriptions/4d6112db-c97e-47d6-abd9-97ce61f62f2e/resourceGroups/azurestack-activation/providers/Microsoft.AzureBridge.Admin/activations/default
Location                            : redmond
MarketplaceSyndicationEnabled       : True
Name                                : default
ProvisioningState                   : Succeeded
Tag                                 : Microsoft.Azure.PowerShell.Cmdlets.BridgeAdmin.Models.Api201601.ResourceTags
Type                                : Microsoft.AzureBridge.Admin/activations
UsageReportingEnabled               : True
```

Get an Azure Bridge Activation by name 'myActivation' situated under 'activationRG'

## PARAMETERS

### -DefaultProfile
The credentials, account, tenant, and subscription used for communication with Azure.

```yaml
Type: System.Management.Automation.PSObject
Parameter Sets: (All)
Aliases: AzureRMContext, AzureCredential

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -InputObject
Identity Parameter
To construct, see NOTES section for INPUTOBJECT properties and create a hash table.

```yaml
Type: Microsoft.Azure.PowerShell.Cmdlets.BridgeAdmin.Models.IBridgeAdminIdentity
Parameter Sets: GetViaIdentity
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: True (ByValue)
Accept wildcard characters: False
```

### -Name
Name of the activation.

```yaml
Type: System.String
Parameter Sets: Get
Aliases: ActivationName

Required: True
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ResourceGroupName
The resource group the resource is located under.

```yaml
Type: System.String
Parameter Sets: Get, List
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -SubscriptionId
Subscription credentials which uniquely identify Microsoft Azure subscription.The subscription ID forms part of the URI for every service call.

```yaml
Type: System.String[]
Parameter Sets: Get, List
Aliases:

Required: False
Position: Named
Default value: (Get-AzContext).Subscription.Id
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### Microsoft.Azure.PowerShell.Cmdlets.BridgeAdmin.Models.IBridgeAdminIdentity

## OUTPUTS

### Microsoft.Azure.PowerShell.Cmdlets.BridgeAdmin.Models.Api201601.IActivationResource

## NOTES

ALIASES

COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.


INPUTOBJECT <IBridgeAdminIdentity>: Identity Parameter
  - `[ActivationName <String>]`: Name of the activation.
  - `[Id <String>]`: Resource identity path
  - `[ProductName <String>]`: Name of the product.
  - `[ResourceGroupName <String>]`: The resource group the resource is located under.
  - `[SubscriptionId <String>]`: Subscription credentials which uniquely identify Microsoft Azure subscription.The subscription ID forms part of the URI for every service call.

## RELATED LINKS

