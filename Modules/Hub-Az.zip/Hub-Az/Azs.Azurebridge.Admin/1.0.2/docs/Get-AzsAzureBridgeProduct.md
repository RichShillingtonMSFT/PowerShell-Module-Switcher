---
external help file:
Module Name: Azs.Azurebridge.Admin
online version: https://docs.microsoft.com/en-us/powershell/module/azs.azurebridge.admin/get-azsazurebridgeproduct
schema: 2.0.0
---

# Get-AzsAzureBridgeProduct

## SYNOPSIS
Return product name.

## SYNTAX

### List (Default)
```
Get-AzsAzureBridgeProduct -ActivationName <String> -ResourceGroupName <String> [-SubscriptionId <String[]>]
 [-DefaultProfile <PSObject>] [<CommonParameters>]
```

### Get
```
Get-AzsAzureBridgeProduct -ActivationName <String> -Name <String> -ResourceGroupName <String>
 [-SubscriptionId <String[]>] [-DefaultProfile <PSObject>] [<CommonParameters>]
```

### GetViaIdentity
```
Get-AzsAzureBridgeProduct -InputObject <IBridgeAdminIdentity> [-DefaultProfile <PSObject>]
 [<CommonParameters>]
```

## DESCRIPTION
Return product name.

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```powershell
Get-AzsAzureBridgeProduct -ActivationName 'default' -ResourceGroupName 'azurestack-activation' | Select -First 5 | ft *

BillingPartNumber CompatibilityDescription CompatibilityIsCompatible CompatibilityIssue CompatibilityMessage Description DisplayName                                    
----------------- ------------------------ ------------------------- ------------------ -------------------- ----------- -----------                                    
                  None                                          True {}                 None                             Acronis Backup for Linux (preview)             
                  None                                          True {}                 None                             CoreOS Linux (Stable)                          
                  None                                          True {}                 None                             Custom Script Extension                        
                  None                                          True {}                 None                             BGInfo                                         
                  None                                          True {}                 None                             Free License: SQL Server 2016 SP2 Express on...

```

Get a list of Products available for download from Azure Marketplace.

### -------------------------- EXAMPLE 2 --------------------------
```powershell
Get-AzsAzureBridgeProduct -ActivationName 'default' -ResourceGroupName 'azurestack-activation' -Name 'microsoft.sqliaasextension-1.3.20590'


BillingPartNumber         : 
CompatibilityDescription  : None
CompatibilityIsCompatible : True
CompatibilityIssue        : {}
CompatibilityMessage      : None
Description               : This extension is required for deploying SQL Server Windows-based VMs on Azure Stack
DisplayName               : SqlIaaSExtension
GalleryItemIdentity       : Microsoft.SqlIaaSExtension.1.3.20590
IconUriHero               : 
IconUriLarge              : https://azstmktprodwcu001.blob.core.windows.net/icons/dbf187f0c64c467f931482ee778e5a04/Large.png
IconUriMedium             : https://azstmktprodwcu001.blob.core.windows.net/icons/dbf187f0c64c467f931482ee778e5a04/Medium.png
IconUriSmall              : https://azstmktprodwcu001.blob.core.windows.net/icons/dbf187f0c64c467f931482ee778e5a04/Small.png
IconUriWide               : https://azstmktprodwcu001.blob.core.windows.net/icons/dbf187f0c64c467f931482ee778e5a04/Wide.png
Id                        : /subscriptions/4d6112db-c97e-47d6-abd9-97ce61f62f2e/resourceGroups/azurestack-activation/providers/Microsoft.AzureBridge.Admin/activations/d
                            efault/products/microsoft.sqliaasextension-1.3.20590
LegalTerm                 : 
Link                      : {}
Location                  : 
Name                      : default/microsoft.sqliaasextension-1.3.20590
Offer                     : 
OfferVersion              : 
PayloadLength             : 7419601
PrivacyPolicy             : 
ProductKind               : virtualMachineExtension
ProductProperties         : 1.3.20590
ProvisioningState         : Succeeded
PublisherDisplayName      : Microsoft
PublisherIdentifier       : Microsoft.SqlServer.Management
Sku                       : 
Tag                       : Microsoft.Azure.PowerShell.Cmdlets.BridgeAdmin.Models.Api201601.ResourceTags
Type                      : Microsoft.AzureBridge.Admin/activations/products
VMExtensionType           : 
```

Get a product info available for download from Azure Marketplace by Name.

## PARAMETERS

### -ActivationName
Name of the activation.

```yaml
Type: System.String
Parameter Sets: Get, List
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -DefaultProfile
The credentials, account, tenant, and subscription used for communication with Azure.

```yaml
Type: System.Management.Automation.PSObject
Parameter Sets: (All)
Aliases: AzureRMContext, AzureCredential

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -InputObject
Identity Parameter
To construct, see NOTES section for INPUTOBJECT properties and create a hash table.

```yaml
Type: Microsoft.Azure.PowerShell.Cmdlets.BridgeAdmin.Models.IBridgeAdminIdentity
Parameter Sets: GetViaIdentity
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: True (ByValue)
Accept wildcard characters: False
```

### -Name
Name of the product.

```yaml
Type: System.String
Parameter Sets: Get
Aliases: ProductName

Required: True
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -ResourceGroupName
The resource group the resource is located under.

```yaml
Type: System.String
Parameter Sets: Get, List
Aliases:

Required: True
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -SubscriptionId
Subscription credentials which uniquely identify Microsoft Azure subscription.The subscription ID forms part of the URI for every service call.

```yaml
Type: System.String[]
Parameter Sets: Get, List
Aliases:

Required: False
Position: Named
Default value: (Get-AzContext).Subscription.Id
Accept pipeline input: False
Accept wildcard characters: False
```

### CommonParameters
This cmdlet supports the common parameters: -Debug, -ErrorAction, -ErrorVariable, -InformationAction, -InformationVariable, -OutVariable, -OutBuffer, -PipelineVariable, -Verbose, -WarningAction, and -WarningVariable. For more information, see [about_CommonParameters](http://go.microsoft.com/fwlink/?LinkID=113216).

## INPUTS

### Microsoft.Azure.PowerShell.Cmdlets.BridgeAdmin.Models.IBridgeAdminIdentity

## OUTPUTS

### Microsoft.Azure.PowerShell.Cmdlets.BridgeAdmin.Models.Api201601.IProductResource

## NOTES

ALIASES

COMPLEX PARAMETER PROPERTIES

To create the parameters described below, construct a hash table containing the appropriate properties. For information on hash tables, run Get-Help about_Hash_Tables.


INPUTOBJECT <IBridgeAdminIdentity>: Identity Parameter
  - `[ActivationName <String>]`: Name of the activation.
  - `[Id <String>]`: Resource identity path
  - `[ProductName <String>]`: Name of the product.
  - `[ResourceGroupName <String>]`: The resource group the resource is located under.
  - `[SubscriptionId <String>]`: Subscription credentials which uniquely identify Microsoft Azure subscription.The subscription ID forms part of the URI for every service call.

## RELATED LINKS

