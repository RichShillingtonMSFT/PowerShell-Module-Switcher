---
Module Name: Azs.Backup.Admin
Module Guid: 9f6ac1f6-5daf-4d6d-a27c-6b30eecf18dc
Download Help Link: https://docs.microsoft.com/en-us/powershell/module/azs.backup.admin
Help Version: 1.0.0.0
Locale: en-US
---

# Azs.Backup.Admin Module
## Description
Microsoft AzureStack PowerShell: Backup Admin cmdlets

## Azs.Backup.Admin Cmdlets
### [Get-AzsBackup](Get-AzsBackup.md)
Returns a backup from a location based on name.

### [Get-AzsBackupConfiguration](Get-AzsBackupConfiguration.md)
Returns a specific backup location based on name.

### [Invoke-AzsPruneBackupLocationExternalStore](Invoke-AzsPruneBackupLocationExternalStore.md)
Prune the external backup store.

### [Restore-AzsBackup](Restore-AzsBackup.md)
Restore a backup.

### [Set-AzsBackupConfiguration](Set-AzsBackupConfiguration.md)
Update a backup location.

### [Start-AzsBackup](Start-AzsBackup.md)
Back up a specific location.

