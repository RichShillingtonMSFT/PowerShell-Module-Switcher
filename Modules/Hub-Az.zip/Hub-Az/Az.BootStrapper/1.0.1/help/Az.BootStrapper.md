---
Module Name: Az.BootStrapper
Module Guid: 30d8a5cf-3ee5-49ce-b9b0-a4d000d65161
Download Help Link: {{Please enter FwLink manually}}
Help Version: {{Please enter version of help manually (X.X.X.X) format}}
Locale: en-US
---

# Az.BootStrapper Module
## Description
{{Manually Enter Description Here}}

## Az.BootStrapper Cmdlets
### [Get-AzModule](Get-AzModule.md)
{{Manually Enter Get-AzModule Description Here}}

### [Get-AzApiProfile](Get-AzApiProfile.md)
{{Manually Enter Get-AzApiProfile Description Here}}

### [Get-ModuleVersion](Get-ModuleVersion.md)
{{Manually Enter Get-ModuleVersion Description Here}}

### [Install-AzProfile](Install-AzProfile.md)
{{Manually Enter Install-AzProfile Description Here}}

### [Remove-AzDefaultProfile](Remove-AzDefaultProfile.md)
{{Manually Enter Remove-AzDefaultProfile Description Here}}

### [Set-AzDefaultProfile](Set-AzDefaultProfile.md)
{{Manually Enter Set-AzDefaultProfile Description Here}}

### [Set-BootstrapRepo](Set-BootstrapRepo.md)
{{Manually Enter Set-BootstrapRepo Description Here}}

### [Uninstall-AzProfile](Uninstall-AzProfile.md)
{{Manually Enter Uninstall-AzProfile Description Here}}

### [Update-AzProfile](Update-AzProfile.md)
{{Manually Enter Update-AzProfile Description Here}}

### [Use-AzProfile](Use-AzProfile.md)
{{Manually Enter Use-AzProfile Description Here}}

