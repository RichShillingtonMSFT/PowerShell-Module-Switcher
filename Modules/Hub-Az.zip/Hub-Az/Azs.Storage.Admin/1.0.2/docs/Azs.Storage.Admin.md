---
Module Name: Azs.Storage.Admin
Module Guid: 2f14a02d-4f51-4a7d-bb87-8d09348ae2fa
Download Help Link: https://docs.microsoft.com/en-us/powershell/module/azs.storage.admin
Help Version: 1.0.0.0
Locale: en-US
---

# Azs.Storage.Admin Module
## Description
Microsoft AzureStack PowerShell: Storage Admin cmdlets

## Azs.Storage.Admin Cmdlets
### [Get-AzsStorageAccount](Get-AzsStorageAccount.md)
Returns the requested storage account.

### [Get-AzsStorageAcquisition](Get-AzsStorageAcquisition.md)
Returns a list of BLOB acquisitions.

### [Get-AzsStorageQuota](Get-AzsStorageQuota.md)
Returns the specified storage quota.

### [Get-AzsStorageSettings](Get-AzsStorageSettings.md)
Returns the storage resource provider settings.

### [New-AzsStorageQuota](New-AzsStorageQuota.md)
Create or update an existing storage quota.

### [Remove-AzsStorageQuota](Remove-AzsStorageQuota.md)
Delete an existing quota

### [Restore-AzsStorageAccount](Restore-AzsStorageAccount.md)
Undelete a deleted storage account with new account name if the a new name is provided.

### [Set-AzsStorageQuota](Set-AzsStorageQuota.md)
Create or update an existing storage quota.

### [Set-AzsStorageSettings](Set-AzsStorageSettings.md)
Update storage resource provider settings.

### [Start-AzsReclaimStorageCapacity](Start-AzsReclaimStorageCapacity.md)
Start reclaim storage capacity on deleted storage objects.

