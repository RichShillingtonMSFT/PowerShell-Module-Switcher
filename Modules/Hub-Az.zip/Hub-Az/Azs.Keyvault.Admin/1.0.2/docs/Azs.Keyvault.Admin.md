---
Module Name: Azs.Keyvault.Admin
Module Guid: bc2394e3-cf81-4cbd-87f9-0aee14a01a0d
Download Help Link: https://docs.microsoft.com/en-us/powershell/module/azs.keyvault.admin
Help Version: 1.0.0.0
Locale: en-US
---

# Azs.Keyvault.Admin Module
## Description
Microsoft AzureStack PowerShell: Keyvault Admin cmdlets

## Azs.Keyvault.Admin Cmdlets
### [Get-AzsKeyvaultQuota](Get-AzsKeyvaultQuota.md)
Get a list of all quota objects for KeyVault at a location.

