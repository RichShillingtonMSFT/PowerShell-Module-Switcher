<#
.SYNOPSIS
    Common Reporting functions across all modules/scenarios
.DESCRIPTION
    Logging, Reporting
.INPUTS
    Inputs (if any)
.OUTPUTS
    Output (if any)
.NOTES
    General notes
#>

if (-not $outputPath) {
    $OutputPath = "$ENV:TEMP\AzsReadinessChecker"
}

if ($AzsReadinessLogFile) {
    Remove-Variable AzsReadinessLogFile -ErrorAction SilentlyContinue
}
if ($AzsReadinessReport) {
    Remove-Variable AzsReadinessReport -ErrorAction SilentlyContinue
}

if ($AzsReadinessReportXml) {
    Remove-Variable AzsReadinessReportXml -ErrorAction SilentlyContinue
}

$Global:AzsReadinessLogFile = Join-Path -Path $OutputPath -ChildPath 'AzsReadinessChecker.log'
$Global:AzsReadinessReport = Join-Path -Path $OutputPath -ChildPath 'AzsReadinessCheckerReport.json'
$Global:AzsReadinessReportXml = Join-Path -Path $OutputPath -ChildPath 'AzsReadinessCheckerReport.xml'

function Get-AzsReadinessProgress {
    <#
    .SYNOPSIS
        Look for existing progress or create new progress.
    .DESCRIPTION
        Finds either the latest progress XML file or creates a new progress XML file
    .EXAMPLE
        PS C:\> <example usage>
        Explanation of what the example does
    .INPUTS
        Clean switch, in case the user wants to start fresh
        Path to search for progress run.
    .OUTPUTS
        PSCustomObject of progress.
    .NOTES
    #>
    param ([switch]$clean, $path = $PSScriptRoot)
    $thisFunction = $MyInvocation.MyCommand.Name
    $latestReport = Get-Item -Path $Global:AzsReadinessReportXml -ErrorAction SilentlyContinue
    if (-not $clean -and $latestReport) {
        $report = Import-CliXML $latestReport.FullName
        Write-AzsReadinessLog -Message ('Found existing report: {0}' -f $report.FilePath) -Type Info -Function $thisFunction
    }
    else {
        $hash = @{
            FilePath              = $Global:AzsReadinessReportXml
            Version               = $MyInvocation.MyCommand.Module.Version.ToString()
            Jobs                  = @{}
            CertificateValidation = @{}
            AzureValidation       = @{
                AzureRegistration  = @{}
                AzureInstallResult = @{}
            }
            GraphValidation       = @{}
            ADFSValidation        = @{}
            NetworkValidation     = @{}
        }
        $report = new-object PSObject -Property $hash
        Write-AzsReadinessLog -Message ('Creating new report {0}' -f $report.FilePath) -Type Info -Function $thisFunction
    }
    $report
}

function Write-AzsReadinessProgress {
    <#
    .SYNOPSIS
        Write report output to JSON
    .DESCRIPTION
        After all processing, take results object and convert to JSON report.
        Any file already existing will be overwritten.
    .EXAMPLE
        Write-AzsReadinessProgress -report $report
        Writes $report to JSON file
    .INPUTS
        [psobject]
    .OUTPUTS
        XML file on disk (path on disk is expected to be embedded in psobject)
    .NOTES
        General notes
    #>
    param ([psobject]$report)
    $thisFunction = $MyInvocation.MyCommand.Name
    try {
        $report | Export-CliXml -Depth 10 -Path $report.FilePath -Force
        Write-AzsReadinessLog -Message ('Azs Readiness progress written: {0}' -f $report.FilePath) -Type Info -Function $thisFunction
    }
    Catch {
        Write-AzsReadinessLog -Message ('Writing XML progress to disk error {0}' -f $_.exception.message) -Type Error -Function $thisFunction
        throw $_.exception
    }
}

function Write-AzsReadinessLog {
    <#
    .SYNOPSIS
        Write verbose logging to disk
    .DESCRIPTION
        Formats and writes verbose logging to disk under scriptroot.  Log type (or severity) is essentially cosmetic
        to the verbose log file, no action should be inferred, such as termination of the script.
    .EXAMPLE
        Write-AzsReadinessLog -Message ('Script messaging include data {0}' -f $data) -Type 'Info|Warning|Error' -Function 'FunctionName'
    .INPUTS
        Message - a string of the body of the log entry
        Type - a cosmetic type or severity for the message, must be info, warning or error
        Function - ideally the name of the function or the script writing the log entry.
    .OUTPUTS
        Appends Log entry to AzsReadinessChecker.log under the script root.
    .NOTES
        General notes
    #>
    param([string]$Message,
        [ValidateSet('Info', 'Warning', 'Error', 'Success')][string]$Type = 'Info',
        [ValidateNotNullOrEmpty()][string]$Function = ((Get-PSCallStack)[0].Command),
        [switch]$toScreen
    )
    $Message = RunMask $Message
    if ($toScreen) {
        if ($PSEdition -eq 'desktop') {
            switch -wildcard ($function) {
                '*-AzsReadiness*' {$foregroundcolor = 'DarkYellow' }
                default {$foregroundcolor = "White" }
            }
            switch ($Type) {
                'Success' {$foregroundcolor = 'Green'}
                'Warning' {$foregroundcolor = 'Yellow'}
                'Error' {$foregroundcolor = 'Red'}
                default {$foregroundcolor = "White" }
            }
            Write-Host $message -foregroundcolor $foregroundcolor
        }
        else {
            Write-Output $message
        }
    }

    $entry = "[{0}] [{1}] [{2}] {3}" -f ([datetime]::now).tostring(), $type, $function, ($Message -replace "`n|`t", "")
    if (-not (Test-Path $AzsReadinessLogFile)) {
        New-Item -Path $AzsReadinessLogFile -Force | Out-Null
    }
    $entry | Out-File -FilePath $AzsReadinessLogFile -Append -Force
}

function Add-AzsReadinessCheckerJob {
    <#
    .SYNOPSIS
        Adds a 'Job' to the progress object.
    .DESCRIPTION
        If a user runs the tool multiple time to check different assets
        e.g. Certificates on one execution and Registration details on the next execution
        Those executions are added to the progress for tracking purposes.
        Execution/Job details include:
            start time,
            parameters,
            parameterset (indicating what is being checked, certificates or Azure Accounts),
            Placeholders for EndTime and Duration (later filled in by Close-AzsReadinessCheckerJob)
    .EXAMPLE
        Add-AzsReadinessCheckerJob -report $report
        Adds execution job to progress object ($report)
    .INPUTS
        Report - psobject - containing all progress to date
    .OUTPUTS
        Report - psobject - updated with execution job log.
    .NOTES
        General notes
    #>
    param ($report)
    $thisFunction = $MyInvocation.MyCommand.Name
    $allJobs = @{}
    $alljobs = $report.Jobs

    # Index for jobs must be a string for json conversion later
    if ($alljobs.Count) {
        $jobCount = ($alljobs.Count++).tostring()
    }
    else {
        $jobCount = '0'
    }

    # Record current job
    $currentJob = @{
        Index             = $jobCount
        StartTime         = (Get-Date -f 'yyyy/MM/dd HH:mm:ss')
        PSBoundParameters = $paramToString
        Operations        = ($PSCmdlet.ParameterSetName -join ', ')
        EndTime           = $null
        Duration          = $null
    }
    Write-AzsReadinessLog -Message ('Adding current job to progress: {0}' -f $currentJob) -Type Info -Function $thisFunction
    # Add current job
    $allJobs += @{"$jobcount" = $currentJob}
    $report.Jobs = $allJobs
    $report
}

function Close-AzsReadinessCheckerJob {
    <#
    .SYNOPSIS
        Writes endtime and duration for jobs
    .DESCRIPTION
        Find latest job entry and update time and calculates duration
        calls function to update xml on disk
        and updates and returns report object
    .EXAMPLE
        Close-AzsReadinessCheckerJob -report $report
    .INPUTS
        Report - psobject - containing all progress to date
    .OUTPUTS
        Report - psobject - updated with finished execution job log.
    .NOTES
        General notes
    #>
    param ($report)
    $thisFunction = $MyInvocation.MyCommand.Name
    try {
        $latestJob = $report.jobs.Keys -match '[0-9]' | ForEach-Object {[int]$_} | Sort-Object -Descending | Select-Object -First 1
        $report.jobs["$latestJob"].EndTime = (Get-Date -f 'yyyy/MM/dd HH:mm:ss')
        $duration = (([dateTime]$report.jobs["$latestJob"].EndTime) - ([dateTime]$report.jobs["$latestJob"].StartTime)).TotalSeconds
        $report.jobs["$latestJob"].Duration = $duration
        Write-AzsReadinessLog -Message ('Updating current job to progress with endTime: {0} and duration {1}' -f $report.jobs["$latestJob"].EndTime, $duration) -Type Info -Function $thisFunction
    }
    Catch {
        Write-AzsReadinessLog -Message ('Updating current job to progress failed with exception: {0}' -f $_.exception) -Type Error -Function $thisFunction
        throw
    }
    Write-AzsReadinessProgress -report $report
    $report
}

function Write-AzsReadinessReport {
    <#
    .SYNOPSIS
        Writes progress to disk in JSON format
    .DESCRIPTION
        Write progress object to disk in JSON format, overwriting as neccessary.
        The resulting blob is intended to be a portable record of what has been checked
        including the results of that check
    .EXAMPLE
        Write-AzsReadinessReport -report $report
    .INPUTS
        Report - psobject - containing all progress to date
    .OUTPUTS
        JSON - file - named AzsReadinessReport.json
    .NOTES
        General notes
    #>
    param ([psobject]$report)
    $thisFunction = $MyInvocation.MyCommand.Name
    try {
        ConvertTo-Json -InputObject $report -depth 10 | Out-file $AzsReadinessReport -force
        Write-AzsReadinessLog -Message ('JSON report written to {0}' -f $AzsReadinessReport) -Type Info -Function $thisFunction
    }
    catch {
        Write-AzsReadinessLog -Message ('Writing JSON report failed:' -f $_.exception.message) -Type Error -Function $thisFunction
        throw $_.exception
    }
}

function Copy-AzsReadinessLogging {
    <#
    .SYNOPSIS
        Copy each individual component log to the main log for AzsReadinessChecker
    .DESCRIPTION
        This function copies an individual component log to the main log for this tool.
        E.g. get CertChecker.log and insert it into AzsReadinessChecker.log,
        so there's a single source of truth.
        It archives individual component logs after copying their content.
        This ensures all timestamps are chronological.
        If no content is found, a placeholder of [missing] is inserted to indicate log copy failure.
    .EXAMPLE
        Copy-AzsReadinessLogging -ComponentLogFile CertChecker
        Gets CertChecker.log and inserts it into AzsReadinessChecker.log
    .INPUTS
        ComponentLogFile - string - valid set of 'CertChecker','AADHelper','CertRequest'
    .OUTPUTS
        File content in AzsReadinessChecker.log
    .NOTES
    #>
    param ([ValidateSet('CertChecker', 'AADHelper')][string]$ComponentLogFile)
    $thisFunction = $MyInvocation.MyCommand.Name
    switch ($ComponentLogFile) {
        'CertChecker' {$logPath = "$PSScriptRoot\CertificateValidation\CertChecker.log" }
        'AADHelper' {$logPath = "$PSScriptRoot\AzureValidation\AADChecker.log" }
    }
    if (Test-Path $logPath) {
        $logContent = Get-Content $logPath -ErrorAction SilentlyContinue
        if (-not $logContent) {
            # if there is no log content make an  indication of this
            $logContent = '[missing]'
        }
        else {
            # if there is a log rename it to archive it, so the next execution would create a fresh.
            Move-Item -Path $logPath -Destination $logPath.replace('.log', '-{0}.log' -f (Get-Date -f yyyyMMddHHmmss)) -Force
        }
        # logs will always be fresh for each execution so indiscriminately copy all content to the main log.
        $logContent | Out-File $AzsReadinessLogFile -Append
        Write-AzsReadinessLog -Message ('Finished copying {0} log from {1}' -f $ComponentLogFile, $logPath, $outfile) -Type Info -Function $thisFunction
    }
    else {
        Write-AzsReadinessLog -Message ('Retrieving {0} log from {1} failed.' -f $ComponentLogFile, $logPath) -Type Error -Function $thisFunction
    }
}

function Get-AzsReadinessReport {
    <#
    .SYNOPSIS
        Read the readiness report and format it to screen
    .DESCRIPTION

    .EXAMPLE
        Get-AzsReadinessReport -reportFile $reportFile
    .INPUTS
        Report - psobject
    .OUTPUTS
        Write-Output
    .NOTES
    #>
    param ($reportJSON, [ValidateSet('Certificate', 'AzureRegistration', 'AzureIdentity', 'Graph', 'ADFS', 'Jobs', 'Network', 'All')]$validations, [switch]$Summary)
    $thisFunction = $MyInvocation.MyCommand.Name
    Write-AzsReadinessLog -Message ('Reading report contents to output to screen') -Type Info -Function $thisFunction
    if ($validations -match 'Certificate|All') {
        foreach ($key in $reportJSON.CertificateValidation.PSObject.Properties.Name) {
            if ($reportJSON.CertificateValidation.$key.Test) {
                if (-not $Summary) {
                    Write-AzsReadinessLog "`n############### $key Certificate Validation Results ###############`n" -Type Info -Function $thisFunction -toScreen
                    if ($reportJSON.CertificateValidation.$key.count -ne $null) {
                        Write-Output $reportJSON.CertificateValidation.$key | Select-Object Test, Result, Path, FailureDetail, ReuseCount | Format-List
                    }
                    else {
                        Write-AzsReadinessLog "Deployment Certificate Validation results not available."  -Type Info -Function $thisFunction -toScreen
                    }
                }
                Write-AzsReadinessLog "`n############### $key Certificate Validation Summary ###############`n" -Type Info -Function $thisFunction -toScreen
                if ($reportJSON.CertificateValidation.$key.FailureDetail -match '[a-z]') {
                    $certificateFailures = $reportJSON.CertificateValidation.$key |
                        ForEach-Object {$PSITEM | where-object FailureDetail -ne $null}
                    foreach ($certificateFailure in $certificateFailures) {
                        Write-AzsReadinessLog ("`n`tCertificate: {0}" -f $certificateFailure.path) -Type Warning -toScreen
                        Write-AzsReadinessLog ("`tIssue(s): {0}" -f ($certificateFailure.failureDetail -join ', ')) -Type Warning -Function Warn -toScreen
                    }
                }
                else {
                    Write-AzsReadinessLog "`tCertificate Validation found no errors or warnings." -Type Info -Function Success -toScreen
                }
            }
            else {
                Write-AzsReadinessLog "`n############### Certificate Validation Summary ###############`n" -Type Info -Function $thisFunction -toScreen
                Write-AzsReadinessLog "Certificate Validation results not available." -Type Info -Function $thisFunction -toScreen
            }
        }
    }
    if ($validations -match 'AzureRegistration|All') {
        if ($reportJSON.AzureValidation.AzureRegistration.Result) {
            if (-not $Summary) {
                Write-AzsReadinessLog "############### Azure Registration Subscription Results ###############" -Type Info -Function $thisFunction -toScreen
                Write-Output $reportJSON.AzureValidation.AzureRegistration.SubscriptionDetail |
                    Select-Object `
                @{Label = "Operation"; Expression = {$_.Test}}, `
                @{Label = "AzureEnvironment"; Expression = {$_.AzureEnvironment}}, `
                @{Label = "Account"; Expression = {$_.credential}}, `
                @{Label = "Account Role"; Expression = {$_.userrole}}, `
                @{Label = "Azure Active Directory Tenant"; Expression = {$_.AADDirectoryTenantName}}, `
                @{Label = "Subscription Id"; Expression = {$_.subscription.subscriptionId}}, `
                @{Label = "displayName"; Expression = {$_.subscription.displayName}}, `
                @{Label = "Location Placement Id"; Expression = {$_.subscription.subscriptionPolicies.locationPlacementId}}, `
                @{Label = "Quota ID"; Expression = {$_.subscription.subscriptionPolicies.quotaId}}, `
                @{Label = "spendingLimit"; Expression = {$_.subscription.subscriptionPolicies.spendingLimit}}, `
                @{Label = "Authorization Source"; Expression = {$_.subscription.authorizationSource}}, `
                @{Label = "Enabled"; Expression = {$_.subscription.state}}, `
                @{Label = "Subscription Type"; Expression = {$_.subscription.subscriptionPolicies.quotaId}}, `
                @{Label = "Error Details"; Expression = {$_.errorDetails}} |
                    Format-List

                Write-AzsReadinessLog "`n############### Azure Registration Validation Overall Results ###############" -Type Info -Function $thisFunction -toScreen

                Write-Output $reportJSON.AzureValidation.AzureRegistration |
                    Select-Object `
                @{Label = "Test"; Expression = {$_.Test}}, `
                @{Label = "Result"; Expression = {$_.result}}, `
                @{Label = "Subscription Id"; Expression = {$_.Assets.SubscriptionId}}, `
                @{Label = "Enabled"; Expression = {$_.Assets.Enabled}}, `
                @{Label = "Subscription Type"; Expression = {$_.Assets.SubscriptionType}}, `
                @{Label = "Error Details"; Expression = {$_.errorDetails}} |
                    Format-List
            }
            Write-AzsReadinessLog "`n############### Registration Validation Summary ###############`n" -Type Info -Function $thisFunction -toScreen
            if ($reportJSON.AzureValidation.AzureRegistration.errorDetails -or $reportJSON.AzureValidation.AzureRegistration.SubscriptionDetail.errorDetails) {
                $reportJSON.AzureValidation.AzureRegistration, $reportJSON.AzureValidation.AzureRegistration.SubscriptionDetail | where-object errorDetails -ne $null | `
                    ForEach-Object {Write-AzsReadinessLog ("`t{0}" -f ($_.errorDetails -join ', ')) -Type Warning -function Warn -toScreen}
            }
            else {
                Write-AzsReadinessLog "`tRegistration Validation found no errors or warnings.`n" -Type Info -Function Success -toScreen
            }
        }
        else {
            Write-AzsReadinessLog "`n############### Registration Validation Summary ###############`n" -Type Info -Function $thisFunction -toScreen
            Write-AzsReadinessLog "Azure Registration Validation results not available." -Type Warning -Function $thisFunction -toScreen
            Write-AzsReadinessLog "Invoke-AzsRegistrationValidation -RegistrationAccount `$registrationCredential -RegistrationSubscriptionID `$subscriptionID -AzureEnvironment AzureCloud -AzureDirectoryTenantName azurestack.contoso.com" -Type Warning -Function $thisFunction
        }
    }
    if ($validations -match 'AzureIdentity|All') {
        if ($reportJSON.AzureValidation.AzureInstallResult.Result) {
            if (-not $Summary) {
                Write-AzsReadinessLog "############### Azure Identity Results ###############" -Type Info -Function $thisFunction -toScreen
                Write-Output $reportJSON.AzureValidation.AzureInstallResult |
                    Select-Object Test, Result, `
                @{Label = "AAD Service Admin"; Expression = {$_.Assets.AADServiceAdmin}}, `
                @{Label = "Azure Environment"; Expression = {$_.Assets.AzureEnvironment}}, `
                @{Label = "Azure Active Directory Tenant"; Expression = {$_.Assets.AADDirectoryTenantName}}, `
                @{Label = "Error Details"; Expression = {$_.errorDetails}} |
                    Format-List
            }
            Write-AzsReadinessLog "`n############### Azure Identity Validation Summary ###############`n" -Type Info -Function $thisFunction -toScreen
            if ($reportJSON.AzureValidation.AzureInstallResult.errorDetails) {
                $reportJSON.AzureValidation.AzureInstallResult | where-object errorDetails -ne $null | `
                    ForEach-Object {Write-AzsReadinessLog ("`t{0}" -f ($_.errorDetails -join ', ')) -Type Warning -Function $thisFunction -toScreen}
            }
            else {
                Write-AzsReadinessLog "`tAzure Identity Validation found no errors or warnings.`n" -Type Info -Function Success -toScreen
            }
        }
        else {
            Write-AzsReadinessLog "`n############### Azure Identity Validation Summary ###############`n" -Type Info -Function $thisFunction -toScreen
            Write-AzsReadinessLog "Azure Identity Validation results not available." -Type Warning -Function $thisFunction -toScreen
            Write-AzsReadinessLog "Invoke-AzsIdentityValidation -AADServiceAdministrator `$serviceAdminCredential - AzureEnvironment AzureCloud -AzureDirectoryTenantName azurestack.contoso.com" -Type Warning -Function $thisFunction
        }
    }
    if ($validations -match 'Graph|All') {
        if ($reportJSON.GraphValidation.Test) {
            if (-not $Summary) {
                Write-AzsReadinessLog "############### Azure Graph Validation Results ###############" -Type Info -Function $thisFunction -toScreen
                Write-Output $reportJSON.GraphValidation |
                    Select-Object Test, Result, @{Label = "Error Details"; Expression = {$_.FailureDetail}} | Format-List
            }
            Write-AzsReadinessLog "`n############### Azure Graph Validation Summary ###############`n" -Type Info -Function $thisFunction -toScreen
            if ($reportJSON.GraphValidation.errorDetails) {
                $reportJSON.GraphValidation | where-object errorDetails -ne $null | `
                    ForEach-Object {Write-AzsReadinessLog ("`t{0}" -f ($_.errorDetails -join ', ')) -Type Warning -Function $thisFunction -toScreen}
            }
            else {
                Write-AzsReadinessLog "`tAzure Stack Graph Validation found no errors or warnings.`n" -Type Info -Function Success -toScreen
            }
        }
        else {
            Write-AzsReadinessLog "`n############### Azure Stack Graph Validation Summary ###############`n" -Type Info -Function $thisFunction -toScreen
            Write-AzsReadinessLog "Azure Stack Graph Validation results not available." -Type Warning -Function $thisFunction -toScreen
            Write-AzsReadinessLog "Invoke-AzureStackGraphValidation -ForestFQDN contoso.com -Credential `$cred" -Type Warning -Function $thisFunction
        }
    }
    if ($validations -match 'ADFS|All') {
        if ($reportJSON.ADFSValidation.Test) {
            if (-not $Summary) {
                Write-AzsReadinessLog "############### Azure Stack ADFS Validation Results ###############" -Type Info -Function $thisFunction -toScreen
                Write-Output $reportJSON.ADFSValidation |
                    Select-Object Test, Result, @{Label = "Error Details"; Expression = {$_.FailureDetail}} | Format-List
            }
            Write-AzsReadinessLog "`n############### Azure Stack ADFS Validation Summary ###############`n" -Type Info -Function $thisFunction -toScreen
            if ($reportJSON.ADFSValidation.errorDetails) {
                $reportJSON.ADFSValidation | where-object errorDetails -ne $null | `
                    ForEach-Object {Write-AzsReadinessLog ("`t{0}" -f ($_.errorDetails -join ', ')) -Type Warning -Function $thisFunction -toScreen}
            }
            else {
                Write-AzsReadinessLog "`tAzure Stack ADFS Validation found no errors or warnings.`n" -Type Info -Function Success -toScreen
            }
        }
        else {
            Write-AzsReadinessLog "`n############### Azure Stack ADFS Validation Summary ###############`n" -Type Info -Function $thisFunction -toScreen
            Write-AzsReadinessLog "Azure Stack ADFS Validation results not available." -Type Warning -Function $thisFunction -toScreen
            Write-AzsReadinessLog "Invoke-AzsADFSValidation -CustomADFSFederationMetadataEndpointUri https://adfs.contoso.com/FederationMetadata/2007-06/FederationMetadata.xml" -Type Warning -Function $thisFunction
        }
    }
    if ($validations -match 'Network|All') {
        if ($reportJSON.NetworkValidation.Test) {
            if (-not $Summary) {
                Write-AzsReadinessLog "############### Azure Stack Network Validation Results ###############" -Type Info -Function $thisFunction -toScreen
                Write-Output $reportJSON.NetworkValidation |
                    Select-Object Test, Result, @{Label = "Error Details"; Expression = {$_.FailureDetail}} | Format-List
            }
            Write-AzsReadinessLog "`n############### Azure Stack Network Validation Summary ###############`n" -Type Info -Function $thisFunction -toScreen
            if ($reportJSON.NetworkValidation.errorDetails) {
                $reportJSON.NetworkValidation | where-object errorDetails -ne $null | `
                    ForEach-Object {Write-AzsReadinessLog ("`t{0}" -f ($_.errorDetails -join ', ')) -Type Warning -Function $thisFunction -toScreen}
            }
            else {
                Write-AzsReadinessLog "`tAzure Stack Network Validation found no errors or warnings.`n" -Type Info -Function Success -toScreen
            }
        }
        else {
            Write-AzsReadinessLog "`n############### Azure Stack Network Validation Summary ###############`n" -Type Info -Function $thisFunction -toScreen
            Write-AzsReadinessLog "Azure Stack Network Validation results not available." -Type Warning -Function $thisFunction -toScreen
            Write-AzsReadinessLog "Invoke-AzsNetworkValidation -DnsServer 192.168.50.1 -TimeServer pool.ntp.org" -Type Warning -Function $thisFunction
        }
    }
    if ($validations -match 'Jobs|All') {
        if (-not $reportjson.jobs) {
            Write-AzsReadinessLog "Job Summary not available. No validations have been run." -Type Warning -Function $thisFunction -toScreen
        }
        else {
            if (-not $Summary) {
                Write-AzsReadinessLog "`n############### AzsReadiness Job Summary ###############`n" -Type Info -Function $thisFunction -toScreen
                $jobs = @{}
                $reportjson.jobs.psobject.properties | ForEach-Object { $jobs[$_.Name] = $_.Value }
                $jobDetail = $jobs.Keys | ForEach-Object {if ($_ -ne 'count') {$jobs[$_]}}
                $jobDetail |
                    Sort-Object Index |
                    Select-Object `
                @{Label = "Index"; Expression = {$_.Index}}, `
                @{Label = "Operations"; Expression = {$_.Operations -join ', '}}, `
                @{Label = "StartTime"; Expression = {$_.StartTime}}, `
                @{Label = "EndTime"; Expression = {$_.EndTime}}, `
                @{Label = "Duration"; Expression = {$_.Duration}}, `
                @{Label = "PSBoundParameters"; Expression = {$_.PSBoundParameters}}  |
                    Format-List
            }
        }
    }
}

function Read-AzsReadinessReport {
    param (
        [Parameter(Mandatory = $true, ParameterSetName = "ReadReport", HelpMessage = "Path for Readiness Report")]
        [ValidateScript( {Test-Path $_ -Include *.json})]
        [string]$ReportPath,

        [Parameter(Mandatory = $false, ParameterSetName = "ReadReport", HelpMessage = "Specify Report Path as 'Certificate', 'AzureRegistration', 'AzureIdentity', 'Graph', 'ADFS', 'Jobs', or 'All'")]
        [ValidateSet('Certificate', 'AzureRegistration', 'AzureIdentity', 'Graph', 'ADFS', 'Jobs', 'Network', 'All')]
        [string[]]$ReportSections = 'All',

        [Parameter(Mandatory = $false, ParameterSetName = "ReadReport", HelpMessage = "Summarize report for issues only")]
        [switch]$Summary = $false
    )
    $thisFunction = $MyInvocation.MyCommand.Name
    Write-AzsReadinessLog -Message ("`nReading {0} Validation(s) from Report {1}" -f ($ReportSections -join ', '), $reportPath) -Type Info -Function $thisFunction -toScreen
    if (Test-Path $reportPath) {
        $reportJSON = Get-Content -path $reportPath -ErrorAction Stop | ConvertFrom-Json
        Get-AzsReadinessReport -reportJSON $reportJSON -validations $ReportSections -Summary:$summary
    }
    else {
        Write-AzsReadinessLog -Message ("Unable to find $reportPath. Please specify a valid report file.") -Type Warning -Function $thisFunction -toScreen
    }
}

function Write-Header {
    param ($invocation, $params)
    $paramToString = ($params.GetEnumerator() | ForEach-Object { "$($_.Key)=$($_.Value)" }) -join ';'
# only print the header to screen if the user called the function directly rather than an add on via packaging.
    # ConvertTo-AzsPfx calls Invoke-AzsCertValidation, only want a header/footer when called by ConvertTo-AzsPfx
    if (-not ('ConvertTo-AzsPFX' -in (Get-PSCallStack).command -and 'Invoke-AzsCertificateValidation' -in (Get-PSCallStack).command )) {
        $cmdLetName = Get-CmdletName (Get-PSCallStack)
        $cmdletVersion = (Get-Command $cmdletName).version.tostring()
        Write-AzsReadinessLog -Message ('{0} v{1} started.' -f `
            $cmdLetName,$cmdletVersion) `
                -Type Info `
                -Function $MyInvocation.MyCommand.Name `
                -toScreen
    }

    Write-AzsReadinessLog -Message ('{0} started version: {1} with parameters: {2}' `
            -f $invocation.MyCommand.Name, (Get-Module Microsoft.AzureStack.ReadinessChecker).Version.ToString(), $paramToString) `
        -Type Info `
        -Function $MyInvocation.MyCommand.Name

    Write-AzsReadinessLog -Message ('OSVersion: {0} PSVersion: {1} PSEdition: {2} Security Protocol: {3}' -f `
            [environment]::OSVersion.Version.tostring(), $PSVersionTable.PSVersion.tostring(), $PSEdition, [Net.ServicePointManager]::SecurityProtocol) `
        -Type Info `
        -Function $MyInvocation.MyCommand.Name
}

function Write-Footer {
    param ($invocation)
    # only print the footer to screen if the user called the function directly rather than an add on via packaging.
    # ConvertTo-AzsPfx calls Invoke-AzsCertValidation, only want a header/footer when called by ConvertTo-AzsPfx
    if (-not ('ConvertTo-AzsPFX' -in (Get-PSCallStack).command -and 'Invoke-AzsCertificateValidation' -in (Get-PSCallStack).command )) {
        Write-AzsReadinessLog -Message ("`nLog location (contains PII): $AzsReadinessLogFile") `
            -Type Info `
            -Function $MyInvocation.MyCommand.Name `
            -toScreen
        if ($invocation.MyCommand.Name -match 'Validation') {
            Write-AzsReadinessLog -Message ("Report location (contains PII): $AzsReadinessReport") `
                -Type Info `
                -Function $MyInvocation.MyCommand.Name `
                -toScreen
        }

        Write-AzsReadinessLog -Message ("{0} Completed" -f (Get-CmdletName (Get-PSCallStack))) `
            -Type Info `
            -Function $MyInvocation.MyCommand.Name `
            -toScreen
    }
}

Function Get-CmdletName {
    param ($callstack)
    try {
        $functionCalled = (Get-PSCallStack)[-2].Command
        if (!$functionCalled) {
            "Certificate Validation"
        }
        $functionCalled
    }
    catch {
        throw "Certificate Validation"
    }
}

function Get-GuidMask {
    [cmdletbinding()]
    [OutputType([string])]
    Param ([Parameter(ValueFromPipeline = $True)][string]$guid)
    Begin {
        $r = [regex]::new("(-([a-fA-F0-9]{4}-){3})")

    }
    Process {
            try {
                return [regex]::replace($guid,$r,"-xxxx-xxxx-xxxx-")
            }
            catch {
                $_.exception
            }
        }
    End{}
}

function Get-PIIMask {
    [cmdletbinding()]
    [OutputType([string])]
    Param ([Parameter(ValueFromPipeline = $True)][string]$in)
    Begin {
        $pii = $($ENV:USERDNSDOMAIN),$($ENV:COMPUTERNAME),$($ENV:USERNAME),$($ENV:USERDOMAIN) | Foreach-Object {
            if ($null -ne $PSITEM) {
                $PSITEM
            }
        }
        $r = $pii -join '|'
    }
    Process {
            try {
                return [regex]::replace($in,$r,"[*redacted*]")
            }
            catch {
                $_.exception
            }
        }
    End{}
}

function RunMask {
    [cmdletbinding()]
    [OutputType([string])]
    Param ([Parameter(ValueFromPipeline = $True)][string]$in)
    Begin {}
    Process {
            try {
                $in | Get-PIIMask | Get-GuidMask
            }
            catch {
                $_.exception
            }
        }
    End{}
}

function Write-AzsResult
{
    param([psobject]$in, $AdditionalhelpURL)
    if ($in.test)
    {
        Write-Host ("`t{0}: " -f $($in.Test)) -noNewLine
        if ($in.Result -eq 'OK')
        {
            Write-Host 'OK' -foregroundcolor Green
        }
        elseif ($in.Result -eq 'WARNING')
        {
            Write-Host 'Warning' -foregroundcolor Yellow
        }
        elseif ($in.Result -eq 'Skipped')
        {
            Write-Host 'Skipped' -foregroundcolor White
        }
        elseif ($in.Result -eq 'SkippedByConfig')
        {
            Write-Host 'SkippedByConfig' -foregroundcolor White
        }
        else
        {
            Write-Host 'Fail' -foregroundcolor Red
        }
    }
    else
    {
        Write-Host "`Details:"
        $in | ForEach-Object {if($_){Write-Host "[-] $_" -foregroundcolor Yellow}}
        if ($AdditionalhelpURL){
            Write-Host ("Additional help URL {0}" -f "$additionalHelpUrl")
        }
    }
}
# SIG # Begin signature block
# MIIjkgYJKoZIhvcNAQcCoIIjgzCCI38CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDx+mdS1l69Bu+R
# 7qRmGnBE4sat6gxbvhXwKRuCPffF86CCDYEwggX/MIID56ADAgECAhMzAAACUosz
# qviV8znbAAAAAAJSMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjEwOTAyMTgzMjU5WhcNMjIwOTAxMTgzMjU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDQ5M+Ps/X7BNuv5B/0I6uoDwj0NJOo1KrVQqO7ggRXccklyTrWL4xMShjIou2I
# sbYnF67wXzVAq5Om4oe+LfzSDOzjcb6ms00gBo0OQaqwQ1BijyJ7NvDf80I1fW9O
# L76Kt0Wpc2zrGhzcHdb7upPrvxvSNNUvxK3sgw7YTt31410vpEp8yfBEl/hd8ZzA
# v47DCgJ5j1zm295s1RVZHNp6MoiQFVOECm4AwK2l28i+YER1JO4IplTH44uvzX9o
# RnJHaMvWzZEpozPy4jNO2DDqbcNs4zh7AWMhE1PWFVA+CHI/En5nASvCvLmuR/t8
# q4bc8XR8QIZJQSp+2U6m2ldNAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUNZJaEUGL2Guwt7ZOAu4efEYXedEw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDY3NTk3MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAFkk3
# uSxkTEBh1NtAl7BivIEsAWdgX1qZ+EdZMYbQKasY6IhSLXRMxF1B3OKdR9K/kccp
# kvNcGl8D7YyYS4mhCUMBR+VLrg3f8PUj38A9V5aiY2/Jok7WZFOAmjPRNNGnyeg7
# l0lTiThFqE+2aOs6+heegqAdelGgNJKRHLWRuhGKuLIw5lkgx9Ky+QvZrn/Ddi8u
# TIgWKp+MGG8xY6PBvvjgt9jQShlnPrZ3UY8Bvwy6rynhXBaV0V0TTL0gEx7eh/K1
# o8Miaru6s/7FyqOLeUS4vTHh9TgBL5DtxCYurXbSBVtL1Fj44+Od/6cmC9mmvrti
# yG709Y3Rd3YdJj2f3GJq7Y7KdWq0QYhatKhBeg4fxjhg0yut2g6aM1mxjNPrE48z
# 6HWCNGu9gMK5ZudldRw4a45Z06Aoktof0CqOyTErvq0YjoE4Xpa0+87T/PVUXNqf
# 7Y+qSU7+9LtLQuMYR4w3cSPjuNusvLf9gBnch5RqM7kaDtYWDgLyB42EfsxeMqwK
# WwA+TVi0HrWRqfSx2olbE56hJcEkMjOSKz3sRuupFCX3UroyYf52L+2iVTrda8XW
# esPG62Mnn3T8AuLfzeJFuAbfOSERx7IFZO92UPoXE1uEjL5skl1yTZB3MubgOA4F
# 8KoRNhviFAEST+nG8c8uIsbZeb08SeYQMqjVEmkwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVZzCCFWMCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAlKLM6r4lfM52wAAAAACUjAN
# BglghkgBZQMEAgEFAKCBrjAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg+5r51gGT
# mRDWAp2OouvhATEbTv1DQqh8UBLgy+5TABMwQgYKKwYBBAGCNwIBDDE0MDKgFIAS
# AE0AaQBjAHIAbwBzAG8AZgB0oRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQA3us0WZ3rMUQkYJlmECPRS/KTiA14RuxeEyvGL0eiz
# rb9BnDg9SX3cMV78LtSnCwsfktoCxcv1VjaEZXDnfUXspJzvU6Wm9tPlJ5BpFv8r
# AfTe1KtCN7qNFDgKWsDRMj7fR/+yR5y8YLL+yBljOvoZwop0bpfoEEOuJyPUG7/J
# VgUru8VTrvaOJUGVF8K4NlEi1rRDobyckx5XjWvLHU67qE0chnRLKOJMG81XNSem
# n8Fz3gjQLzniJHU4rh6T9p8AYbknpuT6dkTjP7WYBkYM1fYvfwYGM4pWFaNaGSwM
# dc+DxLvkz8bhiJ50BlrIyJtEjQcnBDiO7dv4yU5YSWQBoYIS8TCCEu0GCisGAQQB
# gjcDAwExghLdMIIS2QYJKoZIhvcNAQcCoIISyjCCEsYCAQMxDzANBglghkgBZQME
# AgEFADCCAVUGCyqGSIb3DQEJEAEEoIIBRASCAUAwggE8AgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEIHgVtgCOV82c4weyIvhzfLNFgyDYu0t+RLZTzltY
# YwMkAgZhvMDcJ70YEzIwMjIwMTA1MTIxMTQwLjQwM1owBIACAfSggdSkgdEwgc4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1p
# Y3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMg
# VFNTIEVTTjpDNEJELUUzN0YtNUZGQzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgU2VydmljZaCCDkQwggT1MIID3aADAgECAhMzAAABV0QHYtxv6L4qAAAA
# AAFXMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MB4XDTIxMDExNDE5MDIxM1oXDTIyMDQxMTE5MDIxM1owgc4xCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVy
# YXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpDNEJE
# LUUzN0YtNUZGQzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vydmlj
# ZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAN5tA6dUZvnnwL9qQtXc
# wPANhB4ez+5CQrePp/Z8TH4NBr5vAfGMo0lV/lidBatKTgHErOuKH11xVAfBehHJ
# vH9T/OhOc83CJs9bzDhrld0Jdy3eJyC0yBdxVeucS+2a2ZBd50wBg/5/2YjQ2ylf
# D0dxKK6tQLxdODTuadQMbda05lPGnWGwZ3niSgIKVRgqqCVlhHzwNtRh1AH+Zxbf
# Se7t8z3oEKAdTAy7SsP8ykht3srjdh0BykPFdpaAgqwWCJJJmGk0gArSvHC8+vXt
# Go3MJhWQRe5JtzdD5kdaKH9uc9gnShsXyDEhGZjx3+b8cuqEO8bHv0WPX9MREfrf
# xvkCAwEAAaOCARswggEXMB0GA1UdDgQWBBRdMXu76DghnU/kPTMKdFkR9oCp2TAf
# BgNVHSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBH
# hkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNU
# aW1TdGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUF
# BzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0
# YVBDQV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsG
# AQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IBAQAld3kAgG6XWiZyvdibLRmWr7yb6RSy
# cjVDg8tcCitS01sTVp4T8Ad2QeYfJWfK6DMEk7QRBfKgdN7oE8dXtmQVL+JcxLj0
# pUuy4NB5RchcteD5dRnTfKlRi8vgKUaxDcoFIzNEUz1EHpopeagDb4/uI9Uj5tIu
# wlik/qrv/sHAw7kM4gELLNOgdev9Z/7xo1JIwfe0eoQM3wxcCFLuf8S9OncttaFA
# WHtEER8IvgRAgLJ/WnluFz68+hrDfRyX/qqWSPIE0voE6qFx1z8UvLwKpm65QNyN
# DRMp/VmCpqRZrxB1o0RY7P+n4jSNGvbk2bR70kKt/dogFFRBHVVuUxf+MIIGcTCC
# BFmgAwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJv
# b3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1WhcN
# MjUwNzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCASIw
# DQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkdDbx3EYo6IOz8E5f1+n9plGt0
# VBDVpQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMnBDEfQRsalR3OCROOfGEwWbEw
# RA/xYIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeGMoQe
# dGFnkV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8RsEnHSRnEnIaIYqvS2SJUGKx
# Xf13Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v0Ev9buWayrGo8noqCjHw2k4G
# kbaICDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN/LzAyURdXhacAQVPIk0CAwEA
# AaOCAeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ80N7
# fEYbxTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMC
# AYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvX
# zpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20v
# cGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYI
# KwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDCBoAYDVR0g
# AQH/BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYIKwYB
# BQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0AGUA
# bQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAAfmiFEN4sbgmD+BcQM9naOh
# IW+z66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4vceoniXj+bzta1RXCCtRgkQS
# +7lTjMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzymXlK
# kVIArzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8z+0DpZaPWSm8tv0E4XCfMkon
# /VWvL/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVKC5Em4jnsGUpxY517IW3DnKOi
# PPp/fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs9/S/
# fmNZJQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF0M2n0O99g/DhO3EJ3110mCII
# YdqwUB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+YWtvd6mBy6cJrDm77MbL2IK0
# cs0d9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt6o3gMy4SKfXAL1QnIffIrE7a
# KLixqduWsqdCosnPGUFN4Ib5KpqjEWYw07t0MkvfY3v1mYovG8chr1m1rtxEPJdQ
# cdeh0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc1bN+
# NR4Iuto229Nfj950iEkSoYIC0jCCAjsCAQEwgfyhgdSkgdEwgc4xCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBP
# cGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpD
# NEJELUUzN0YtNUZGQzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZaIjCgEBMAcGBSsOAwIaAxUAES34SWJ7DfbSG/gbIQwTrzgZ8PKggYMwgYCk
# fjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIF
# AOV/osUwIhgPMjAyMjAxMDUwODUzMjVaGA8yMDIyMDEwNjA4NTMyNVowdzA9Bgor
# BgEEAYRZCgQBMS8wLTAKAgUA5X+ixQIBADAKAgEAAgIhxwIB/zAHAgEAAgIRHTAK
# AgUA5YD0RQIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIB
# AAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAKa6IF25ZYDxtqzh
# 9zq9T2KjLqlqpeIHmpIwO6CUQGWgVcvuK7nlU8sdTLhGfKTBjzU2O0OAui3ryKvG
# y7vcZz2DuvDAGFObR0tBKPvZoAtaHCBtyZJFDyn6JBdvelB7kkpq7NkZ7bmIzjpq
# hVlzR7wWYgZaBRr4pDRfLh8gWCGZMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTACEzMAAAFXRAdi3G/ovioAAAAAAVcwDQYJYIZIAWUD
# BAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0B
# CQQxIgQg7BmL2wwnD98w5JkEFc8vcmZbFvArBOqhWWGlHCzPdsQwgfoGCyqGSIb3
# DQEJEAIvMYHqMIHnMIHkMIG9BCAsWo0NQ6vzuuupUsZEMSJ4UsRjtQw2dFxZWkHt
# qRygEzCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB
# V0QHYtxv6L4qAAAAAAFXMCIEIIYK8lGN1XppTJl07nGdYw1qvKywm8+qsww8jbBz
# K23uMA0GCSqGSIb3DQEBCwUABIIBAICog+qd4f8baWgutv38jhwlAvh2DaFLJFtt
# N8Rl+1aloNgxxWW4tzPQVibwiPGazayj4snZX1/soh0f21xyJudZE/ylXyTn+IRY
# dXuXj/h45awxY/Bx2OnmnuuJpa7/2EmnRE1UCa3LmkMF+UYGdlsYd0wXBcimek+9
# t/+7D+LV+bw+BB4R/CiuJxBeGfZmOYcOpcEEiLY/SWksMWKH2bG5CO9jhdVA6kpU
# XNevl4dk+4jL9uqlAO1lSmthfV3MX31Un08cU+qwHTwQHyI4dqEFflUCCKJQi9ks
# 5TIsgTTMXjt7rkuiACqnTLqvMtx7xgTk/KbL8kqUukfT/V/WmZg=
# SIG # End signature block
