#!/usr/bin/python3
#
#
from logging import disable, handlers, info, raiseExceptions, shutdown
import logging
from glob import glob
from posix import ST_SYNCHRONOUS
from copy import deepcopy
import time
import os
import sys
import requests
import json
from functools import wraps
import re
import urllib.parse
import subprocess
from socket import AF_INET, SOCK_DGRAM
import socket
import struct


try:
    cloudId = sys.argv[1]
    timestr = time.strftime("%Y%m%d-%H%M%S")
    rootPath = './results/{}'.format(cloudId)
    logPath = rootPath + '/logs/'
    logFile = logPath + 'nrc.log'
    traceRoutePath = rootPath + '/traceroute'
    if os.path.isdir(traceRoutePath):
        os.rename(traceRoutePath, traceRoutePath + '.{}'.format(timestr))
    os.makedirs(logPath, exist_ok=True)
    os.makedirs(traceRoutePath, exist_ok=True)
    logs = glob(logPath+'*')
    numberOfLogs = len(logs)
    if numberOfLogs > 0 and os.path.isfile(logFile):
        os.rename(logFile, logFile + '.{}'.format(str(numberOfLogs)))
    appLogger = logging.getLogger('appLogger')
    appLogger.setLevel(logging.INFO)
    appLogFormat = logging.Formatter(
        '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]')
    handler = logging.handlers.RotatingFileHandler(
        logFile, maxBytes=104857600, backupCount=5)
    handler.setFormatter(appLogFormat)
    appLogger.addHandler(handler)
except Exception as e:
    os.makedirs('results', exist_ok=True)
    returnData = {}
    returnData['success'] = False
    returnData['message'] = str(e)
    with open(rootPath + '/results.json', 'w') as outfile:
        json.dump(returnData, outfile)
    raise


def retry(exceptions, total_tries=4, initial_wait=0.5, backoff_factor=2):
    """
    calling the decorated function applying an exponential backoff.
    Args:
        exceptions: Exeption(s) that trigger a retry, can be a tuple
        total_tries: Total tries
        initial_wait: Time to first retry
        backoff_factor: Backoff multiplier (e.g. value of 2 will double the delay each retry).
    """
    def retry_decorator(f):
        @wraps(f)
        def func_with_retries(*args, **kwargs):
            totalSleep = 0
            _tries, _delay = total_tries + 1, initial_wait
            while _tries > 1:
                try:
                    appLogger.info(f'{total_tries + 2 - _tries}. try:')
                    return f(*args, **kwargs)
                except exceptions as e:
                    _tries -= 1
                    print_args = args if args else 'no args'
                    if _tries == 1:
                        msg = str(f'Function: {f.__name__}\n'
                                  f'Failed after {total_tries} tries.')
                        appLogger.warning(msg)
                        raise
                    msg = str(f'Function: {f.__name__}\n'
                              f'Exception: {e}\n'
                              f'Retrying in {_delay} seconds!, args: {print_args}, kwargs: {kwargs}\n')
                    appLogger.warning(msg)
                    time.sleep(_delay)
                    totalSleep = totalSleep + _delay / 60
                    appLogger.info(
                        'Total Sleep Time(minutes) = {}'.format(str(totalSleep)))
                    _delay *= backoff_factor
        return func_with_retries
    return retry_decorator


def sendCommand(command):
    # Example: command="sudo vtysh -c 'show ip bgp neighbors json'"
    try:
        appLogger.info("Command to send: {}".format(command))
        proc = subprocess.Popen(command,
                                stdout=subprocess.PIPE,
                                shell=True,
                                stderr=subprocess.STDOUT)
        stdout = proc.communicate()[0]
        proc.wait()
        return stdout, proc.returncode
    except OSError as e:
        raise OSError("Failed to issue: {}".format(command))


def session_for_src_addr(addr: str) -> requests.Session:
    """
    Create `Session` which will bind to the specified local address
    rather than auto-selecting it.
    # usage example:
    s = session_for_src_addr('100.64.246.10')
    s.get('https://login.microsoftonline.com')
    """
    session = requests.Session()
    for prefix in ('http://', 'https://'):
        session.get_adapter(prefix).init_poolmanager(
            # those are default values from HTTPAdapter's constructor
            connections=requests.adapters.DEFAULT_POOLSIZE,
            maxsize=requests.adapters.DEFAULT_POOLSIZE,
            # This should be a tuple of (address, port). Port 0 means auto-selection.
            source_address=(addr, 0),
        )
    return session


def traceRoute(sourceIP, dest):
    appLogger.info(
        'Starting traceroute using src:{} to dst:{}'.format(sourceIP, dest))
    command = 'sudo traceroute -m 15 -I -s {} {}'.format(sourceIP, dest)
    stdout, returnCode = sendCommand(command)
    result = (stdout.decode("utf-8")).rstrip('\n')
    appLogger.info('Traceroute completed')
    appLogger.info(result)
    return result


def getNTPTime(host):
    port = 123
    buf = 1024
    address = (host, port)
    msg = '\x1b' + 47 * '\0'

    # reference time (in seconds since 1900-01-01 00:00:00)
    TIME1970 = 2208988800  # 1970-01-01 00:00:00

    # connect to server
    client = socket.socket(AF_INET, SOCK_DGRAM)
    client.settimeout(20)
    client.sendto(msg.encode('utf-8'), address)
    msg, address = client.recvfrom(buf)

    t = struct.unpack("!12I", msg)[10]
    t -= TIME1970
    return time.ctime(t).replace("  ", " ")


def main():
    try:
        appLogger.info('#######################################')
        appLogger.info("Starting NRC Network Validation.")
        returnData = {}
        returnData['success'] = True
        inputFile = '{}-TestData.json'.format(cloudId)
        appLogger.info('Importing {}'.format(inputFile))
        testText = open(inputFile).read()
        testData = json.loads(testText)

        for network in testData:
            if returnData['success'] == False:
                raise Exception(
                    'Testing will stop because the previous network does not have the proper connectivity.')

            appLogger.info('Testing Network: {}'.format(network))

            # iterate through testData Tests per each bgp neighbor
            sourceIP = testData[network]['sourceIP']['ipaddress']
            for device, neighbor in testData[network]['neighbors'].items():
                continueTesting = {device: True}
                if network not in returnData:
                    appLogger.info(
                        'Setting ReturnData Network = {}'.format(network))
                    returnData[network] = {}
                if 'success' not in returnData[network]:
                    returnData[network]['success'] = True
                returnData[network][device] = {}
                if 'success' not in returnData[network][device]:
                    returnData[network][device]['success'] = True
                neighborIP = neighbor['ipaddress']
                appLogger.info(
                    "Testing neighbor {} {}".format(device, neighborIP))

                # Settings applicable to specific network tests
                if network == 'BmcNetwork':
                    appLogger.info(
                        'Apply settings for testing Network: {}'.format(network))

                    sendCommand("config bgp shutdown all")
                    sendCommand(
                        'config route add prefix 0.0.0.0/0 nexthop {}'.format(neighborIP))

                else:
                    appLogger.info(
                        'Apply settings for testing Network: {}'.format(network))

                    # Make sure no default route is set as this will cause traffic to be source from the incorrect IP address.
                    sendCommand('config route del prefix 0.0.0.0/0')

                    # if gateway is defined, set a static route to bgp neighbors address
                    if 'gateway' in testData[network] and testData[network]['gateway'] != False:
                        gateway = testData[network]['gateway']
                        sendCommand(
                            'config route add prefix {}/32 nexthop {}'.format(neighborIP, gateway))
                        staticRoutesJson, returnCode = sendCommand(
                            "vtysh -c 'show ip route static json'")
                        staticRoutesJson = json.loads(staticRoutesJson)
                        if '{}/32'.format(neighborIP) not in staticRoutesJson:
                            staticRoutesStr, returnCode = sendCommand(
                                "vtysh -c 'show ip route static")
                            result = (staticRoutesStr.decode(
                                "utf-8")).rstrip('\n')
                            appLogger.warning('Static Routes as follows:')
                            appLogger.warning(result)
                            raise Exception(
                                'Static Route did not get set properly.  See log for more details')

                    # Do not redistribute static routes
                    sendCommand(
                        "vtysh -c 'configure terminal' -c 'router bgp' -c 'address-family ipv4 unicast' -c 'no redistribute static'")

                    # Set ebgp multihop
                    sendCommand(
                        "vtysh -c 'configure terminal' -c 'router bgp' -c 'neighbor {} ebgp-multihop 3'".format(neighborIP))
                    runnConfigBytes, returnCode = sendCommand(
                        "vtysh -c 'show run'")
                    runconfigStr = (
                        runnConfigBytes.decode("utf-8")).rstrip('\n')
                    appLogger.info(runconfigStr)

                    # Set up bgp neighbors to be in the proper state.
                    # startup the neighbor that we are testing
                    activeNeighbor = BgpNeighbor(device, neighborIP)
                    appLogger.info(
                        "Starting up bgp neighbor {} {}".format(device, neighborIP))
                    activeNeighbor.configureBgpNeighbor(state="startup")
                    allNeighbors = activeNeighbor.getBgpNeighbors()
                    for naddress, nvalue in allNeighbors.items():
                        if naddress != neighborIP:
                            appLogger.info("Disabling bgp neighbor {} {}".format(
                                nvalue['nbrDesc'], naddress))
                            disableNeighbor = BgpNeighbor(
                                nvalue['nbrDesc'], naddress)
                            disableNeighbor.configureBgpNeighbor(
                                state="shutdown")
                    try:

                        # neighbor check to make sure the active one is up, and the other is admin down.
                        appLogger.info("Checking bgp neighbor {} {} to ensure proper peering".format(
                            device, neighborIP))
                        activeNeighbor.checkBgpNeighbor("enabled")

                        # check how long neighbor has been up.  Make sure its at least 30 seconds.
                        allNeighbors = activeNeighbor.getBgpNeighbors()

                        # convert milliseconds to seconds by /1000
                        uptime = allNeighbors[neighborIP]['bgpTimerUpMsec'] / 1000
                        if uptime < 30:
                            appLogger.info(
                                "Sleeping for additional {} seconds to allow BGP to become stable.".format(30 - uptime))
                            time.sleep(30 - uptime)
                        else:
                            appLogger.info(
                                "BGP has been established for {} seconds.".format(uptime))
                    except Exception as e:
                        appLogger.warning(
                            "Exception Caught: BGP is not in the established state. Exception: {}".format(e))
                        returnData[network][device] = {
                            'success': False,
                            'message': str(e)
                        }
                        raise(e)

                # Test Execution
                for key, value in sorted(testData[network]['tests'].items()):
                    if continueTesting[device]:
                        appLogger.info("Continue Testing = {}".format(
                            bool(continueTesting[device])))
                        tName = str(value['testName'])
                        appLogger.info("Testing {}".format(tName))
                        returnData[network][device][tName] = {}
                        try:
                            copyOfEndpoints = deepcopy(value['endPoints'])
                            appLogger.info(
                                'endpoints={}'.format(value['endPoints']))
                            appLogger.info(
                                'copy endpoints={}'.format(copyOfEndpoints))
                            test = TestCalls(
                                value['testName'], value['destination'], copyOfEndpoints, sourceIP, device)
                            result = getattr(test, tName)()
                            appLogger.info(result)
                            returnData[network][device][tName] = result
                        except Exception as e:
                            appLogger.warning(e)
                            if len(e.args) > 1:
                                message, cont, failures = e.args
                                appLogger.info(message)
                                appLogger.info('ContinueTesting is: {}'.format(
                                    bool(cont['continue'])))
                                uniqueFailures = list(set(failures))
                                appLogger.info(
                                    'Failures are: {}'.format(uniqueFailures))
                                continueTesting[device] = cont['continue']
                                try:
                                    for fdest in uniqueFailures:
                                        troute = traceRoute(
                                            sourceIP=sourceIP, dest=fdest)
                                        with open(traceRoutePath + '/{}_traceroute_{}_{}.txt'.format(device, tName, fdest), 'w') as outfile:
                                            outfile.write(troute + '\n')
                                except Exception as nested:
                                    appLogger.warning(nested)
                            else:
                                message = str(e)
                            returnData[network][device][tName] = {
                                'success': False,
                                'message': message
                            }
                            returnData['success'] = False
                            returnData[network]['success'] = False
                            returnData[network][device]['success'] = False

    except Exception as e:
        appLogger.warning("Exception caught.")
        os.makedirs('results', exist_ok=True)
        returnData['success'] = False
        returnData['message'] = "Check the log file for further debugging. Exception: {}".format(
            str(e))
        appLogger.exception(e)

    finally:
        try:
            appLogger.info(activeNeighbor.startAllBgpNeighbors())
        except Exception as e:
            appLogger.warning('BGP Neighbors not started.')
        os.makedirs('results', exist_ok=True)
        appLogger.info(
            "All test completed writing results to {}/results.json".format(rootPath))
        if 'success' in returnData and not returnData['success']:
            success = False
        else:
            success = True

        if success:
            returnData['success'] = True
            returnData['message'] = "Network is ready for deployment."
        else:
            returnData['success'] = False
            if 'message' not in returnData:
                returnData['message'] = "Network is not ready for deployment. See log file for details."
        with open(rootPath + '/results.json', 'w') as outfile:
            json.dump(returnData, outfile)
        return returnData


class TestCalls:
    def __init__(self, testName, destination, endpoints, sourceIP, device):
        self.testName = testName
        self.destination = destination
        self.endpoints = endpoints
        self.sourceIP = sourceIP
        self.device = device

    # Total Sleep time approx 24 seconds
    @retry(Exception, initial_wait=5, total_tries=3, backoff_factor=1.5)
    def ntpServer(self):
        returnData = {}
        returnData['message'] = []
        success = []
        failures = []
        for dest in self.destination:
            try:
                appLogger.info("Testing NTP Server: {}".format(dest))
                timeResult = getNTPTime(host='{}'.format(dest))
                returnData['message'].append(
                    "PASS: ({}) NTP Server {} using Source IP {} got the time: {}".format(self.device, dest, self.sourceIP, timeResult))
                success.append(True)
            except Exception as e:
                appLogger.warning(e)
                returnData['message'].append(
                    "FAIL: ({}) NTP Server {} using Source IP {} is not working. Error: {}".format(self.device, dest, self.sourceIP, str(e)))
                success.append(False)
                failures.append(dest)
        if False not in success:
            returnData['success'] = True
        else:
            raise Exception(returnData['message'], {
                            'continue': True}, failures)
        return returnData

    # Total Sleep time approx 24 seconds
    @retry(Exception, initial_wait=5, total_tries=3, backoff_factor=1.5)
    def dnsServer(self):
        returnData = {}
        returnData['message'] = []
        success = []
        failures = []
        try:
            for dest in self.destination:

                # Edit resolve.conf to have just the DNS server being tested.
                with open('/etc/resolv.conf', 'w') as resolvconf:
                    resolvconf.write('nameserver {}'.format(dest))
                for endpoint in self.endpoints:
                    appLogger.info(
                        "Testing DNS Server: {} resolving: {}".format(dest, endpoint))
                    url = urllib.parse.urlparse(endpoint)
                    domain = url.netloc
                    try:
                        lookup = socket.gethostbyname_ex(domain)
                        msg = "PASS: ({}) DNS Server {} using Source IP {} resolved domain {}".format(
                            self.device, dest, self.sourceIP, domain)
                        appLogger.info(msg)
                        appLogger.info(lookup)
                        success.append(True)
                        returnData['message'].append(msg)
                    except Exception as e:
                        msg = "FAIL: ({}) DNS Server {} using Source IP {} FAILED to resolve domain {}. Error: {}".format(
                            self.device, dest, self.sourceIP, domain, str(e))
                        appLogger.warning(msg)
                        failures.append(dest)
                        success.append(False)
                        returnData['message'].append(msg)
                        raise Exception(msg)
        except Exception as e:
            appLogger.warning(e)
            if len(failures) == 0:
                returnData['message'].append(
                    "FAIL: ({}) DNS Server {} using Source IP {} Error: {}".format(self.device, dest, self.sourceIP, str(e)))
            success.append(False)
            failures.append(dest)
        if False not in success:
            returnData['success'] = True
            with open('/etc/resolv.conf', 'w') as resolvconf:
                for dest in self.destination:
                    resolvconf.write('nameserver {}\n'.format(dest))
        else:
            appLogger.warning(returnData['message'])
            raise Exception(returnData['message'], {
                            'continue': False}, failures)
        return returnData

    # Total Sleep time approx 24 seconds
    @retry(Exception, initial_wait=5, total_tries=3, backoff_factor=1.5)
    def webRequests(self):
        returnData = {}
        returnData['message'] = []
        success = []
        failures = []
        appLogger.info(self.endpoints)

        try:

            # Custom Cloud Support requires a webrequest to ARM to get the other endpoints.
            if len(self.endpoints) == 1:
                armEndpoint = self.endpoints[0]
                appLogger.info("Testing Webrequest to: {}  Source: {}".format(
                    armEndpoint, self.sourceIP))
                url = urllib.parse.urlparse(armEndpoint)
                domain = url.netloc
                webrequest = session_for_src_addr(self.sourceIP)
                fullurl = armEndpoint.rstrip(
                    '/') + '/metadata/endpoints?api-version=2015-01-01'
                r = webrequest.get(fullurl, allow_redirects=False, timeout=10)
                appLogger.info("HTTP Status Code: {}".format(r.status_code))
                if r.status_code == 200:
                    appLogger.info("Response Text: {}".format(r.text))
                    success.append(True)
                    returnData['message'].append(
                        "PASS: ({}) Successfull webrequest using Source IP {} to: {}".format(self.device, self.sourceIP, armEndpoint))
                    rjson = r.json()
                    self.endpoints.remove(armEndpoint)
                    self.endpoints.append(rjson['graphEndpoint'])
                    self.endpoints.append(
                        rjson['authentication']['loginEndpoint'])
                    self.endpoints.append(
                        rjson['authentication']['audiences'][0])
                else:
                    msg = "FAIL: ({}) Webrequest using Source IP {} received status code for {} should be 200. StatusCode={}".format(
                        self.device, self.sourceIP, armEndpoint, r.status_code)
                    appLogger.warning(msg)
                    returnData['message'].append(msg)
                    success.append(False)
                    appLogger.info('failure: {}'.format(domain))
                    failures.append(domain)
        except Exception as e:
            success.append(False)
            appLogger.info('failure: {}'.format(domain))
            failures.append(domain)
            returnData['message'].append(
                "FAIL: ({}) Unsuccessfull webrequest using Source IP {} to: {}: Exception: {}".format(self.device, self.sourceIP, armEndpoint, str(e)))
        if False not in success:
            pass
        else:
            # Raising the exception will cause the function to retry based off the @retry decorator
            appLogger.warning(returnData['message'])
            raise Exception(returnData['message'], {
                            'continue': False}, failures)

        # loop through endpoints
        for endpoint in self.endpoints:
            try:
                appLogger.info("Testing Webrequest to: {}  Source: {}".format(
                    endpoint, self.sourceIP))
                url = urllib.parse.urlparse(endpoint)
                domain = url.netloc
                webrequest = session_for_src_addr(self.sourceIP)
                r = webrequest.get(endpoint, allow_redirects=False, timeout=10)
                appLogger.info("HTTP Status Code: {}".format(r.status_code))
                # any code between 200-499 is considered a success. Python range() goes from 200-499.
                if r.status_code not in range(200, 500):
                    msg = "FAIL: ({}) Webrequest using Source IP {} received invalid status code for {} and it is not within the acceptable range of 200-499.  StatusCode={}".format(
                        self.device, self.sourceIP, endpoint, r.status_code)
                    appLogger.warning(msg)
                    returnData['message'].append(msg)
                    success.append(False)
                    appLogger.info('failure: {}'.format(domain))
                    failures.append(domain)
                else:
                    appLogger.info("Response Text: {}".format(r.text))
                    success.append(True)
                    returnData['message'].append(
                        "PASS: ({}) Successfull webrequest using Source IP {} to: {}".format(self.device, self.sourceIP, endpoint))
            except Exception as e:
                success.append(False)
                appLogger.info('failure: {}'.format(domain))
                failures.append(domain)
                returnData['message'].append(
                    "FAIL: ({}) Unsuccessfull webrequest using Source IP {} to: {}: Exception: {}".format(self.device, self.sourceIP, endpoint, str(e)))
        if False not in success:
            returnData['success'] = True
        else:
            appLogger.warning(returnData['message'])
            raise Exception(returnData['message'], {
                            'continue': False}, failures)

        return returnData

    @retry(Exception, initial_wait=5, total_tries=2, backoff_factor=1.5)
    def p2pPing(self):
        appLogger.info('Starting p2pPing testing.')
        returnData = {}
        returnData['success'] = True
        returnData['message'] = []
        tor1ToBorder = []
        tor2ToBorder = []
        try:
            for dest in self.destination:
                destKey = list(dest.keys())[0]
                destValue = list(dest.values())[0]
                appLogger.info('Ping to {}'.format(destKey))
                command = 'ping -I {} -n -c 4 {}'.format(
                    self.sourceIP, destValue)
                stdout, returnCode = sendCommand(command)
                pingOutput = (stdout.decode("utf-8")).rstrip('\n')
                appLogger.info(pingOutput)
                if returnCode == 0:
                    msg = 'PASS: ({}) Successful ping using Source IP {} to: {}'.format(
                        self.device, self.sourceIP, destKey)
                    appLogger.info(msg)
                    returnData['message'].append(msg)

                else:

                    # Customers Border IP's may not ping. Warning
                    if re.search('Rack\d{2}/B\d', destKey):
                        msg = 'WARN: ({}) Unsuccessful ping using Source IP {} to: {}'.format(
                            self.device, self.sourceIP, destKey)
                        appLogger.warning(msg)
                        returnData['message'].append(msg)

                    # Tor1's IP to Border, expected to ping as the interface is within AzsHub
                    elif re.search('Rack\d{2}/Tor1', destKey):
                        msg = 'FAIL: ({}) Unsuccessful ping using Source IP {} to: {}'.format(
                            self.device, self.sourceIP, destKey)
                        appLogger.error(msg)
                        tor1ToBorder.append(msg)
                        # returnData['message'].append(msg)

                    # Tor2's IP to Border, expected to ping as the interface is within AzsHub
                    elif re.search('Rack\d{2}/Tor2', destKey):
                        msg = 'FAIL: ({}) Unsuccessful ping using Source IP {} to: {}'.format(
                            self.device, self.sourceIP, destKey)
                        appLogger.error(msg)
                        tor2ToBorder.append(msg)
                        # returnData['message'].append(msg)

                    # Vlan interfaces are not required to pass the ping test as we have seen unreliable results across all OEM's
                    elif re.search('-BMCMgmt|-Infrastructure|-ExtendedStore|-ExtStoreMGMT', destKey):
                        msg = 'WARN: ({}) Unsuccessful ping using Source IP {} to: {}'.format(
                            self.device, self.sourceIP, destKey)
                        appLogger.warning(msg)
                        returnData['message'].append(msg)

                    # These should ping and are failures.
                    elif re.search('ibgp', destKey):
                        msg = 'FAIL: ({}) Unsuccessful ping using Source IP {} to: {}'.format(
                            self.device, self.sourceIP, destKey)
                        appLogger.error(msg)
                        returnData['message'].append(msg)
                        returnData['success'] = False

                    # Add a sleep between ping tests
                        time.sleep(1)

            # Greater than one indicates FAIL
            if len(tor1ToBorder) > 1:
                returnData['success'] = False
                returnData['message'] += tor1ToBorder

            if len(tor2ToBorder) > 1:
                returnData['success'] = False
                returnData['message'] += tor2ToBorder
                #raise Exception('P2P Testing has failed as the required interfaces did not respond to ping.')

            # Exactly one is acceptable, the msg will be updated from FAIL to WARN
            if len(tor1ToBorder) == 1:
                for item in tor1ToBorder:
                    match = re.compile('FAIL')
                    msg = match.sub('WARN', item)
                    appLogger.warning(msg)
                    returnData['message'].append(msg)

            if len(tor2ToBorder) == 1:
                for item in tor1ToBorder:
                    match = re.compile('FAIL')
                    msg = match.sub('WARN', item)
                    appLogger.warning(msg)
                    returnData['message'].append(msg)

            # Required ping checks not met.
            if returnData['success'] == False:
                raise Exception(
                    'P2P Testing has failed as the required interfaces did not respond to ping.')

        except Exception as e:
            appLogger.warning(str(e))
            raise Exception(returnData['message'], {'continue': False}, [])

        return returnData


class BgpNeighbor:
    def __init__(self, neighborName, ipaddress):
        self.neighborName = neighborName
        self.ipaddress = ipaddress

    def configureBgpNeighbor(self, state):
        try:
            validState = ["startup", "shutdown"]
            if state not in validState:
                raise Exception(
                    "Unsupported state: {}.  Must be: {}".format(state, validState))
            appLogger.info("Command: sudo config bgp {} neighbor {}".format(
                state, self.ipaddress))
            stdout, returnCode = sendCommand(
                "sudo config bgp {} neighbor {}".format(state, self.ipaddress))
            result = (stdout.decode("utf-8")).rstrip('\n')
            if state == "startup":
                if not 'Starting up BGP session with neighbor {}...'.format(self.ipaddress) == result:
                    raise Exception("Unexpected output in {}".format(result))
            else:
                if not 'Shutting down BGP session with neighbor {}...'.format(self.ipaddress) == result:
                    raise Exception("Unexpected output in {}".format(result))
            appLogger.info("Command result: {}".format(result))
            return result
        except Exception as e:
            raise(e)

    # Total Retry time is approx 10.5 minutes
    @retry(Exception, initial_wait=30, total_tries=7, backoff_factor=1.5)
    def checkBgpNeighbor(self, state):
        try:
            validState = ["enabled", "disabled"]
            if state not in validState:
                raise Exception(
                    "Unsupported state: {}.  Must be: {}".format(state, validState))
            appLogger.info("Getting all BGP neighbors")
            result = self.getBgpNeighbors()
            for key, value in result.items():

                # checking the neighbor for its correct state
                if key == self.ipaddress:
                    if state == "enabled":
                        if not value['bgpState'] == 'Established':
                            raise Exception(
                                'FAIL: Expected the neighbor {}:{} to be Establish in BGP. Check that the TOR configurations are correct.'.format(self.neighborName, self.ipaddress))
                        else:
                            appLogger.info("{} {} is peering properly".format(
                                self.neighborName, self.ipaddress))
                            pass
                    else:

                        #state is disabled
                        if not 'adminShutDown' in value:
                            raise Exception(
                                'Expected the BGP neighbor {} to be adminShutDown state.'.format(self.ipaddress))
                else:
                    if state == "enabled":
                        if not 'adminShutDown' in value:
                            raise Exception(
                                'Expected the OTHER neighbor {} to be adminShutDown state.'.format(key))
                    else:
                        if not value['bgpState'] == 'Established':
                            raise Exception(
                                'Expected the OTHER neighbor {} to be Establish in BGP'.format(key))
                        else:
                            pass
            return True
        except Exception as e:
            raise Exception(e)

    def getBgpNeighbors(self):
        appLogger.info("Getting all BGP neighbors..")
        stdout, returnCode = (sendCommand(
            "sudo vtysh -c 'show ip bgp neighbor json'"))
        return json.loads(stdout)

    def startAllBgpNeighbors(self):
        appLogger.info("Starting all BGP neighbors..")
        stdout, returnCode = sendCommand("sudo config bgp startup all")
        result = (stdout.decode("utf-8")).rstrip('\n')
        return result

    def shutdownAllBgpNeighbors(self):
        appLogger.info("Shutting down all BGP neighbors..")
        stdout, returnCode = sendCommand("sudo config bgp shutdown all")
        result = (stdout.decode("utf-8")).rstrip('\n')
        return result


if __name__ == '__main__':
    main()
