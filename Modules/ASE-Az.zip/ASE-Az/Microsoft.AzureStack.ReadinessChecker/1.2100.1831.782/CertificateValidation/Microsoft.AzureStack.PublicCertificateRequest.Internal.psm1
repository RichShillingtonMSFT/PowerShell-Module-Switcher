function Set-CertificateSubject {
    <#
    .SYNOPSIS
        Set Distinguished name for certificate request
    .DESCRIPTION
        Checks if Common Name is present and honours CN in distinguished name.
        If common name is not present, it preprends the target RP hostname to the distinguished name as a common name value.
    #>
    param (
            [System.Security.Cryptography.X509Certificates.X500DistinguishedName]$distinguishedName,
            [System.Security.Cryptography.X509Certificates.X500DistinguishedNameFlags]$distinguishedNameFlag = 'UseUTF8Encoding',
            [string]$commonName
            )
    try {
        $thisFunction = $MyInvocation.MyCommand.Name
        if ($distinguishedName) {
            $distinguishedNameExpanded = $distinguishedName.Format($true)
            $distinguishedNameString = $distinguishedName.Format($false)

            Write-AzsReadinessLog -Message ("User DN String is: {0}, flag: {1}" -f $distinguishedNameString,$distinguishedNameFlag) -Type Info -Function $thisFunction
            $commonNamePair = $distinguishedNameExpanded.trim() -split "`n" | Where-Object { $PSITEM -imatch 'cn='}
        }

        if ($commonNamePair) {
            Write-AzsReadinessLog -Message ("User DN String contains common name, no change: {0}" -f $distinguishedNameString) -Type Info -Function $thisFunction
        }
        else {
            $distinguishedNameString = "CN={0}" -f (($commonName,$distinguishedName.Name) -join ',')
            Write-AzsReadinessLog -Message ("Calculated DN String is: {0}, flag: {1}." -f $distinguishedNameString,$distinguishedNameFlag) -Type Info -Function $thisFunction
        }
        return [System.Security.Cryptography.X509Certificates.X500DistinguishedName]::new($distinguishedNameString,[System.Security.Cryptography.X509Certificates.X500DistinguishedNameFlags]::UseUTF8Encoding)
    }
    catch {
        Write-AzsReadinessLog -Message ("Setting Certificate Subject failed with exception: {0}" -f $_.exception.message) -Type Error -Function $thisFunction -toScreen
        break
    }
}

function Get-CSRFileName {
    param (
        [array]$commonName
    )
    $filename = "{0}_certrequest.req" -f $commonName[0].Replace('.', '_').Replace('*', 'wildcard')
    return $filename
}

function Write-AzsCertificateRequestFileInternal {
    <#
    .SYNOPSIS
        Internal function to call CSR using the standard Azure Stack request template.
    .DESCRIPTION
        Imports the standard Azure Stack certificate request template
        replaces deployment specific data such as subject and SAN.
        Detects if commas are used in the subject name and thus requiring a different X500NameFlag
    .EXAMPLE
        Write-AzsCertificateRequestFileInternal -subjectAltNames $completeSANs -subject $subject  -KeyLength $KeyLength -HashAlgorithm $HashAlgorithm -OutputRequestPath $OutputRequestPath
    .INPUTS
        subjectAltNames - string - SubjectAlternativeNames
        subject - ordereddictionary - hashtable of deployment subject
        OutputRequestPath - string - path (parent must be valid) to where the CSRs should land.
        KeyLength - int - Defines the length of the public and private key
        HashAlgorithm - string - Hash Algorithm to be used for this request.
    .OUTPUTS
        Encoded CSR file - This is the file or content that should be presented to a CA to request certificates
        Clear Text INF file - this is a reference file to help debugging.
        Certreq log file - the output of the certreq.exe command, later streamed into overall AzsCertificateRequest.log
    .NOTES
    #>
    [cmdletbinding()]
    param (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$subject,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string[]]$subjectAltNames,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [ValidateScript( {Test-Path (Split-Path $_ -parent) -PathType Container})]
        $OutputRequestPath,

        [Parameter(Mandatory = $false)]
        [ValidateSet(2048, 4096, 8192)]
        [int]$KeyLength = 2048,

        [Parameter(Mandatory = $false)]
        [ValidateSet('SHA256', 'SHA384', 'SHA512')]
        [string]$HashAlgorithm = 'SHA256',

        [Parameter(Mandatory = $false)]
        [string[]]$KeyUsage = @('DigitalSignature','KeyEncipherment'),

        [Parameter(Mandatory = $false)]
        $KeyUsageEKUExtension = @('Server Authentication','Client Authentication'),

        [Parameter(Mandatory = $false)]
        [System.Security.Cryptography.X509Certificates.X500DistinguishedNameFlags]$DistinguishedNameFlag = $null,

        [Parameter(Mandatory = $false)]
        [switch]$LowPrivilege
    )

    $thisFunction = $MyInvocation.MyCommand.Name
    try {

        # translate DistinguishNameFlag
        $x500flagValue = switch ($DistinguishedNameFlag) {
            'DoNotUsePlusSign' {'0x20000000'}
            'DoNotUseQuotes'   {'0x10000000'}
            'ForceUTF8Encoding'{'0x80000'}
            'None'             {'0'}
            'Reversed'         {'0x2000000'}
            'UseCommas'        {'0x4000000'}
            'UseNewLines'      {'0x8000000'}
            'UseSemicolons'    {'0x40000000'}
            'UseT61Encoding'   {'0x20000'}
            'UseUTF8Encoding'  {'0x40000'}
            'Default'          {'0'}
        }

        # if name flag isn't 'none' write the flag in the inf file, otherwise write nothing.
        if ($x500flagValue -ne '0') {
            $X500NameFlags = "X500NameFlags = $x500flagValue`n`r"
        }

        # Get Key Usages Strings
        $keyUsageStrings = Format-KeyUsage -KeyUsage $KeyUsage

        # Get Enhanced Key Usage strings
        $EKUInfStrings = Format-EnhancedKeyUsage -EKUExtension $KeyUsageEKUExtension

        # Get SAN DNS names formatted
        $sanString = Format-SubjectAlternativeNames -subjectAltNames $subjectAltNames

        # Get INF Template and replace placeholders with user data
        $data = Import-PowerShellDataFile $PSScriptRoot\Microsoft.AzureStack.PublicCertificateRequestData.psd1
        $infTemplate = $data.requestINF
        $requestINF = $infTemplate.Replace('[[SubjectString]]', $subject.replace('"',''))
        $requestINF = $requestINF.Replace('[[KeyUsage]]',$keyUsageStrings)
        $requestINF = $requestINF.Replace('[[X500]]', $X500NameFlags)
        $requestINF = $requestINF.Replace('[[SANStrings]]', $sanString)
        $requestINF = $requestINF.Replace('[[KeyLength]]', $KeyLength)
        $requestINF = $requestINF.Replace('[[HashAlgorithm]]', $HashAlgorithm)
        $requestINF = $requestINF.Replace('[[EnhancedKeyStrings]]', $EKUInfStrings.Strings)
        $requestINF = $requestINF.Replace('[[EnhancedKeyExtension]]', $EKUInfStrings.Extensions)

        $CertReqFilePaths = Get-CertReqFilePaths -filePath $OutputRequestPath
        $infFilePath = $CertReqFilePaths.infFilePath
        $csrFilePath = $CertReqFilePaths.csrFilePath
        $certReqLogPath = $CertReqFilePaths.certReqLogPath

        # Create and print Inf template
        $requestINF | Out-File $infFilePath -Force
        # Create encoded cert request
        Write-AzsReadinessLog -Message ("Setting csrFilePath to {0}" -f $csrFilePath) -Type Info -Function $thisFunction

        if (-not $LowPrivilege) {
            $cmd = "-new $infFilePath $csrFilePath"
            $process = Start-Process -FilePath certreq.exe `
                -ArgumentList $cmd `
                -WindowStyle Hidden `
                -PassThru `
                -Wait `
                -RedirectStandardOutput $certReqLogPath
            if ($process.ExitCode -ne 0) {
                $certReqLogContent = Get-Content $certReqLogPath
                throw $certReqLogContent
            }
            Write-AzsReadinessLog -Message ("CSR generating for following SAN(s): {0}" -f ($subjectAltNames -join ',')) -Type Info -Function $thisFunction -toScreen
            Write-AzsReadinessLog -Message ("Present this CSR to your Certificate Authority for Certificate Generation: {0}" -f $csrFilePath) -Type Info -Function $thisFunction -toScreen
        }
        else {
            Write-AzsReadinessLog -Message ("INF generating for following SAN(s): {0}" -f ($subjectAltNames -join ',')) -Type Info -Function $thisFunction -toScreen
            Write-AzsReadinessLog -Message ("Copy this template to a machine with Admin priviledges to convert to a Certificate Signing Request Generation: {0}" -f $infFilePath) -Type Info -Function $thisFunction -toScreen
        }
    }
    catch {
        Write-AzsReadinessLog -Message ("CSR generation failed with: {0}" -f $_.exception) -Type Error -Function $thisFunction
        throw ("CSR generation failed with: {0}" -f $_.exception)
    }
    finally {
        # Move inf file and copy log only if certreq was run.
        if (-not $LowPrivilege) {
            # Move inf file to child directory called inf
            $infDest = ("{0}\{1}" -f (Split-Path $infFilePath -parent), 'Inf')
            if (-not (Test-Path $infDest)) {$null = New-Item -path $infDest  -ItemType Directory -Force}
            Move-Item -Path $infFilePath -Destination $infDest -Force -ErrorAction SilentlyContinue
            # Move log content to parent log and clean up log file.
            $certReqLogContent = Get-Content $certReqLogPath -ErrorAction SilentlyContinue | ForEach-Object {if ($_) {$_}}
            if (-not $certReqLogContent) {$certReqLogContent = '[missing]'}
            Write-AzsReadinessLog -Message ("Certreq.exe output: {0}" -f ($certReqLogContent -join '. ')) -Type Info -Function $thisFunction -toScreen
            Remove-item $certReqLogPath -Force
        }
    }
}

function Format-KeyUsage {
    param([string[]]$KeyUsage)
    $thisFunction = $MyInvocation.MyCommand.Name
    try {
        Write-AzsReadinessLog -Message ("Formating key {0} usage(s)." -f $KeyUsage.Length) -Type Info -Function $thisFunction
        $KeyUsageOutput = for ($i = 0; $i -lt $KeyUsage.Length; $i++) {
            # convert the value
            Write-AzsReadinessLog -Message ("Formating Key usage: {0}" -f $KeyUsage[$i]) -Type Info -Function $thisFunction
            $keyUsageValue = switch ($KeyUsage[$i]) {
                digitalSignature {'CERT_DIGITAL_SIGNATURE_KEY_USAGE'}
                nonRepudiation {'CERT_NON_REPUDIATION_KEY_USAGE'}
                keyEncipherment {'CERT_KEY_ENCIPHERMENT_KEY_USAGE'}
                dataEncipherment {'CERT_DATA_ENCIPHERMENT_KEY_USAGE'}
                keyAgreement {'CERT_KEY_AGREEMENT_KEY_USAGE'}
                keyCertSign {'CERT_KEY_CERT_SIGN_KEY_USAGE'}
                cRLSign {'CERT_CRL_SIGN_KEY_USAGE'}
                encipherOnly {'CERT_ENCIPHER_ONLY_KEY_USAGE'}
                decipherOnly {'CERT_DECIPHER_ONLY_KEY_USAGE'}
            }
            "`"$keyUsageValue`""
        }
        $keyUsageString = $KeyUsageOutput -join '|'
        $keyUsageString
    }
    catch {
        Write-AzsReadinessLog -Message ("Formatting key usage failed with exception: {0}" -f $_.exception) -Type Error -Function $thisFunction
        break
    }

}

function Format-EnhancedKeyUsage {
    <#
    .SYNOPSIS
        Crafts neccessary data for certificate request file
    .DESCRIPTION
        Creates strings section and extensions section data e.g.
        [Strings]
        szOID_SUBJECT_ALT_NAME2 = "2.5.29.17"
        szOID_ENHANCED_KEY_USAGE = "2.5.29.37"
        szOID_PKIX_KP_SERVER_AUTH = "1.3.6.1.5.5.7.3.1"
        szOID_PKIX_KP_CLIENT_AUTH = "1.3.6.1.5.5.7.3.2"
        [Extensions]
        %szOID_SUBJECT_ALT_NAME2% = "{text}[[SANStrings]]"
        %szOID_ENHANCED_KEY_USAGE% = "{text}%szOID_PKIX_KP_SERVER_AUTH%,%szOID_PKIX_KP_CLIENT_AUTH%"
    #>
    param ($EKUExtension)
    $thisFunction = $MyInvocation.MyCommand.Name
    try {
        $dataFile = Import-PowerShellDataFile $PSScriptRoot\Microsoft.AzureStack.CertificateConfig.psd1
        $EKUHashtable = $dataFile.CertificateAttributes.EnhancedKeyUsage

        Write-AzsReadinessLog -Message ("Formating Enhanced Key usages: {0}" -f ($EKUExtension -join ',')) -Type Info -Function $thisFunction
        if ($null -ne $EKUExtension) {

            $enhancedStrings = @()
            $enhancedExtensions = @()
            $enhancedStrings += "szOID_ENHANCED_KEY_USAGE = `"2.5.29.37`""

            foreach ($eku in $EKUExtension) {
                Write-AzsReadinessLog -Message ("Formating Key usage: {0}" -f $eku) -Type Info -Function $thisFunction
                $ekuData = $EKUHashtable[$eku]
                # if the eku isn't present in the config, treat it as user supplied
                if (-not $ekuData) {
                    $ekuData = @{}
                    $eku.keys | ForEach-Object {
                        $stringName = "XCN_OID_{0}" -f $_.replace(' ','_')
                        $ekuData.Add($stringName, $eku[$_])
                    }
                }
                # Construct string format
                $ekuString = "{0} = `"{1}`"" -f $ekuData.GetEnumerator().Name,$ekuData[$ekuData.GetEnumerator().Name]
                Write-AzsReadinessLog -Message ("EKU String: {0}" -f $ekuString) -Type Info -Function $thisFunction

                # Append string section with EKU and OID
                $enhancedStrings += $ekuString.replace('XCN_','sz')
                Write-AzsReadinessLog -Message ("Enhanced String: {0}" -f $enhancedStrings) -Type Info -Function $thisFunction

                # Append Extension section with EKU and OID
                $enhancedExtensions += $ekuData.GetEnumerator().Name.replace('XCN_','sz')
                Write-AzsReadinessLog -Message ("EKU Extension: {0}" -f $enhancedExtensions) -Type Info -Function $thisFunction
            }

            $enhancedExtensionString += "%szOID_ENHANCED_KEY_USAGE% = `"{{text}}%{0}%`"" -f ($enhancedExtensions -join '%,%')
        }
        @{Strings = ($enhancedStrings -join "`n"); Extensions = $enhancedExtensionString}
    }
    Catch {
        Write-AzsReadinessLog -Message ("Formatting key usage failed with exception: {0}" -f $_.exception) -Type Error -Function $thisFunction
        break
    }
}

function ConvertTo-EnhancedKeyUsage {
    <#
    .SYNOPSIS
        Converts custom input from user to Oid collection of Enhanced Key Usage
    .DESCRIPTION
        Converts custom input from user to Oid collection of Enhanced Key Usage
    .EXAMPLE
        PS C:\> ConvertTo-EnhancedKeyUsage @('Server Authentication','Client Authentication',@{'My_Custom_Name' = '1.3.6.1.5.15.7.3.2'})
        Converts custom input from user to Oid collection of Enhanced Key Usage
    #>
    param ($EnhancedKeyUsages)
    $thisFunction = $MyInvocation.MyCommand.Name
    try {
        $EKUCollection = [System.Security.Cryptography.OidCollection]::new()
        $EKUCollection += foreach ($EnhancedKeyUsage in $EnhancedKeyUsages) {
                if ($EnhancedKeyUsage -is [HashTable]) {
                    $EnhancedKeyUsage.keys | ForEach-Object {
                        $oid = [System.Security.Cryptography.Oid]::new($EnhancedKeyUsage[$_], $_)
                        [void]$EKUCollection.Add($oid)
                        Write-AzsReadinessLog -Message ('Added OID {0} ({1})' -f $oid.Value,$oid.FriendlyName) -Type Info -Function $thisFunction
                    }
                }
                else {
                    $oid = [System.Security.Cryptography.Oid]::new($EnhancedKeyUsage)
                    [void]$EKUCollection.Add($oid)
                    Write-AzsReadinessLog -Message ('Added OID {0} ({1})' -f $oid.Value,$oid.FriendlyName) -Type Info -Function $thisFunction
                }
        }
        $EKUCollection | Foreach-Object {
            if (!$_.FriendlyName -or !$_.Value) {
                $errorMsg = ("Invalid Oid data. `nName: '{0}' `nValue: '{1}' `nEnsure input is valid. For example, the following will request Client and Server Auth key usage and the custom usage: `n@('Client Authentication','Server Authentication',@{{'Custom Usage' = '1.3.6.1.5.7.8.2.1'}})" -f $_.friendlyName, $_.Value)
                Write-AzsReadinessLog -Message $errorMsg -Type Error -Function $thisFunction
                throw $errorMsg
            }
        }
    }
    catch {
        throw $_
    }
}

function Format-SubjectAlternativeNames {
    <#
    .SYNOPSIS
        Formats array of DNS names for SAN
    .DESCRIPTION
        Creates neccessary string for SAN in certificate request inf config.
        %szOID_SUBJECT_ALT_NAME2% = "{text}dns=*.queue.east.azurestack.contoso.com"
    #>
    param ([string[]]$subjectAltNames)
    $thisFunction = $MyInvocation.MyCommand.Name
    try {
        $sanStrings = @()
        foreach ($san in $subjectAltNames) {
            Write-AzsReadinessLog -Message ("Formatting Subject Alternative DNS Names : {0}" -f $san) -Type Info -Function $thisFunction
            $sanStrings += "dns={0}" -f $san
        }
        $sanStrings -join "&"
    }
    catch {
        Write-AzsReadinessLog -Message ("Formatting Subject Alternative DNS Names failed with exception: {0}" -f $_.exception) -Type Error -Function $thisFunction
        break
    }
}

function Test-DistinguishedName {
    <#
    .SYNOPSIS
        Ensure user specified distinguished name is valid.
    .DESCRIPTION
        Ensure the distringuished name has the rght number of rdn when it is formatted
    .NOTES
        General notes
    #>
    param (
        [System.Security.Cryptography.X509Certificates.X500DistinguishedName]$DistinguishedName,
        [System.Security.Cryptography.X509Certificates.X500DistinguishedNameFlags]$DistinguishedNameFlag
    )
    $thisFunction = $MyInvocation.MyCommand.Name
    try {
        $dn = [Security.Cryptography.X509Certificates.X500DistinguishedName]::new($distinguishedName.Name,$DistinguishedNameFlag)
        $rdnCount = $distinguishedName.Name.ToCharArray() | Group-Object -NoElement | Where-Object Name -eq '=' | Select-Object -ExpandProperty Count
        $dnFormat = $dn.Format($true)
        $formatLineCount = $dnFormat | Measure-Object -Line | Select-Object -ExpandProperty Lines

        # Checking for common issues
        if ($dnFormat -match ',' -and $DistinguishedNameFlag -ne 'UseSemicolons') {
            throw ("One or more RDNs appear to contain commas, the correct format for the distinguished name is to seperate RDNs with semi-colons and pass the UseSemiColons DistinguishedNameFlag")
        }

        # if the number of rdns doesn't match the number of '=' characters, the format probably isn't what the user intended.
        if ($rdnCount -ne $formatLineCount) {
            throw ("Error validating the distinguish name provided: {0}" -f $dnFormat)
        }

        Write-AzsReadinessLog ("Validated the distinguished name: {0}" -f $dnFormat) -Type Info -Function $thisFunction
        return $true
    }
    catch {
        Write-AzsReadinessLog ("Check the input of the distinguished name. Error {0}" -f $_.exception.message) -type Error -Function $thisFunction -toScreen
        throw $_.exception.message
    }

}

function Get-CertReqFilePaths {
    <#
    .SYNOPSIS
        Short description
    .DESCRIPTION
        Long description
    .EXAMPLE
        PS C:\> $FilePath = Join-Path -Path $OutputRequestPath -ChildPath $subjectAltNames[0].Replace('.', '_').Replace('*', 'wildcard')
        Get-CertReqFilePaths -filePath $FilePath
        outputs inf path, req path and log path.
    #>
    param ($filePath)
    $thisFunction = $MyInvocation.MyCommand.Name

    $directory = Split-Path $filePath -Parent
    $fileSeed = Split-Path $filePath -Leaf

    #Create filepaths for inf, req and log as [host|wildcard].region.external.fqdn-CertRequest-
    $infFilePath = "{0}\{1}_CertRequest_{2}_ClearTextTemplate.inf" -f $directory, $fileSeed, (Get-Date -f yyyyMMddHHmmss)
    Write-AzsReadinessLog -Message ("Setting infFilePath to {0}" -f $infFilePath) -Type Info -Function $thisFunction
    $csrFilePath = $infFilePath.Replace('_ClearTextTemplate', '').Replace('inf', 'req')
    $certReqLogPath = $csrFilePath.Replace('.req', '.log')
    @{infFilePath = $infFilePath; csrFilePath = $csrFilePath; certReqLogPath = $certReqLogPath}
}
# SIG # Begin signature block
# MIIjkgYJKoZIhvcNAQcCoIIjgzCCI38CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBv74ORWkd3THsT
# RYCrndL6TNfjaOCp+fsyFWZ3Bna7M6CCDYEwggX/MIID56ADAgECAhMzAAACUosz
# qviV8znbAAAAAAJSMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjEwOTAyMTgzMjU5WhcNMjIwOTAxMTgzMjU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDQ5M+Ps/X7BNuv5B/0I6uoDwj0NJOo1KrVQqO7ggRXccklyTrWL4xMShjIou2I
# sbYnF67wXzVAq5Om4oe+LfzSDOzjcb6ms00gBo0OQaqwQ1BijyJ7NvDf80I1fW9O
# L76Kt0Wpc2zrGhzcHdb7upPrvxvSNNUvxK3sgw7YTt31410vpEp8yfBEl/hd8ZzA
# v47DCgJ5j1zm295s1RVZHNp6MoiQFVOECm4AwK2l28i+YER1JO4IplTH44uvzX9o
# RnJHaMvWzZEpozPy4jNO2DDqbcNs4zh7AWMhE1PWFVA+CHI/En5nASvCvLmuR/t8
# q4bc8XR8QIZJQSp+2U6m2ldNAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUNZJaEUGL2Guwt7ZOAu4efEYXedEw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDY3NTk3MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAFkk3
# uSxkTEBh1NtAl7BivIEsAWdgX1qZ+EdZMYbQKasY6IhSLXRMxF1B3OKdR9K/kccp
# kvNcGl8D7YyYS4mhCUMBR+VLrg3f8PUj38A9V5aiY2/Jok7WZFOAmjPRNNGnyeg7
# l0lTiThFqE+2aOs6+heegqAdelGgNJKRHLWRuhGKuLIw5lkgx9Ky+QvZrn/Ddi8u
# TIgWKp+MGG8xY6PBvvjgt9jQShlnPrZ3UY8Bvwy6rynhXBaV0V0TTL0gEx7eh/K1
# o8Miaru6s/7FyqOLeUS4vTHh9TgBL5DtxCYurXbSBVtL1Fj44+Od/6cmC9mmvrti
# yG709Y3Rd3YdJj2f3GJq7Y7KdWq0QYhatKhBeg4fxjhg0yut2g6aM1mxjNPrE48z
# 6HWCNGu9gMK5ZudldRw4a45Z06Aoktof0CqOyTErvq0YjoE4Xpa0+87T/PVUXNqf
# 7Y+qSU7+9LtLQuMYR4w3cSPjuNusvLf9gBnch5RqM7kaDtYWDgLyB42EfsxeMqwK
# WwA+TVi0HrWRqfSx2olbE56hJcEkMjOSKz3sRuupFCX3UroyYf52L+2iVTrda8XW
# esPG62Mnn3T8AuLfzeJFuAbfOSERx7IFZO92UPoXE1uEjL5skl1yTZB3MubgOA4F
# 8KoRNhviFAEST+nG8c8uIsbZeb08SeYQMqjVEmkwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVZzCCFWMCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAlKLM6r4lfM52wAAAAACUjAN
# BglghkgBZQMEAgEFAKCBrjAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgLT7QsZ/t
# NX2ghlURvWBozvCfeG3t5/ixNXckHO8Q7VwwQgYKKwYBBAGCNwIBDDE0MDKgFIAS
# AE0AaQBjAHIAbwBzAG8AZgB0oRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQBDWWrTGPI3cP3WBVqRtQ6n2SVOC4VspqyaqfFRsM0+
# c0ZGYO/Qo9v2wprQAjsU85fXWzEAkSwQM6TT3tuZdvItPmQ5DaLa1emvsyT8mF+b
# f9/JHydkDZSc0w2yUo24YkKJHlMY2FzBzUZmZaCRVSMst2QxI9J8HXdWoIheQ8y+
# ccIYmB3M4Rju1CnUoz9RXolqH4ANdMK8q3s+jtSWyB9OS4wZnVNFk6cWxbdoAjLx
# eLQaQM5OzOSY9OjgJstgPNj0TEYi2TVER6e1VjTaaViJeuongyBSQXtnYTy9beb/
# 669AYeldBWALqu4+hj8iMTLD68YrSho6zOrh6qOCoYYooYIS8TCCEu0GCisGAQQB
# gjcDAwExghLdMIIS2QYJKoZIhvcNAQcCoIISyjCCEsYCAQMxDzANBglghkgBZQME
# AgEFADCCAVUGCyqGSIb3DQEJEAEEoIIBRASCAUAwggE8AgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEINKYPABprYRhklsYMqP7Hno5Bee88CfbDUjl/jIg
# OwP0AgZhvMDr8N4YEzIwMjIwMTA1MTIxMTI5LjgxNFowBIACAfSggdSkgdEwgc4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1p
# Y3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMg
# VFNTIEVTTjpGN0E2LUUyNTEtMTUwQTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgU2VydmljZaCCDkQwggT1MIID3aADAgECAhMzAAABWZ/8fl8s6vJDAAAA
# AAFZMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MB4XDTIxMDExNDE5MDIxNVoXDTIyMDQxMTE5MDIxNVowgc4xCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVy
# YXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpGN0E2
# LUUyNTEtMTUwQTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vydmlj
# ZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAK54xGHJZ8SHREtNIoBo
# 9AG6Mro8gEZCt8WgV/mNdIt2tMOP3zVYU4+sRsImxTwfzJEDBWaTc7LxlEy/1302
# fRmd/R2pwnY7pyT90yvZAmQQLZ6D+faGBwwhi5rre/tmBJdbAXFZ8qL2JDc4txBn
# 30Mr1C8DFBdrIjwbP+i2RdAOaSwIs/xQsMeZAz3v5j9VEdwq8+iM6YcLcqKrYAwP
# +OE58371ST5kj2f7quToeTXhSvDczKYrVokL3Zn0+KNAnbpp4rH1tXymmgXQcgVC
# z1E/Ey8NEsvZ1FjV5QP6ovDMT8YAo7KzaYvT4Ix+xMVvW+1/1MnYaaoR8bLnQxmT
# ZOMCAwEAAaOCARswggEXMB0GA1UdDgQWBBT20KmFRryt+uTrJ9eIwjyy6Tdj5zAf
# BgNVHSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBH
# hkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNU
# aW1TdGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUF
# BzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0
# YVBDQV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsG
# AQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IBAQCNkVQS6A+BhrfGOCAWo3KcuUa4estp
# zyn+ZLlkh0pJmAJp4EUDrLWsieYCf2oyoc8KjVMC+NHFFVvHLrSMhWnR5FtY6l3Z
# 6Ur9ITBSz64j5wTRRE8vIpQiHVYjRVNPGR2tiqG5nKP5+sD0rZI464OFNz4n7erD
# JOpV7Im1L/sAwfX+GHoc4j5rfuAuQTFY82sdYvtHM4LTxwV997uhlFs52oHapdFW
# 1KXt6vMxEXnSX8soQfUd+M+Yq3J7udc6R941Guxfd6A0vecV56JjvmpCng4jRkqu
# Aeyf/dKmQUaR1fKvALBRAmZkAUtWijS/3MkeQv/lUvHVo7GPFzJ/O3wJMIIGcTCC
# BFmgAwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJv
# b3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1WhcN
# MjUwNzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCASIw
# DQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkdDbx3EYo6IOz8E5f1+n9plGt0
# VBDVpQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMnBDEfQRsalR3OCROOfGEwWbEw
# RA/xYIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeGMoQe
# dGFnkV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8RsEnHSRnEnIaIYqvS2SJUGKx
# Xf13Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v0Ev9buWayrGo8noqCjHw2k4G
# kbaICDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN/LzAyURdXhacAQVPIk0CAwEA
# AaOCAeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ80N7
# fEYbxTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMC
# AYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvX
# zpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20v
# cGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYI
# KwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDCBoAYDVR0g
# AQH/BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYIKwYB
# BQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0AGUA
# bQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAAfmiFEN4sbgmD+BcQM9naOh
# IW+z66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4vceoniXj+bzta1RXCCtRgkQS
# +7lTjMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzymXlK
# kVIArzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8z+0DpZaPWSm8tv0E4XCfMkon
# /VWvL/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVKC5Em4jnsGUpxY517IW3DnKOi
# PPp/fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs9/S/
# fmNZJQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF0M2n0O99g/DhO3EJ3110mCII
# YdqwUB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+YWtvd6mBy6cJrDm77MbL2IK0
# cs0d9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt6o3gMy4SKfXAL1QnIffIrE7a
# KLixqduWsqdCosnPGUFN4Ib5KpqjEWYw07t0MkvfY3v1mYovG8chr1m1rtxEPJdQ
# cdeh0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc1bN+
# NR4Iuto229Nfj950iEkSoYIC0jCCAjsCAQEwgfyhgdSkgdEwgc4xCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBP
# cGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpG
# N0E2LUUyNTEtMTUwQTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZaIjCgEBMAcGBSsOAwIaAxUAKnbLAI8fhO58SCWrpZnXvXEZshGggYMwgYCk
# fjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIF
# AOV/ot4wIhgPMjAyMjAxMDUwODUzNTBaGA8yMDIyMDEwNjA4NTM1MFowdzA9Bgor
# BgEEAYRZCgQBMS8wLTAKAgUA5X+i3gIBADAKAgEAAgIlqAIB/zAHAgEAAgIRYjAK
# AgUA5YD0XgIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIB
# AAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAKoResrtY9MTNeF8
# SYfDMSt3p24mbbn30J0GQHRBYk21ncZF5AUa60UvwrEa/Cle+itgA2tYGXW68dB0
# mJBafrtq4sw3c5xgp6Ib6tb95Qdl5mDHzAGQji9zvSP2PSV0wCQPoYj5PVliIos8
# ga6EUWkoC03bKWGoCSGzJPnSXG8fMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTACEzMAAAFZn/x+Xyzq8kMAAAAAAVkwDQYJYIZIAWUD
# BAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0B
# CQQxIgQg8F371jVh0c82efG35WvJKKUGv3P4cnejNmO0f22gT2QwgfoGCyqGSIb3
# DQEJEAIvMYHqMIHnMIHkMIG9BCABWBvPvzDmfNeSzmJT4+dGA+uj/qq7/fKkUn36
# rxND6DCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB
# WZ/8fl8s6vJDAAAAAAFZMCIEIPtVz1PHihEZWrL/UGLoVi5vI0c50FopWkgfGrwU
# p9SvMA0GCSqGSIb3DQEBCwUABIIBAISs2tLVi+3l6dvJPpz2bq13FV48RMsNsw8d
# Tbpk7nOg6Vu+YtHXmzxdKBt0u0xZkVDIOuodktQMogMZliJ0VLSkhaSF7ot1RfpL
# zz+hwQeZCRbEx8gUK0qcyHUeLObhR4A0DVfnONGH3DWphJpn3H5R9+QfaGlXCH/j
# dkDtbtegA8IRWY+Aa4F0HFISqvo0IsS1BPtT7QZLu5JxhhfKRIZuzDZceB9KxrhF
# KBOPQ8m2+FoYwri3+a3yYsHnNaNgMhZ40I4xO88BIfQZDbdysqxYmf77GamwuNcp
# D4LEa5zDpzS5BExjmG4N4EDNroTUqNYKyzPpU6v8vn6zb7E8RZA=
# SIG # End signature block
