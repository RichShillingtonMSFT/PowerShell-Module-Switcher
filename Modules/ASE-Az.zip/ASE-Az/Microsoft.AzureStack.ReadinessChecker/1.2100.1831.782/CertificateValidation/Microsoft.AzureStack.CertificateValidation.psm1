<#############################################################
 #                                                           #
 # Copyright (C) Microsoft Corporation. All rights reserved. #
 #                                                           #
 #############################################################>

<#

.SYNOPSIS
This module is intended to be given to the customer along with their deploymentdata.json
in order to validate the certificates are suitable before Azure Stack deployment.

.DESCRIPTION
The validation checks the following:
    Read PFX. Checks for valid PFX file, correct password and warns if public information is not protected by the password.
    Signature Algorithm. Checks the Signature Algorithm is not SHA1
    Private Key. Checks the private key is present and is exported with the Local Machine attribute.
    Cert Chain. Checks certificate chain is in tact including for self-signed certificates.
    DNS Names. Checks the SAN contains relevant DNS names for each endpoint or if a supporting wildcard is present.
    Key Usage. Checks Key Usage contains Digital Signature and Key Encipherment and Enhanced Key Usage contains Server Authentication and Client Authentication.
    Key Size. Checks Key Size is 2048 or larger
    Chain Order. Checks the order of the other certificates making the chain is correct.
    Other Certificates. Ensure no other certificates have been packaged in PFX other than the relevant leaf certificate and its chain.
    No Profile. Checks a new user can load the PFX data without a user profile loaded, mimicking the behavior of gMSA accounts during certificate servicing.


.EXAMPLE
To Check certificates are ready for install run the following:
Import-Module .\Microsoft.AzureStack.CertificateValidation.psm1
$password = Read-Host -Prompt "Enter PFX Password" -AsSecureString
Start-CertChecker -CertificatePath .\Certificates\ -pfxPassword $password -deploymentDataJSONPath .\DeploymentData.json

To import/export certificates as indicated by the output of the above command
Import-Module .\Microsoft.AzureStack.CertificateValidation.psm1
$password = Read-Host -Prompt "Enter PFX Password" -AsSecureString
Start-CertChecker -pfxPassword $password -pfxPath \certificates\acsblob\old_sslblob.pfx -ExportToPath \certificates\acsblob\new_sslblob.pfx [<CommonParameters>]

.NOTES
The script expects the certificates in the same directory structure as the install: i.e.
\Certificates\
    \ACSblob
        \ssl.pfx
    \ADFS
        \ssl.pfx
The script requires the deploymentdata.json that will be used for deployment.

.LINK

#>

$mod = Import-Module $PSScriptRoot\PublicCertHelper.psd1 -Force -PassThru
Import-Module $PSScriptRoot\..\Microsoft.AzureStack.ReadinessChecker.Utilities.psm1 -Force
#setting global variable to true
$GLOBAL:standalone = $true
$ErrorActionPreference = 'Stop'

function Test-AzsCertificatePlacement {
    param ($certificatePath, $certConfig, $UseADFS)
    $thisFunction = $MyInvocation.MyCommand.Name
    # set expected folder names
    $validContainers = $certConfig.Keys | Foreach-Object {$PSITEM}
    if ($validContainers.count -eq 1) {
        if ($validContainers -eq (Split-Path $certificatePath -leaf)) {
            Write-AzsReadinessLog -message ("Single container expected: {0}" -f ($validContainers)) -Type Info -Function $thisFunction
            $folders = (Get-Item -Path $certificatePath)
            $actualContainers = (Get-Item -Path $certificatePath).Name
        }
        else {
            Write-AzsReadinessLog -Message ("Invalid folder name used {0}, expecting {1}. Please correct the folder name and retry. Exiting." -f (Split-Path -Path $certificatePath -leaf),$validContainers) -Type Error -Function $thisFunction -toScreen
            break
        }
    }
    elseif ($validContainers.count -gt 1) {
        Write-AzsReadinessLog -message ("Multiple containers found. Checking for folders: {0}" -f ($validContainers -join ',')) -Type Info -Function $thisFunction
        # Check directory structure is valid
        $actualContainers = (Get-ChildItem -Path $certificatePath -Directory).Name
        $folders = (Get-ChildItem -Path $certificatePath -Directory)
        if (-not $actualContainers) {
            Write-AzsReadinessLog -message ("Invalid folder structure found in certificate folder {0}, ensure only required folders are present. `nRequired folders: {1}" -f `
                $CertificatePath, `
                ($validContainers -join ', ')`
            ) -Type Error -Function $thisFunction -toScreen
            break
        }
    }
    else {
        Write-AzsReadinessLog -Message "Unable to determine expected certificate placement. Exiting." -Type Error -Function $thisFunction
        break
    }

    $compareContainers = Compare-Object -ReferenceObject $validContainers -DifferenceObject $actualContainers
    if ($compareContainers) {
        $invalidContainers = $compareContainers | Where-Object SideIndicator -eq '=>' | Select-Object -ExpandProperty InputObject
        $missingContainers = $compareContainers | Where-Object SideIndicator -eq '<=' | Select-Object -ExpandProperty InputObject
        if (-not $invalidContainers) {$invalidContainers = '[none]'}
        if (-not $missingContainers) {$missingContainers = '[none]'}
        Write-AzsReadinessLog -Message ("Invalid folder structure found in certificate folder {0}, ensure only required folders are present. `nRequired folders: {1} `nInvalid folders: {2} `nMissing folders: {3}" -f `
                $CertificatePath, `
            ($validContainers -join ', '), `
            ($invalidContainers -join ', '), `
            ($missingContainers -join ', ')
        ) -Type Error -Function $thisFunction -toScreen
        Write-AzsReadinessLog -Message 'Expected folder structure is as follows:' -Type Info -Function $thisFunction -toScreen
        Write-AzsReadinessLog -Message "`t$certificatePath" -Type Info -Function $thisFunction -toScreen
        $i = 0
        foreach ($key in $certConfig.keys) {
            $i++
            Write-AzsReadinessLog -Message "`t +--$key" -Type Info -Function $thisFunction -toScreen
            if ($i -lt $certConfig.Keys.count) {
                Write-AzsReadinessLog -Message "`t |   \-<customFileName>.pfx" -Type Info -Function $thisFunction -toScreen
            }
            else {
                Write-AzsReadinessLog -Message "`t     \-<customFileName>.pfx" -Type Info -Function $thisFunction -toScreen
            }
        }
        Write-AzsReadinessLog -Message "`nCorrect the folder structure and rerun validation." -Type Info -Function $thisFunction -toScreen
        break
    }
    else {
        Write-AzsReadinessLog -Message "Folder structure verified." -Type Info -Function $thisFunction
    }

    # Check there is only a single cert in each folder
    foreach ($folder in $folders) {
        Set-PFXPlacement -path $folder.fullname -certConfig $certConfig
    }
}

function Invoke-AzsCertificateValidation {
    <#
    .SYNOPSIS
        Invoke-Microsoft.AzureStack.CertificateValidation is a standalone wrapper for "certchecker"
    .DESCRIPTION
        Either invokes certificate validation for Azure Stack public certificates or
        import/export routine to correct Azure Stack public certificates
    .EXAMPLE
        $pfxPassword = Read-Host -Prompt "Enter PFX Password" -AsSecureString
        $certificateValidationParams = @{
            CertificateType          = 'Deployment'
            certificatepath          = "$ENV:USERPROFILE\Documents\AzureStack\Certificates\Deployment"
            pfxPassword              = $pfxPassword
            RegionName               = 'east'
            ExternalFQDN             = 'azurestack.contoso.com'
            IdentitySystem           = 'AAD'
        }
        Invoke-AzsCertificateValidation @certificateValidationParams
        Validates multiple certificates are ready for Azure Stack Deployment and Secret Rotation.
    .EXAMPLE
        $pfxPassword = Read-Host -Prompt "Enter PFX Password" -AsSecureString
        $certificateValidationParams = @{
            CertificateType          = 'Deployment'
            certificatepath          = "$ENV:USERPROFILE\Documents\AzureStack\Certificates\Deployment"
            pfxPassword              = $pfxPassword
            DeploymentDataJSONPath   = "$ENV:USERPROFILE\Documents\AzureStack\DeploymentData.json"
        }
        Invoke-AzsCertificateValidation @certificateValidationParams
        Validates multiple certificates are ready for Azure Stack Deployment and Secret Rotation using the DeploymentData.json.
    .EXAMPLE
        $pfxPassword = Read-Host -Prompt "Enter PFX Password" -AsSecureString
        $certificateValidationParams = @{
            CertificateType          = 'AppServices'
            certificatepath          = "$ENV:USERPROFILE\Documents\AzureStack\Certificates\AppServices"
            pfxPassword              = $pfxPassword
            RegionName               = 'east'
            ExternalFQDN             = 'azurestack.contoso.com'
        }
        Invoke-AzsCertificateValidation @certificateValidationParams
        Validates multiple Certificates are ready for AppServices and Azure Stack.  Requires certificates in folders DefaultDomain, API, Publishing, Identity respectively.
    .EXAMPLE
        $pfxPassword = Read-Host -Prompt "Enter PFX Password" -AsSecureString
        $certificateValidationParams = @{
            CertificateType          = 'IoTHub'
            certificatepath          = "$ENV:USERPROFILE\Documents\AzureStack\Certificates\IoTHub"
            pfxPassword              = $pfxPassword
            RegionName               = 'east'
            ExternalFQDN             = 'azurestack.contoso.com'
        }
        Invoke-AzsCertificateValidation @certificateValidationParams
        Validates single Certificates are ready for IoTHub and Azure Stack. Also applicable to EventHubs, DBAdapter and DataboxEdge certificate types.
    .EXAMPLE
        $customCertConfig = @{
            'NWTradersRP' = @{
                DNSName = @('*.nwtraders','admin.nwtraders')
                KeyLength = 4096
            }
            'TailSpinRP' = @{
                DNSName = @('*.tailspin')
                HashAlgorithm = 'SHA386'
            }
        }

        $certificateValidationParams = @{
            CustomCertConfig         = $customCertConfig
            certificatepath          = "$ENV:USERPROFILE\Documents\AzureStack\Certificates\CustomRPs"
            pfxPassword              = $pfxPassword
            RegionName               = 'east'
            ExternalFQDN             = 'azurestack.contoso.com'
        }
        Invoke-AzsCertificateValidation @certificateValidationParams
        Validates multiple Certificates. Each single certificates should be placed in a subfolder (of CertificatePath) named the same as the key in the custom hashtable e.g. NWTraderRP and TailSpinRP as in the example.
    .EXAMPLE
        $pfxPassword = Read-Host -Prompt "Enter PFX Password" -AsSecureString
        $certificateValidationParams = @{
            CertificateType          = 'AzureStackEdgeDevice'
            DeviceName               = 'DBG-KARB2NP5J'
            NodeSerialNumber         = 'WIN-KARB2NP5J3O'
            certificatepath          = "$ENV:USERPROFILE\Documents\AzureStack\Certificates\AzureStackEdgeDevice"
            pfxPassword              = $pfxPassword
            ExternalFQDN             = 'azurestack.contoso.com'
        }
        Invoke-AzsCertificateValidation @certificateValidationParams
        Validates multiple certificates are ready for Azure Stack Edge device certificates.
    .PARAMETER CertificateType
        Specifies the Azure Stack certificate type to generate a request for e.g. Deployment, AppServices, EventHubs, IoTHub etc.
    .PARAMETER CertificatePath
        Path to directory structure for Azure Stack Public Certificates.
        The path given for this parameter is expected to contain one of the following sets of sub-directories, each with a single pfx certificate:
        Identity System AAD:
            ACSBlob, ACSQueue, ACSTable, Admin Portal, ARM Admin, ARM Public, KeyVault, KeyVaultInternal, Public Portal
        Identity System ADFS:
            ADFS, Graph, ACSBlob, ACSQueue, ACSTable, Admin Portal, ARM Admin, ARM Public, KeyVault, KeyVaultInternal, Public Portal
    .PARAMETER pfxPassword
        A securestring containing a single password that is common across all certificates
    .PARAMETER deploymentDataJSONPath
        Specifies the Azure Stack deployment deployment data JSON configuration file. Generally only available to the deployment team.
    .PARAMETER ExternalFQDN
        Specifies the Azure Stack deployment's External FQDN, also aliased as ExternalFQDN and ExternalDomainName, must be valid DNSHostName
    .PARAMETER RegionName
        Specifies the Azure Stack deployment's region name when deploymentdata.json is not used, must be alphanumeric.
    .PARAMETER DeviceName
        Specifies the Device Name of an Azure Stack Edge device.
    .PARAMETER NodeSerialNumber
        Specifies the node serial number(s) of an Azure Stack Edge device.
    .PARAMETER IdentitySystem
        Specifies the Azure Stack deployment's Identity System valid values, AAD or ADFS, for Azure Active Directory and Active Directory Federated Services respectively
    .PARAMETER CustomCertConfig
        Specifies a custom hashtable for custom validation. Minimum required info: @{'CertificateName' = @{DNSName= @('*.rpnamespace')}} where DNSName declared everything left of region.domain.com.
    .PARAMETER CleanReport
        Specifies whether to purge the existing report and start again with a clean report. Execution history and validation data is lost for all Readiness Checker validations.
    .PARAMETER OutputPath
        Specifies custom path to save Readiness JSON report and Verbose log file.
    .LINK
        Deployment Certificate Validation - https://aka.ms/AzsValidateCerts
        PaaS Certificate Validation - https://aka.ms/AzsValidatePaaSCerts
        Azure Stack Readiness Checker Tool - https://aka.ms/AzsReadinessChecker
    #>
    [CmdletBinding()]
    [Alias("Start-CertChecker", "Start-AzsCertChecker", "Start-AzureStackCertChecker", "CertChecker", "Invoke-AzureStackCertificateValidation")]
    Param(
        [Parameter(Mandatory = $true, HelpMessage = "Specify the Azure Stack certificate type to generate a request")]
        [ArgumentCompleter({Get-AzsCertificateTypes | Sort-Object})]
        [ValidateScript({$_ -in (Get-AzsCertificateTypes)})]
        [string]
        $CertificateType,

        [Parameter(Mandatory=$true,HelpMessage="Enter Path to Certificates Directory")]
        [ValidateScript( {Test-Path $_ -PathType Container})]
        [string]
        $CertificatePath,

        [ValidatePattern('(?# Region must be alphanumeric)^[a-zA-Z0-9]+$')]
        [string]
        $RegionName,

        [Alias("ExternalDomainName", "FQDN")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        [string]
        $ExternalFQDN,

        [Parameter(Mandatory = $true, HelpMessage = "Enter Password for PFX Certificates as a secure string" )]
        [ValidateScript({`
            Test-PasswordLength -MinimumCharactersInPassword 8 -Password $PSITEM -CredentialDescription 'pfxPassword'
            Test-PasswordComplexity -Password $PSITEM -CredentialDescription 'pfxPassword'
        })]
        [securestring]
        $pfxPassword,

        [ValidateScript( {Test-Path $_ -Include *.json})]
        [string]
        $deploymentDataJSONPath,

        [Parameter(HelpMessage="Enter Azure Stack Edge Device Name")]
        [string]
        $DeviceName,

        [Parameter(HelpMessage="Enter Azure Stack Edge Node Serial Number")]
        [string[]]
        $NodeSerialNumber,

        [Parameter(HelpMessage="Enter Azure Stack Hub deployment identity system, AAD or ADFS.")]
        [ValidateSet('AAD', 'ADFS')]
        [string]
        $IdentitySystem,

        [hashtable]
        $customCertConfig,

        [Parameter(HelpMessage = "Directory path for log and report output")]
        [string]$OutputPath = "$ENV:TEMP\AzsReadinessChecker",

        [Parameter(HelpMessage = "Remove all previous progress and create a clean report")]
        [switch]$CleanReport = $false
    )
    process {
        try {
            $thisFunction = $MyInvocation.MyCommand.Name
            $GLOBAL:OutputPath = $OutputPath
            # Get/Clean Existing Report
            Import-Module $PSScriptRoot\..\Microsoft.AzureStack.ReadinessChecker.Reporting.psm1 -Force
            Write-Header -invocation $MyInvocation -params $PSBoundParameters
            $readinessReport = Get-AzsReadinessProgress -clean:$CleanReport
            $readinessReport = Add-AzsReadinessCheckerJob -report $readinessReport

            # Ensure we are elevated
            if (Test-Elevation)
            {
                Write-AzsReadinessLog -Message ("Powershell running as Administrator. Continuing.") -Type Info
            }
            else
            {
                Write-AzsReadinessLog -Message ("Running as administrator is required for this operation.  `nPlease restart PowerShell as Administrator and retry.") -Type Error -toScreen
                Write-AzsReadinessLog -Message ("This is because certificate validation must load sensitive key material in order to validate all required certificate attributes.") -Type Error -toScreen
                throw "This operation requires elevation."
            }

            # Check the user provided appropriate parameters
            # NodeSerialNumber is AzureStackEdgeDevice
            if ($certificateType -eq 'AzureStackEdgeDevice' -and !$NodeSerialNumber) {
                throw "CertificateType is $certificateType and NodeSerialNumber not provided. Please re-run providing -NodeSerialNumber and the appropriate value for your system."
            }

            if ($deploymentDataJSONPath) {
                # detect deployment type, get region name and fqdn, and set useADFS flag and directory name
                $deploymentDataJSON = ConvertTo-DeploymentData -path $deploymentDataJSONPath
                $RegionName = $deploymentDataJSON.DeploymentData.RegionName
                $externalFQDN = $deploymentDataJSON.DeploymentData.ExternalDomainFQDN
                if ($deploymentDataJSON.DeploymentData.UseAdfs) {
                    $UseADFS = $true
                    $dirName = 'ADFS'
                }
                elseif ($deploymentDataJSON.DeploymentData.InfraAzureEnvironment) {
                    $UseADFS = $false
                    $dirName = 'AAD'
                }
                else {
                    Write-Error -message "Failed to parse identity store in DeploymentJSON"
                }
            }
            else {
                switch ($IdentitySystem) {
                    'ADFS' { $UseADFS = $true; $dirName = 'ADFS' }
                    'AAD' { $UseADFS = $false; $dirName = 'AAD' }
                }
            }

            # Join RegionName and ExternalFQDN
            if ($regionName -and $CertificateType -ne 'AzureStackEdgeDevice') {
                    $ExternalFQDN = "{0}" -f (($regionName,$ExternalFQDN) -join '.')
            }

            # Get certificate Config
            if ($customCertConfig) {
                # Test custom cert structure
                $customCertConfig = Test-CustomCertConfig -customCertConfig $customCertConfig
                if (-not $customCertConfig) {
                    Write-AzsReadinessLog -Message "Please correct the custom certificate configuration and retry." -Type Error -Function $thisFunction -toScreen
                    break
                }
                $certConfig = $customCertConfig
            }
            else {
                # Get declared configs
                $CertificateType = $PSBoundParameters.CertificateType
                $certificateConfigDataFile = Import-PowerShellDataFile -Path $PSScriptRoot\Microsoft.AzureStack.CertificateConfig.psd1
                $certConfig = $certificateConfigDataFile.CertificateTypes[$certificateType]
                if (-not $UseADFS) {
                    $certConfig.Remove('Graph')
                    $certConfig.Remove('ADFS')
                }
            }

            # Add support for multiple multi node Edge device  (NodeSerialNumbers)
            # Split them in to their own folders
            if ($certificateType -in 'AzureStackEdgeDevice' -and $NodeSerialNumber.count -gt 1) {
                Write-AzsReadinessLog -Message "Configuring multi-node Edge device validation. Finding DNS matches for nodeserialnumbers in PFXs present" -Type Info
                Import-Module $PSScriptRoot\PublicCertHelper.psm1 -Force
                $num = 0
                $PSBoundParameters.nodeSerialNumber | ForEach-Object {
                    $newNode = $certConfig.node.Clone()
                    $nodeKey = "Node{0:d2}" -f $num
                    $certConfig.Add($nodeKey,$newNode)
                    $certConfig[$nodeKey].DnsName = $PSITEM
                    $num++

                    $edgeNodePfxs = Get-ChildItem -Path $CertificatePath\Node -filter *.pfx
                    foreach ($edgeNodePfx in $edgeNodePfxs) {
                        $certificate = Get-PFXData -FilePath $edgeNodePfx.fullname -Password $pfxPassword | Select-Object -ExpandProperty EndEntityCertificates
                        $testDNSNames = Test-DNSNames -cert $Certificate -ExpectedDomain $ExternalFQDN -certConfig $certConfig[$nodeKey]
                        if ($testDNSNames.Result -eq 'OK') {
                            # copy pfx
                            Write-AzsReadinessLog -Message "DNS match found for $PSITEM." -Type Info
                            New-Item -Path "$CertificatePath\$nodeKey" -Force -ItemType Directory | Out-Null
                            Copy-Item -Path $edgeNodePfx.FullName -Destination ("{0}\{1}\{2}" -f $CertificatePath,$nodeKey,$edgeNodePfx.Name)
                            break
                        }
                        else {
                            Write-AzsReadinessLog -Message "DNS match not found for $PSITEM. Ensure all required Node certificates are in Node folder" -Type Error
                        }
                    }
                }

                if ((Get-ChildItem -path $CertificatePath\Node*).count -ne ($num + 1)) {
                    Write-AzsReadinessLog "Ensure all required Node certificates are in Node folder"  -Type Error -ToScreen
                    throw "Ensure all required Node certificates are in Node folder"
                }
                # Finally remove the Node from the config
                $certConfig.remove('Node')
                # Backup a previous execution instead of overwriting and move the original directory to TEMP for the during of the validation
                if (Test-Path $ENV:Temp\AzsReadinessChecker\Node) {
                    Move-Item -Path $ENV:Temp\AzsReadinessChecker\Node -Destination ("{0}{1}" -f "$ENV:Temp\AzsReadinessChecker\Node",(Get-Date -f 'yyyyMMddHHmmss')) -Force
                }
                Move-Item -Path $CertificatePath\Node -Destination $ENV:Temp\AzsReadinessChecker\Node -Force
            }

            # Validate certificate placement (single cert in one folder for single certs, multiple correctly named folders for multiple certs (e.g. infra/AppServices))
            Test-AzsCertificatePlacement -UseADFS:$UseADFS -certificatePath $CertificatePath -certConfig $certConfig

            #Validate any certificates
            Write-Log -Message ("Starting Azure Stack {0} Certificate Validation {1} " -f $certificateType[0],$mod.Version) -Type Info -Function $thisfunction -toScreen
            $TestAzsCertificatesResults = foreach ($key in $certConfig.keys) {
                # Handle SANs for Azure Stack Edge certificates with DeviceName and Node serial numbers instead of regionname and fqdn
                # Append region & fqdn to dnsname for the rest
                Write-AzsReadinessLog -Message ("Getting pfx content {0}" -f $certConfig.$key.pfxPath) -Type Info -Function $thisFunction
                if ((Get-Command Get-Content).Parameters.AsByteStream) {
                    [byte[]]$pfxBinary = Get-Content -Path $certConfig.$key.pfxPath -AsByteStream
                }
                else {
                    [byte[]]$pfxBinary = Get-Content -Path $certConfig.$key.pfxPath -Encoding Byte
                }
                if (-not $pfxBinary) {
                    Write-AzsReadinessLog -Message ("Invalid PFX {0}" -f $certConfig.$key.pfxPath) -Type Error -Function $thisFunction
                }
                # Handle SANs for AzureStackEdgeDevice appliance certificates with DeviceName and NodeSerialNumbers
                # Append region & fqdn to dnsname for the rest
                $AzureStackEdgeDeviceApplianceCertificates = $certificateConfigDataFile.CertificateTypes.AzureStackEdgeDevice.Keys + `
                                                                $certificateConfigDataFile.CertificateTypes.AzureStackEdgeVPN.Keys
                if ($key -in $AzureStackEdgeDeviceApplianceCertificates) {
                    $certConfig.$key.DNSName = $certConfig.$key.DNSName | Foreach-Object { `
                        $PSITEM.replace('[[DeviceName]]',$DeviceName).replace('[[NodeSerialNumber]]',$NodeSerialNumber)
                    } | Sort-Object
                    $TestAzsRPCertificatesResult = Test-AzsCertificate -CertificateBinary $pfxBinary -CertificatePassword $pfxPassword -ExpectedDomainFQDN $externalFQDN -certConfig $certConfig.$key
                }
                else {
                    $TestAzsRPCertificatesResult = Test-AzsCertificate -CertificateBinary $pfxBinary -CertificatePassword $pfxPassword -ExpectedDomainFQDN $externalFQDN -certConfig $certConfig.$key
                }
                $TestAzsRPCertificatesResult
            }
            # Copy the log certchecker log for now, until migration can occur.
            Copy-AzsReadinessLogging -ComponentLogFile CertChecker

            # Write results to readiness report
            $readinessReport.CertificateValidation.$certificateType = $TestAzsCertificatesResults
            $readinessReport = Close-AzsReadinessCheckerJob -report $readinessReport
            $readinessReport.CertificateValidation.$certificateType = Test-CertificateReuse -validationResult $readinessReport.CertificateValidation.$certificateType
        }
        catch {
            Write-AzsReadinessLog -message ("Certificate Validation failed with error: {0}" -f $_.exception.message) -Type Error
            throw
        }
        finally {
            Write-AzsReadinessProgress -report $readinessReport
            Write-AzsReadinessReport -report $readinessReport
            Write-Footer -invocation $MyInvocation

            # Restore users original folders
            if ($certificateType -in 'AzureStackEdgeDevice' -and $NodeSerialNumber.count -gt 1) {
                Move-Item $ENV:TEMP\AzsReadinessChecker\Node -Destination $CertificatePath\Node -ErrorAction SilentlyContinue
                $NodeTempPath = Get-ChildItem -Path $CertificatePath -Filter Node* -Directory | Where-Object Name -ne 'Node' | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
            }
        }
    }
}

function Repair-AzsPfxCertificate {
    <#
    .SYNOPSIS
        Re-package PFX files to remediate common packaging problems
    .DESCRIPTION
        Import PFX into local machine store, export the package ensuring chain export, encryption usage etc
    .EXAMPLE
        PS C:\> Repair-AzsPfxCertificate -PfxPassword $pfxPassword -PfxPath .\certificates\ACSBlob\ACSBlob.pfx -ExportPFXPath .\certificates\ACSBlob\ACSBlob_new.pfx
        Import ACSBlob PFX and re-exports it to the same folder with a new name.
    .PARAMETER PfxPassword
        Specifies the password associated with PFX certificate files.
    .PARAMETER PfxPath
        Specifies the path to a problematic certificate that requires import/export routine to fix, as indicated by certificate validation in this tool
    .PARAMETER ExportPFXPath
        Specifies the destination path for the resultant PFX file from import/export routine.
    .PARAMETER OutputPath
        Specifies custom path to save Readiness JSON report and Verbose log file.
    .LINK
        Remediate common issues for Azure Stack PKI certificates - https://aka.ms/AzsRemediateCerts
        Azure Stack Readiness Checker Tool - https://aka.ms/AzsReadinessChecker
    #>
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $false, HelpMessage = "Enter Password for PFX Certificates as a secure string")]
        [ValidateScript({`
            Test-PasswordLength -MinimumCharactersInPassword 8 -Password $PSITEM -CredentialDescription 'pfxPassword'
            Test-PasswordComplexity -Password $PSITEM -CredentialDescription 'pfxPassword'
        })]
        [securestring]
        $pfxPassword,

        [Parameter(Mandatory = $true, HelpMessage = "Path to PFX on disk", ParameterSetName = "ImportExport")]
        [ValidateScript( {Test-Path $_ -Include *.pfx -PathType Leaf})]
        [string]
        $pfxPath,

        [Parameter(Mandatory = $true, HelpMessage = "Destination Path for PFX export", ParameterSetName = "ImportExport")]
        [ValidateScript( {Test-Path -Path (split-path -Path $_ -Parent)})]
        [string]
        $ExportPFXPath,

        [Parameter(HelpMessage = "Directory path for log")]
        [string]$OutputPath = "$ENV:TEMP\AzsReadinessChecker"
    )

    $thisFunction = $MyInvocation.MyCommand.Name
    $GLOBAL:OutputPath = $OutputPath
    Import-Module $PSScriptRoot\..\Microsoft.AzureStack.ReadinessChecker.Reporting.psm1 -Force
    Write-Header -invocation $MyInvocation -params $PSBoundParameters

    # Ensure we are elevated
    if (Test-Elevation)
    {
        Write-AzsReadinessLog -Message ("Powershell running as Administrator. Continuing.") -Type Info
    }
    else
    {
        Write-AzsReadinessLog -Message ("Running as administrator is required for this operation.  `nPlease restart PowerShell as Administrator and retry.") -Type Error -toScreen
        Write-AzsReadinessLog -Message ("This is because sensitive key material must be accessed in order to re-package certificates.") -Type Error -toScreen
        throw "This operation requires elevation."
    }

    Write-AzsReadinessLog -Message ("Starting Azure Stack Certificate Import/Export") -Type Info -Function $thisfunction -toScreen
    Write-AzsReadinessLog -Message "Importing PFX $pfxPath into Local Machine Store" -Type Info -Function $thisfunction -toScreen
    $certificate = Import-AzsCertificate -pfxPath $pfxPath -pfxPassword $pfxPassword
    if (-not $certificate) {
        Write-AzsReadinessLog -Message "Import Failed. Please review log." -Type Error -Function $thisfunction -toScreen
    }
    else {
        Write-AzsReadinessLog -Message "Exporting certificate to $exportPFXPath" -Type Info -Function $thisfunction -toScreen
        Export-AzsCertificate -filePath $ExportPFXPath -certPath $certificate -pfxPassword $pfxPassword
        Write-AzsReadinessLog -Message "Export complete. Removing certificate from the local machine store." -Type Info -Function $thisfunction -toScreen
        Remove-Item $certificate.pspath -Force
        if (-not (Test-Path $certificate.pspath)) {
            Write-AzsReadinessLog -Message "Removal complete." -Type Info -Function $thisfunction -toScreen
        }
        else {
            Write-AzsReadinessLog -Message ("Removal incomplete. Please manually remove {0}." -f $certificate.pspath) -Type Warning -Function $thisfunction -toScreen
        }
    }
    Copy-AzsReadinessLogging -ComponentLogFile CertChecker
    Write-Footer -invocation $MyInvocation
}

function Set-PFXPlacement {
    # checks for a single certificate and sets pfxPath in the certConfig
    param ($path,$certConfig)
    $thisFunction = $MyInvocation.MyCommand.Name
    $pfxfiles = Get-ChildItem $path -Filter *.pfx -ErrorAction SilentlyContinue
    if ($pfxfiles.count -ne 1) {
        Write-AzsReadinessLog -Message ("The certificate path '{0}' should only contain 1 PFX certificate. {1} PFX files found.  `nEnsure all certificate folders only contain a single certificate." -f $path, $pfxfiles.count) -Type Error -Function $thisFunction -toScreen
        break
    }
    else {
        Write-AzsReadinessLog -Message ("Single PFX found with name '{0}'. Setting pfxPath in certConfig." -f $pfxfiles.FullName) -Type Info -Function $thisFunction
        $certConfig.$($pfxfiles.Directory.Name).pfxPath = $pfxfiles.FullName
    }
}

function Test-CustomCertConfig {
    param ([hashtable]$customCertConfig)
    if ($customCertConfig -isnot [HashTable]) {
        Write-AzsReadinessLog -Message ("Custom Cert Config is not a valid hashtable. `nExpecting at least: `n@{'CertificateName' = @{DNSName= @('*.certificate.domain')}}.") -Type Error -Function $thisfunction -toScreen
        return $false
    }

    foreach ($customCertName in $customCertConfig.Keys) {
        $customCertHash = $customCertConfig.$customCertName
        # Check its a hashtable
        if ($customCertHash -isnot [HashTable]) {
            Write-AzsReadinessLog -Message ("Custom Cert {0} is not a valid hashtable. `nExpecting at least: `n@{'CertificateName' = @{DNSName= @('*.certificate.domain')}}." -f $customCertName) -Type Error -Function $thisfunction -toScreen
            return $false
        }
        else {
            $hashToString = ($customCertHash.GetEnumerator() | ForEach-Object { "$($_.Key)=$($_.Value)" }) -join '; '
            Write-AzsReadinessLog -Message ("Custom Cert is a valid hashtable @{{{0} = @{{{1}}}}}" -f $customCertName,$hashToString) -Type Info -Function $thisfunction
        }

        # Check it has at least a DNSName
        if (-not $customCertHash.DNSName){
            Write-AzsReadinessLog -Message ("Custom cert {0} must contain at least DNSName key. Exiting." -f $customCertName)  -Type Error -Function $thisfunction -toScreen
            return $false
        }
        else {
            Write-AzsReadinessLog -Message ("Custom Config {0} contains DNSName to check" -f $customCertName) -Type Info -Function $thisfunction
        }

        # Add include and exclude test if they're not present
        if (-not $customCertHash.IncludeTests) {
            Write-AzsReadinessLog -Message ("Custom Config {0}. Adding IncludeTests as 'All'" -f $customCertName) -Type Info -Function $thisfunction
            $customCertConfig.$customCertName.IncludeTests = 'All'
        }
        else {
            Write-AzsReadinessLog -Message ("Custom Config {0}. IncludeTests contains {1}" -f $customCertName, $customCertHash.IncludeTests) -Type Info -Function $thisfunction
        }
        if (-not $customCertHash.ExcludeTests) {
            Write-AzsReadinessLog -Message ("Custom Config {0}. Adding ExcludeTests as 'CNG Key'" -f $customCertName) -Type Info -Function $thisfunction
            $customCertConfig.$customCertName.ExcludeTests = 'CNG Key'
        }
        else {
            Write-AzsReadinessLog -Message ("Custom Config {0}. ExcludeTests contains {1}" -f $customCertName, $customCertHash.ExcludeTests) -Type Info -Function $thisfunction
        }
    }
    $customCertConfig
}

function New-AzsCertificateFolder {
    <#
    .SYNOPSIS
        Create folder structure Azure Stack Certificates
    .DESCRIPTION
        Create folder structure Azure Stack Certificates
    .EXAMPLE
        New-AzsCertificateFolder -certificateType Deployment -IdentitySystem AAD -OutputPath C:\SecureStore\AzureStack
        Create Deployment Folders in C:\SecureStore\AzureStack\Deployment
    .EXAMPLE
        New-AzsCertificateFolder -certificateType AppServices -OutputPath C:\SecureStore\AzureStack
        Create AppServices Folders in C:\SecureStore\AzureStack\AppServices
    .EXAMPLE
        New-AzsCertificateFolder -certificateType EventHubs -OutputPath C:\SecureStore\AzureStack
        Create EventHubs Folders in C:\SecureStore\AzureStack\EventHubs
    .EXAMPLE
        New-AzsCertificateFolder -certificateType IoTHub -OutputPath C:\SecureStore\AzureStack
        Create IoTHub Folders in C:\SecureStore\AzureStack\IoTHub
    .EXAMPLE
        New-AzsCertificateFolder -certificateType DataboxEdge -OutputPath C:\SecureStore\AzureStack
        Create DataboxEdge Folders in C:\SecureStore\AzureStack\DataboxEdge
    .EXAMPLE
        New-AzsCertificateFolder -certificateType AzureStackEdgeDevice -OutputPath C:\SecureStore\AzureStack
        Create Azure Stack Edge Folders in C:\SecureStore\AzureStack\AzureStackEdgeDevice
    .EXAMPLE
        New-AzsCertificateFolder -certificateType DBAdapter -OutputPath C:\SecureStore\AzureStack
        Create DBAdapter Folders in C:\SecureStore\AzureStack\DBAdapter
    #>
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
    param (
        [Parameter(Mandatory = $true, HelpMessage = "Specify the Azure Stack certificate type to generate a request")]
        [ArgumentCompleter({Get-AzsCertificateTypes | Sort-Object})]
        [ValidateScript({$_ -in (Get-AzsCertificateTypes)})]
        [string]
        $CertificateType,

        [Parameter(Mandatory = $true, HelpMessage = "Destination Path for Certificate")]
        [string]$OutputPath,

        [Parameter(Mandatory = $false, HelpMessage = "Enter Azure Stack Identity System (AAD or ADFS) when generating deployment certificates")]
        [ValidateSet('AAD', 'ADFS')]
        [string]$IdentitySystem
    )
    process
    {
        try {
            # Get Certificate Config
            $certificateConfigDataFile = Import-PowerShellDataFile -Path $PSScriptRoot\..\CertificateValidation\Microsoft.AzureStack.CertificateConfig.psd1
            $certificateConfig = $certificateConfigDataFile.CertificateTypes[$CertificateType]
            if ($certificateType -eq 'Deployment' -AND $IdentitySystem -ne 'ADFS') {
                        $certificateConfig.Remove('Graph')
                        $certificateConfig.Remove('ADFS')
            }

            # Create Folder Structure
            if ($certificateConfig.Keys.count -eq 1) {
                $destination = $OutputPath
            }
            else{
                $destination = Join-Path -Path $OutputPath -ChildPath $CertificateType
            }
            Foreach ($key in $certificateConfig.keys) {
                $newFolder = Join-Path -Path $destination -ChildPath $key
                New-Item -Path $newFolder -ItemType Directory -Force
            }
        }
        catch {
            throw $_.exception
        }
    }
}

function Get-AzsCertificateTypes {
    param ([string[]]$certificateTypeExclusions = @('Hardware'))
    $certificateConfigDataFile = Import-PowerShellDataFile -Path $PSScriptRoot\Microsoft.AzureStack.CertificateConfig.psd1
    $certificateTypes = $certificateConfigDataFile.CertificateTypes | Select-Object -ExpandProperty Keys | Where-Object {$PSITEM -notin $certificateTypeExclusions}
    $certificateTypes + 'Custom' | Sort-Object
}

function Invoke-AzsEdgeDeviceCertificateValidation {
    <#
    .SYNOPSIS
        Run certificate validation for Azure Stack Edge Device Certificates
    .DESCRIPTION
        Calls Invoke-AzsCertificateValidation with neccessary parameters to validate Azure Stack Edge Device certificates
    .EXAMPLE
        $pfxPassword = Read-Host -Prompt "Enter PFX Password" -AsSecureString
        $certificateValidationParams = @{
            DeviceName               = 'DBG-KARB2NP5J'
            NodeSerialNumber         = 'WIN-KARB2NP5J3O'
            certificatepath          = "$ENV:USERPROFILE\Documents\AzureStack\Certificates\AzureStackEdgeDevice"
            pfxPassword              = $pfxPassword
            ExternalFQDN             = 'azurestack.contoso.com'
        }
        Invoke-AzsEdgeDeviceCertificateValidation @certificateValidationParams
        Run certificate validation for Azure Stack Edge Device Certificates
    .EXAMPLE
        $pfxPassword = Read-Host -Prompt "Enter PFX Password" -AsSecureString
        $certificateValidationParams = @{
            DeviceName               = 'DBG-KARB2NP5J'
            NodeSerialNumber         = 'WIN-KARB2NP5J3O','WIN-GBWB7ML4K9O'
            certificatepath          = "$ENV:USERPROFILE\Documents\AzureStack\Certificates\AzureStackEdgeDevice"
            pfxPassword              = $pfxPassword
            ExternalFQDN             = 'azurestack.contoso.com'
        }
        Invoke-AzsEdgeDeviceCertificateValidation @certificateValidationParams
        Run certificate validation for multi-node Azure Stack Edge Device Certificates
    .PARAMETER CertificatePath
        Path to directory structure for Azure Stack Edge Device Certificates.
    .PARAMETER pfxPassword
        A securestring containing a single password that is common across all certificates
    .PARAMETER ExternalFQDN
        Specifies the Azure Stack's External FQDN, also aliased as ExternalFQDN and ExternalDomainName, must be valid DNSHostName. Does not need to be resolved.
    .PARAMETER DeviceName
        Specifies the Device Name of an Azure Stack Edge device.
    .PARAMETER NodeSerialNumber
        Specifies the node serial number(s) of an Azure Stack Edge device.
    .PARAMETER CleanReport
        Specifies whether to purge the existing report and start again with a clean report. Execution history and validation data is lost for all Readiness Checker validations.
    .PARAMETER OutputPath
        Specifies custom path to save Readiness JSON report and Verbose log file.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true,HelpMessage="Enter Path to Certificates Directory")]
        [ValidateScript( {Test-Path $_ -PathType Container})]
        [string]
        $certificatepath,

        [Parameter(Mandatory = $true, HelpMessage = "Enter Password for PFX Certificates as a secure string" )]
        [securestring]
        $pfxPassword,

        [Parameter(Mandatory=$true, HelpMessage="Enter Azure Stack External FQDN")]
        [Alias("ExternalDomainName", "FQDN")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        [string]
        $ExternalFQDN,

        [Parameter(Mandatory=$true, HelpMessage="Enter the Device Name of an Azure Stack Edge device.")]
        [string]
        $DeviceName,

        [Parameter(Mandatory=$true, HelpMessage="Enter the Node Serial Number of an Azure Stack Edge device.")]
        [string[]]
        $NodeSerialNumber,

        [Parameter(HelpMessage = "Directory path for log and report output")]
        [string]$OutputPath = "$ENV:TEMP\AzsReadinessChecker",

        [Parameter(HelpMessage = "Remove all previous progress and create a clean report")]
        [switch]$CleanReport = $false
    )
    Invoke-AzsCertificateValidation @PSBoundParameters -CertificateType AzureStackEdgeDevice
}

function Invoke-AzsEdgeVPNCertificateValidation {
    <#
    .SYNOPSIS
        Run certificate validation for Azure Stack Edge VPN Certificates
    .DESCRIPTION
        Calls Invoke-AzsCertificateValidation with neccessary parameters to validate Azure Stack Edge VPN certificates
    .EXAMPLE
        $pfxPassword = Read-Host -Prompt "Enter PFX Password" -AsSecureString
        $certificateValidationParams = @{
            certificatePath = "$ENV:USERPROFILE\Documents\AzureStack\Certificates\AzureStackEdgeVPN"
            pfxPassword = $pfxPassword
            ExternalFQDN = "azurestackedge.contoso.com"
        }
        Invoke-AzsEdgeVPNCertificateValidation @certificateValidationParams
        Run certificate validation for Azure Stack Edge VPN Certificates
    .PARAMETER CertificatePath
        Path to directory structure for Azure Stack Edge VPN Certificates.
    .PARAMETER pfxPassword
        A securestring containing a single password that is common across all certificates
    .PARAMETER ExternalFQDN
        Specifies the Azure Stack's External FQDN, also aliased as ExternalFQDN and ExternalDomainName, must be valid DNSHostName. Does not need to be resolved.
    .PARAMETER CleanReport
        Specifies whether to purge the existing report and start again with a clean report. Execution history and validation data is lost for all Readiness Checker validations.
    .PARAMETER OutputPath
        Specifies custom path to save Readiness JSON report and Verbose log file.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true,HelpMessage="Enter Path to Certificates Directory")]
        [ValidateScript( {Test-Path $_ -PathType Container})]
        [string]
        $certificatepath,

        [Parameter(Mandatory = $true, HelpMessage = "Enter Password for PFX Certificates as a secure string" )]
        [securestring]
        $pfxPassword,

        [Parameter(Mandatory=$true, HelpMessage="Enter Azure Stack External FQDN")]
        [Alias("ExternalDomainName", "FQDN")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        [string]
        $ExternalFQDN,

        [Parameter(HelpMessage = "Directory path for log and report output")]
        [string]
        $OutputPath = "$ENV:TEMP\AzsReadinessChecker",

        [Parameter(HelpMessage = "Remove all previous progress and create a clean report")]
        [switch]
        $CleanReport = $false
    )
    Invoke-AzsCertificateValidation @PSBoundParameters -CertificateType AzureStackEdgeVPN
}

function Invoke-AzsHubDeploymentCertificateValidation {
    <#
    .SYNOPSIS
        Run certificate validation for Azure Stack Hub Deployment/Infrastructure Certificates
    .DESCRIPTION
        Calls Invoke-AzsCertificateValidation with neccessary parameters to validate Azure Stack Hub Deployment certificates
    .EXAMPLE
        $pfxPassword = Read-Host -Prompt "Enter PFX Password" -AsSecureString
        $certificateValidationParams = @{
            certificatepath          = "$ENV:USERPROFILE\Documents\AzureStack\Certificates\Deployment"
            pfxPassword              = $pfxPassword
            RegionName               = 'east'
            ExternalFQDN             = 'azurestack.contoso.com'
            IdentitySystem           = 'AAD'
        }
        Invoke-AzsHubDeploymentCertificateValidation @certificateValidationParams
        Run certificate validation for Azure Stack Hub Deployment/Infrastructure Certificates
    .EXAMPLE
        $pfxPassword = Read-Host -Prompt "Enter PFX Password" -AsSecureString
        $certificateValidationParams = @{
            certificatepath          = "$ENV:USERPROFILE\Documents\AzureStack\Certificates\Deployment"
            pfxPassword              = $pfxPassword
            DeploymentDataJSONPath   = "$ENV:USERPROFILE\Documents\AzureStack\DeploymentData.json"
        }
        Invoke-AzsHubDeploymentCertificateValidation @certificateValidationParams
        Run certificate validation for Azure Stack Hub Deployment/Infrastructure Certificates using deploymentdata.json from deployment team.
    .PARAMETER CertificatePath
        Path to directory structure for Azure Stack Hub Deployment Certificates.
    .PARAMETER pfxPassword
        A securestring containing a single password that is common across all certificates
    .PARAMETER deploymentDataJSONPath
        Specifies the Azure Stack Hub deployment data JSON configuration file. This enables the deployment team and/or system integrators
        to validate directly against the deployment asset that seeds deployment. Replaces user input for region name, external FQDN and identity system (if applicable).
    .PARAMETER ExternalFQDN
        Specifies the Azure Stack deployment's External FQDN, also aliased as ExternalFQDN and ExternalDomainName, must be valid DNSHostName
    .PARAMETER RegionName
        Specifies the Azure Stack deployment's region name when deploymentdata.json is not used, must be alphanumeric.
     .PARAMETER IdentitySystem
        Specifies the Azure Stack deployment's Identity System valid values, AAD or ADFS, for Azure Active Directory and Active Directory Federated Services respectively
    .PARAMETER CleanReport
        Specifies whether to purge the existing report and start again with a clean report. Execution history and validation data is lost for all Readiness Checker validations.
    .PARAMETER OutputPath
        Specifies custom path to save Readiness JSON report and Verbose log file.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true, HelpMessage="Enter Path to Certificates Directory")]
        [ValidateScript( {Test-Path $_ -PathType Container})]
        [string]
        $certificatepath,

        [Parameter(Mandatory = $true, HelpMessage = "Enter Password for PFX Certificates as a secure string" )]
        [securestring]
        $pfxPassword,

        [Parameter(Mandatory=$true, ParameterSetName = "User", HelpMessage="Enter Azure Stack External FQDN")]
        [Alias("ExternalDomainName", "FQDN")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        [string]
        $ExternalFQDN,

        [Parameter(Mandatory=$true, ParameterSetName = "User", HelpMessage="Enter Azure Stack Hub Region Name")]
        [ValidatePattern('(?# Region must be alphanumeric)^[a-zA-Z0-9]+$')]
        [string]
        $RegionName,

        [Parameter(Mandatory=$true, ParameterSetName = "User", HelpMessage="Enter Azure Stack Hub deployment identity system, AAD or ADFS.")]
        [ValidateSet('AAD', 'ADFS')]
        [string]
        $IdentitySystem,

        [Parameter(Mandatory = $true, ParameterSetName = "JSON", HelpMessage = "Enter Path to DeploymentData.json")]
        [ValidateScript( {Test-Path $_ -Include *.json})]
        [string]
        $deploymentDataJSONPath,

        [Parameter(HelpMessage = "Directory path for log and report output")]
        [string]
        $OutputPath = "$ENV:TEMP\AzsReadinessChecker",

        [Parameter(HelpMessage = "Remove all previous progress and create a clean report")]
        [switch]
        $CleanReport = $false
    )
    Invoke-AzsCertificateValidation @PSBoundParameters -CertificateType Deployment
}

function Invoke-AzsHubAppServicesCertificateValidation {
    <#
    .SYNOPSIS
        Run certificate validation for Azure Stack Hub AppServices Resource Provider Certificates
    .DESCRIPTION
        Calls Invoke-AzsCertificateValidation with neccessary parameters to validate Azure Stack Hub AppServices certificates
    .EXAMPLE
        $pfxPassword = Read-Host -Prompt "Enter PFX Password" -AsSecureString
        $certificateValidationParams = @{
            certificatepath          = "$ENV:USERPROFILE\Documents\AzureStack\Certificates\AppServices"
            pfxPassword              = $pfxPassword
            RegionName               = 'east'
            ExternalFQDN             = 'azurestack.contoso.com'
        }
        Invoke-AzsHubAppServicesCertificateValidation @certificateValidationParams
        Run certificate validation for Azure Stack Hub AppServices Resource Provider Certificates
    .EXAMPLE
        $pfxPassword = Read-Host -Prompt "Enter PFX Password" -AsSecureString
        $certificateValidationParams = @{
            certificatepath          = "$ENV:USERPROFILE\Documents\AzureStack\Certificates\AppServices"
            pfxPassword              = $pfxPassword
            DeploymentDataJSONPath   = "$ENV:USERPROFILE\Documents\AzureStack\DeploymentData.json"
        }
        Invoke-AzsHubAppServicesCertificateValidation @certificateValidationParams
        Run certificate validation for Azure Stack Hub AppServices Resource Provider Certificates using deploymentdata.json from Deployment team.
    .PARAMETER CertificatePath
        Path to directory structure for Azure Stack Hub AppServices Certificates. Should contain sub folders named API, DefaultDomain, Identity and Publishing with
        appropriate certificates placed in each. Use New-AzsCertificateFolder -certificateType AppServices for help with generation.
    .PARAMETER pfxPassword
        A securestring containing a single password that is common across all certificates
    .PARAMETER ExternalFQDN
        Specifies the Azure Stack deployment's External FQDN, also aliased as ExternalFQDN and ExternalDomainName, must be valid DNSHostName
    .PARAMETER RegionName
        Specifies the Azure Stack deployment's region name, must be alphanumeric.
    .PARAMETER deploymentDataJSONPath
        Specifies the Azure Stack Hub deployment data JSON configuration file. This enables the deployment team and/or system integrators
        to validate directly against the deployment asset that seeds deployment. Replaces user input for region name, external FQDN and identity system (if applicable).
    .PARAMETER CleanReport
        Specifies whether to purge the existing report and start again with a clean report. Execution history and validation data is lost for all Readiness Checker validations.
    .PARAMETER OutputPath
        Specifies custom path to save Readiness JSON report and Verbose log file.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true, HelpMessage="Enter Path to Certificates Directory")]
        [ValidateScript( {Test-Path $_ -PathType Container})]
        [string]
        $certificatepath,

        [Parameter(Mandatory = $true, HelpMessage = "Enter Password for PFX Certificates as a secure string" )]
        [securestring]
        $pfxPassword,

        [Parameter(Mandatory=$true, ParameterSetName = "User", HelpMessage="Enter Azure Stack External FQDN")]
        [Alias("ExternalDomainName", "FQDN")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        [string]
        $ExternalFQDN,

        [Parameter(Mandatory=$true, ParameterSetName = "User", HelpMessage="Enter Azure Stack Hub Region Name")]
        [ValidatePattern('(?# Region must be alphanumeric)^[a-zA-Z0-9]+$')]
        [string]
        $RegionName,

        [Parameter(Mandatory = $true, ParameterSetName = "JSON", HelpMessage = "Enter Path to DeploymentData.json")]
        [ValidateScript( {Test-Path $_ -Include *.json})]
        [string]
        $deploymentDataJSONPath,

        [Parameter(HelpMessage = "Directory path for log and report output")]
        [string]
        $OutputPath = "$ENV:TEMP\AzsReadinessChecker",

        [Parameter(HelpMessage = "Remove all previous progress and create a clean report")]
        [switch]
        $CleanReport = $false
    )
    Invoke-AzsCertificateValidation @PSBoundParameters -CertificateType AppServices
}

function Invoke-AzsHubEventHubsCertificateValidation {
    <#
    .SYNOPSIS
        Run certificate validation for Azure Stack Hub EventHubs Resource Provider Certificates
    .DESCRIPTION
        Calls Invoke-AzsCertificateValidation with neccessary parameters to validate Azure Stack Hub EventHubs certificates
    .EXAMPLE
        $pfxPassword = Read-Host -Prompt "Enter PFX Password" -AsSecureString
        $certificateValidationParams = @{
            certificatepath          = "$ENV:USERPROFILE\Documents\AzureStack\Certificates\EventHubs"
            pfxPassword              = $pfxPassword
            RegionName               = 'east'
            ExternalFQDN             = 'azurestack.contoso.com'
        }
        Invoke-AzsHubEventHubsCertificateValidation @certificateValidationParams
        Run certificate validation for Azure Stack Hub EventHubs Resource Provider Certificates
    .EXAMPLE
        $pfxPassword = Read-Host -Prompt "Enter PFX Password" -AsSecureString
        $certificateValidationParams = @{
            certificatepath          = "$ENV:USERPROFILE\Documents\AzureStack\Certificates\EventHubs"
            pfxPassword              = $pfxPassword
            DeploymentDataJSONPath   = "$ENV:USERPROFILE\Documents\AzureStack\DeploymentData.json"
        }
        Invoke-AzsHubEventHubsCertificateValidation @certificateValidationParams
        Run certificate validation for Azure Stack Hub EventHubs Resource Provider Certificates with deploymentdata.json from Deployment team.
    .PARAMETER CertificatePath
        Path to directory structure for Azure Stack Hub EventHubs Certificates.
    .PARAMETER pfxPassword
        A securestring containing a single password that is common across all certificates
    .PARAMETER ExternalFQDN
        Specifies the Azure Stack deployment's External FQDN, also aliased as ExternalFQDN and ExternalDomainName, must be valid DNSHostName
    .PARAMETER RegionName
        Specifies the Azure Stack deployment's region name, must be alphanumeric.
    .PARAMETER deploymentDataJSONPath
        Specifies the Azure Stack Hub deployment data JSON configuration file. This enables the deployment team and/or system integrators
        to validate directly against the deployment asset that seeds deployment. Replaces user input for region name, external FQDN and identity system (if applicable).
    .PARAMETER CleanReport
        Specifies whether to purge the existing report and start again with a clean report. Execution history and validation data is lost for all Readiness Checker validations.
    .PARAMETER OutputPath
        Specifies custom path to save Readiness JSON report and Verbose log file.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true, HelpMessage="Enter Path to Certificates Directory")]
        [ValidateScript( {Test-Path $_ -PathType Container})]
        [string]
        $certificatepath,

        [Parameter(Mandatory = $true, HelpMessage = "Enter Password for PFX Certificates as a secure string" )]
        [securestring]
        $pfxPassword,

        [Parameter(Mandatory=$true, ParameterSetName = "User", HelpMessage="Enter Azure Stack External FQDN")]
        [Alias("ExternalDomainName", "FQDN")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        [string]
        $ExternalFQDN,

        [Parameter(Mandatory=$true, ParameterSetName = "User", HelpMessage="Enter Azure Stack Hub Region Name")]
        [ValidatePattern('(?# Region must be alphanumeric)^[a-zA-Z0-9]+$')]
        [string]
        $RegionName,

        [Parameter(Mandatory = $true, ParameterSetName = "JSON", HelpMessage = "Enter Path to DeploymentData.json")]
        [ValidateScript( {Test-Path $_ -Include *.json})]
        [string]
        $deploymentDataJSONPath,

        [Parameter(HelpMessage = "Directory path for log and report output")]
        [string]
        $OutputPath = "$ENV:TEMP\AzsReadinessChecker",

        [Parameter(HelpMessage = "Remove all previous progress and create a clean report")]
        [switch]
        $CleanReport = $false
    )
    Invoke-AzsCertificateValidation @PSBoundParameters -CertificateType EventHubs
}

function Invoke-AzsHubIoTHubCertificateValidation {
    <#
    .SYNOPSIS
        Run certificate validation for Azure Stack Hub IoTHub Resource Provider Certificates
    .DESCRIPTION
        Calls Invoke-AzsCertificateValidation with neccessary parameters to validate Azure Stack Hub IoTHub certificates
    .EXAMPLE
        $pfxPassword = Read-Host -Prompt "Enter PFX Password" -AsSecureString
        $certificateValidationParams = @{
            certificatepath          = "$ENV:USERPROFILE\Documents\AzureStack\Certificates\IoTHub"
            pfxPassword              = $pfxPassword
            RegionName               = 'east'
            ExternalFQDN             = 'azurestack.contoso.com'
        }
        Invoke-AzsHubIoTHubCertificateValidation @certificateValidationParams
        Run certificate validation for Azure Stack Hub IoTHub Resource Provider Certificates
    .EXAMPLE
        $pfxPassword = Read-Host -Prompt "Enter PFX Password" -AsSecureString
        $certificateValidationParams = @{
            certificatepath          = "$ENV:USERPROFILE\Documents\AzureStack\Certificates\IoTHub"
            pfxPassword              = $pfxPassword
            DeploymentDataJSONPath   = "$ENV:USERPROFILE\Documents\AzureStack\DeploymentData.json"
        }
        Invoke-AzsHubIoTHubCertificateValidation @certificateValidationParams
        Run certificate validation for Azure Stack Hub IoTHub Resource Provider Certificates using deploymentdata.json from Deployment team.
    .PARAMETER CertificatePath
        Path to directory structure for Azure Stack Hub IoTHub Certificates.
    .PARAMETER pfxPassword
        A securestring containing a single password that is common across all certificates
    .PARAMETER ExternalFQDN
        Specifies the Azure Stack deployment's External FQDN, also aliased as ExternalFQDN and ExternalDomainName, must be valid DNSHostName
    .PARAMETER RegionName
        Specifies the Azure Stack deployment's region name, must be alphanumeric.
    .PARAMETER deploymentDataJSONPath
        Specifies the Azure Stack Hub deployment data JSON configuration file. This enables the deployment team and/or system integrators
        to validate directly against the deployment asset that seeds deployment. Replaces user input for region name, external FQDN and identity system (if applicable).
    .PARAMETER CleanReport
        Specifies whether to purge the existing report and start again with a clean report. Execution history and validation data is lost for all Readiness Checker validations.
    .PARAMETER OutputPath
        Specifies custom path to save Readiness JSON report and Verbose log file.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true, HelpMessage="Enter Path to Certificates Directory")]
        [ValidateScript( {Test-Path $_ -PathType Container})]
        [string]
        $certificatepath,

        [Parameter(Mandatory = $true, HelpMessage = "Enter Password for PFX Certificates as a secure string" )]
        [securestring]
        $pfxPassword,

        [Parameter(Mandatory=$true, ParameterSetName = "User", HelpMessage="Enter Azure Stack External FQDN")]
        [Alias("ExternalDomainName", "FQDN")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        [string]
        $ExternalFQDN,

        [Parameter(Mandatory=$true, ParameterSetName = "User", HelpMessage="Enter Azure Stack Hub Region Name")]
        [ValidatePattern('(?# Region must be alphanumeric)^[a-zA-Z0-9]+$')]
        [string]
        $RegionName,

        [Parameter(Mandatory = $true, ParameterSetName = "JSON", HelpMessage = "Enter Path to DeploymentData.json")]
        [ValidateScript( {Test-Path $_ -Include *.json})]
        [string]
        $deploymentDataJSONPath,

        [Parameter(HelpMessage = "Directory path for log and report output")]
        [string]
        $OutputPath = "$ENV:TEMP\AzsReadinessChecker",

        [Parameter(HelpMessage = "Remove all previous progress and create a clean report")]
        [switch]
        $CleanReport = $false
    )
    Invoke-AzsCertificateValidation @PSBoundParameters -CertificateType IoTHub
}

function Invoke-AzsHubDBAdapterCertificateValidation {
    <#
    .SYNOPSIS
        Run certificate validation for Azure Stack Hub DBAdapter Resource Provider Certificates
    .DESCRIPTION
        Calls Invoke-AzsCertificateValidation with neccessary parameters to validate Azure Stack Hub DBAdapter certificates
    .EXAMPLE
        $pfxPassword = Read-Host -Prompt "Enter PFX Password" -AsSecureString
        $certificateValidationParams = @{
            certificatepath          = "$ENV:USERPROFILE\Documents\AzureStack\Certificates\DBAdapter"
            pfxPassword              = $pfxPassword
            RegionName               = 'east'
            ExternalFQDN             = 'azurestack.contoso.com'
        }
        Invoke-AzsHubDBAdapterCertificateValidation @certificateValidationParams
        Run certificate validation for Azure Stack Hub DBAdapter Resource Provider Certificates
    .EXAMPLE
        $pfxPassword = Read-Host -Prompt "Enter PFX Password" -AsSecureString
        $certificateValidationParams = @{
            certificatepath          = "$ENV:USERPROFILE\Documents\AzureStack\Certificates\DBAdapter"
            pfxPassword              = $pfxPassword
            DeploymentDataJSONPath   = "$ENV:USERPROFILE\Documents\AzureStack\DeploymentData.json"
        }
        Invoke-AzsHubDBAdapterCertificateValidation @certificateValidationParams
        Run certificate validation for Azure Stack Hub DBAdapter Resource Provider Certificates using deploymentdata.json from Deployment team.
    .PARAMETER CertificatePath
        Path to directory structure for Azure Stack Hub DBAdapter Certificates.
    .PARAMETER pfxPassword
        A securestring containing a single password that is common across all certificates
    .PARAMETER ExternalFQDN
        Specifies the Azure Stack deployment's External FQDN, also aliased as ExternalFQDN and ExternalDomainName, must be valid DNSHostName
    .PARAMETER RegionName
        Specifies the Azure Stack deployment's region name, must be alphanumeric.
    .PARAMETER deploymentDataJSONPath
        Specifies the Azure Stack Hub deployment data JSON configuration file. This enables the deployment team and/or system integrators
        to validate directly against the deployment asset that seeds deployment. Replaces user input for region name, external FQDN and identity system (if applicable).
    .PARAMETER CleanReport
        Specifies whether to purge the existing report and start again with a clean report. Execution history and validation data is lost for all Readiness Checker validations.
    .PARAMETER OutputPath
        Specifies custom path to save Readiness JSON report and Verbose log file.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true, HelpMessage="Enter Path to Certificates Directory")]
        [ValidateScript( {Test-Path $_ -PathType Container})]
        [string]
        $certificatepath,

        [Parameter(Mandatory = $true, HelpMessage = "Enter Password for PFX Certificates as a secure string" )]
        [securestring]
        $pfxPassword,

        [Parameter(Mandatory=$true, ParameterSetName = "User", HelpMessage="Enter Azure Stack External FQDN")]
        [Alias("ExternalDomainName", "FQDN")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        [string]
        $ExternalFQDN,

        [Parameter(Mandatory=$true, ParameterSetName = "User", HelpMessage="Enter Azure Stack Hub Region Name")]
        [ValidatePattern('(?# Region must be alphanumeric)^[a-zA-Z0-9]+$')]
        [string]
        $RegionName,

        [Parameter(Mandatory = $true, ParameterSetName = "JSON", HelpMessage = "Enter Path to DeploymentData.json")]
        [ValidateScript( {Test-Path $_ -Include *.json})]
        [string]
        $deploymentDataJSONPath,

        [Parameter(HelpMessage = "Directory path for log and report output")]
        [string]
        $OutputPath = "$ENV:TEMP\AzsReadinessChecker",

        [Parameter(HelpMessage = "Remove all previous progress and create a clean report")]
        [switch]
        $CleanReport = $false
    )
    Invoke-AzsCertificateValidation @PSBoundParameters -CertificateType DBAdapter
}

function Invoke-AzsHubDataBoxEdgeCertificateValidation {
    <#
    .SYNOPSIS
        Run certificate validation for Azure Stack Hub Databox Edge Resource Provider Certificates
    .DESCRIPTION
        Calls Invoke-AzsCertificateValidation with neccessary parameters to validate Azure Stack Hub DBAdapter certificates
    .EXAMPLE
        $pfxPassword = Read-Host -Prompt "Enter PFX Password" -AsSecureString
        $certificateValidationParams = @{
            certificatepath          = "$ENV:USERPROFILE\Documents\AzureStack\Certificates\DataboxEdge"
            pfxPassword              = $pfxPassword
            RegionName               = 'east'
            ExternalFQDN             = 'azurestack.contoso.com'
        }
        Invoke-AzsHubDataBoxEdgeCertificateValidation @certificateValidationParams
        Run certificate validation for Azure Stack Hub Databox Edge Resource Provider Certificates
    .EXAMPLE
        $pfxPassword = Read-Host -Prompt "Enter PFX Password" -AsSecureString
        $certificateValidationParams = @{
            certificatepath          = "$ENV:USERPROFILE\Documents\AzureStack\Certificates\DataboxEdge"
            pfxPassword              = $pfxPassword
            DeploymentDataJSONPath   = "$ENV:USERPROFILE\Documents\AzureStack\DeploymentData.json"
        }
        Invoke-AzsHubDataBoxEdgeCertificateValidation @certificateValidationParams
        Run certificate validation for Azure Stack Hub Databox Edge Resource Provider Certificates using deploymentdata.json from Deployment team.
    .PARAMETER CertificatePath
        Path to directory structure for Azure Stack Hub DBAdapter Certificates.
    .PARAMETER pfxPassword
        A securestring containing a single password that is common across all certificates
    .PARAMETER ExternalFQDN
        Specifies the Azure Stack deployment's External FQDN, also aliased as ExternalFQDN and ExternalDomainName, must be valid DNSHostName
    .PARAMETER RegionName
        Specifies the Azure Stack deployment's region name, must be alphanumeric.
    .PARAMETER deploymentDataJSONPath
        Specifies the Azure Stack Hub deployment data JSON configuration file. This enables the deployment team and/or system integrators
        to validate directly against the deployment asset that seeds deployment. Replaces user input for region name, external FQDN and identity system (if applicable).
    .PARAMETER CleanReport
        Specifies whether to purge the existing report and start again with a clean report. Execution history and validation data is lost for all Readiness Checker validations.
    .PARAMETER OutputPath
        Specifies custom path to save Readiness JSON report and Verbose log file.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true, HelpMessage="Enter Path to Certificates Directory")]
        [ValidateScript( {Test-Path $_ -PathType Container})]
        [string]
        $certificatepath,

        [Parameter(Mandatory = $true, HelpMessage = "Enter Password for PFX Certificates as a secure string" )]
        [securestring]
        $pfxPassword,

        [Parameter(Mandatory=$true, ParameterSetName = "User", HelpMessage="Enter Azure Stack External FQDN")]
        [Alias("ExternalDomainName", "FQDN")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        [string]
        $ExternalFQDN,

        [Parameter(Mandatory=$true, ParameterSetName = "User", HelpMessage="Enter Azure Stack Hub Region Name")]
        [ValidatePattern('(?# Region must be alphanumeric)^[a-zA-Z0-9]+$')]
        [string]
        $RegionName,

        [Parameter(Mandatory = $true, ParameterSetName = "JSON", HelpMessage = "Enter Path to DeploymentData.json")]
        [ValidateScript( {Test-Path $_ -Include *.json})]
        [string]
        $deploymentDataJSONPath,

        [Parameter(HelpMessage = "Directory path for log and report output")]
        [string]
        $OutputPath = "$ENV:TEMP\AzsReadinessChecker",

        [Parameter(HelpMessage = "Remove all previous progress and create a clean report")]
        [switch]
        $CleanReport = $false
    )
    Invoke-AzsCertificateValidation @PSBoundParameters -CertificateType DataboxEdge
}

function Invoke-AzsHubAzureContainerRegistryCertificateValidation {
    <#
    .SYNOPSIS
        Run certificate validation for Azure Stack Hub Azure Container Registry Resource Provider Certificates
    .DESCRIPTION
        Calls Invoke-AzsCertificateValidation with neccessary parameters to validate Azure Stack Hub DBAdapter certificates
    .EXAMPLE
        $pfxPassword = Read-Host -Prompt "Enter PFX Password" -AsSecureString
        $certificateValidationParams = @{
            certificatepath          = "$ENV:USERPROFILE\Documents\AzureStack\Certificates\ACR"
            pfxPassword              = $pfxPassword
            RegionName               = 'east'
            ExternalFQDN             = 'azurestack.contoso.com'
        }
        Invoke-AzsHubAzureContainerRegistryCertificateValidation @certificateValidationParams
        Run certificate validation for Azure Stack Azure Container Registry Resource Provider Certificates
    .EXAMPLE
        $pfxPassword = Read-Host -Prompt "Enter PFX Password" -AsSecureString
        $certificateValidationParams = @{
            certificatepath          = "$ENV:USERPROFILE\Documents\AzureStack\Certificates\ACR"
            pfxPassword              = $pfxPassword
            DeploymentDataJSONPath   = "$ENV:USERPROFILE\Documents\AzureStack\DeploymentData.json"
        }
        Invoke-AzsHubAzureContainerRegistryCertificateValidation @certificateValidationParams
        Run certificate validation for Azure Stack Hub Azure Container Registry Resource Provider Certificates using deploymentdata.json from Deployment team.
    .PARAMETER CertificatePath
        Path to directory structure for Azure Stack Hub Azure Container Registry (ACR) Certificates.
    .PARAMETER pfxPassword
        A securestring containing a single password that is common across all certificates
    .PARAMETER ExternalFQDN
        Specifies the Azure Stack deployment's External FQDN, also aliased as ExternalFQDN and ExternalDomainName, must be valid DNSHostName
    .PARAMETER RegionName
        Specifies the Azure Stack deployment's region name, must be alphanumeric.
    .PARAMETER deploymentDataJSONPath
        Specifies the Azure Stack Hub deployment data JSON configuration file. This enables the deployment team and/or system integrators
        to validate directly against the deployment asset that seeds deployment. Replaces user input for region name, external FQDN and identity system (if applicable).
    .PARAMETER CleanReport
        Specifies whether to purge the existing report and start again with a clean report. Execution history and validation data is lost for all Readiness Checker validations.
    .PARAMETER OutputPath
        Specifies custom path to save Readiness JSON report and Verbose log file.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true, HelpMessage="Enter Path to Certificates Directory")]
        [ValidateScript( {Test-Path $_ -PathType Container})]
        [string]
        $certificatepath,

        [Parameter(Mandatory = $true, HelpMessage = "Enter Password for PFX Certificates as a secure string" )]
        [securestring]
        $pfxPassword,

        [Parameter(Mandatory=$true, ParameterSetName = "User", HelpMessage="Enter Azure Stack External FQDN")]
        [Alias("ExternalDomainName", "FQDN")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        [string]
        $ExternalFQDN,

        [Parameter(Mandatory=$true, ParameterSetName = "User", HelpMessage="Enter Azure Stack Hub Region Name")]
        [ValidatePattern('(?# Region must be alphanumeric)^[a-zA-Z0-9]+$')]
        [string]
        $RegionName,

        [Parameter(Mandatory = $true, ParameterSetName = "JSON", HelpMessage = "Enter Path to DeploymentData.json")]
        [ValidateScript( {Test-Path $_ -Include *.json})]
        [string]
        $deploymentDataJSONPath,

        [Parameter(HelpMessage = "Directory path for log and report output")]
        [string]
        $OutputPath = "$ENV:TEMP\AzsReadinessChecker",

        [Parameter(HelpMessage = "Remove all previous progress and create a clean report")]
        [switch]
        $CleanReport = $false
    )
    Invoke-AzsCertificateValidation @PSBoundParameters -CertificateType ACR
}

function Invoke-AzsCustomCertificateValidation {
    <#
    .SYNOPSIS
        Run certificate validation for Custom Certificates.
    .DESCRIPTION
        Calls Invoke-AzsCertificateValidation with neccessary parameters to validate custom certificates, by default attributes will be validated against Azure Stack standards.
    .EXAMPLE
        $pfxPassword = Read-Host -Prompt "Enter PFX Password" -AsSecureString
        $customCertConfig = @{
            'NWTradersRP' = @{
                    DNSName = @('*.nwtraders','admin.nwtraders')
                    KeyLength = 4096
                }
                'TailSpinRP' = @{
                    DNSName = @('*.tailspin')
                    HashAlgorithm = 'SHA386'
                }
            }

            $certificateValidationParams = @{
                CustomCertConfig         = $customCertConfig
                certificatepath          = "$ENV:USERPROFILE\Documents\AzureStack\Certificates\CustomRPs"
                pfxPassword              = $pfxPassword
                ExternalFQDN             = 'east.azurestack.contoso.com'
            }
            Invoke-AzsCustomCertificateValidation @certificateValidationParams
        Validates multiple Certificates. Each single certificates should be placed in a subfolder (of CertificatePath) named the same as the key in the custom hashtable e.g. NWTraderRP and TailSpinRP as in the example.
    .PARAMETER CertificatePath
        Path to directory structure for Azure Stack Hub DBAdapter Certificates.
    .PARAMETER pfxPassword
        A securestring containing a single password that is common across all certificates
    .PARAMETER ExternalFQDN
        Specifies the certificates External FQDN, also aliased as ExternalFQDN and ExternalDomainName, must be valid DNSHostName, optional parameter, DNSName can contain full fqdn, or prefix
    .PARAMETER CustomCertConfig
        Specifies the custom hashtable to check a certificate against.
    .PARAMETER CleanReport
        Specifies whether to purge the existing report and start again with a clean report. Execution history and validation data is lost for all Readiness Checker validations.
    .PARAMETER OutputPath
        Specifies custom path to save Readiness JSON report and Verbose log file.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true, HelpMessage="Enter Path to Certificates Directory")]
        [ValidateScript( {Test-Path $_ -PathType Container})]
        [string]
        $certificatepath,

        [Parameter(Mandatory = $true, HelpMessage = "Enter Password for PFX Certificates as a secure string" )]
        [securestring]
        $pfxPassword,

        [Parameter(Mandatory=$false, ParameterSetName = "User", HelpMessage="Enter External FQDN")]
        [Alias("ExternalDomainName", "FQDN")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        [string]
        $ExternalFQDN,

        [Parameter(Mandatory=$true, HelpMessage="Enter custom hashtable to check a certificate against")]
        [hashtable]
        $customCertConfig,

        [Parameter(HelpMessage = "Directory path for log and report output")]
        [string]
        $OutputPath = "$ENV:TEMP\AzsReadinessChecker",

        [Parameter(HelpMessage = "Remove all previous progress and create a clean report")]
        [switch]
        $CleanReport = $false
    )
    Invoke-AzsCertificateValidation @PSBoundParameters -CertificateType Custom
}
# SIG # Begin signature block
# MIIjkgYJKoZIhvcNAQcCoIIjgzCCI38CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCD5U2sXu6fIYhme
# sjdg9qGFDSjT+zhqJydHs8kD9ucQHaCCDYEwggX/MIID56ADAgECAhMzAAACUosz
# qviV8znbAAAAAAJSMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjEwOTAyMTgzMjU5WhcNMjIwOTAxMTgzMjU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDQ5M+Ps/X7BNuv5B/0I6uoDwj0NJOo1KrVQqO7ggRXccklyTrWL4xMShjIou2I
# sbYnF67wXzVAq5Om4oe+LfzSDOzjcb6ms00gBo0OQaqwQ1BijyJ7NvDf80I1fW9O
# L76Kt0Wpc2zrGhzcHdb7upPrvxvSNNUvxK3sgw7YTt31410vpEp8yfBEl/hd8ZzA
# v47DCgJ5j1zm295s1RVZHNp6MoiQFVOECm4AwK2l28i+YER1JO4IplTH44uvzX9o
# RnJHaMvWzZEpozPy4jNO2DDqbcNs4zh7AWMhE1PWFVA+CHI/En5nASvCvLmuR/t8
# q4bc8XR8QIZJQSp+2U6m2ldNAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUNZJaEUGL2Guwt7ZOAu4efEYXedEw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDY3NTk3MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAFkk3
# uSxkTEBh1NtAl7BivIEsAWdgX1qZ+EdZMYbQKasY6IhSLXRMxF1B3OKdR9K/kccp
# kvNcGl8D7YyYS4mhCUMBR+VLrg3f8PUj38A9V5aiY2/Jok7WZFOAmjPRNNGnyeg7
# l0lTiThFqE+2aOs6+heegqAdelGgNJKRHLWRuhGKuLIw5lkgx9Ky+QvZrn/Ddi8u
# TIgWKp+MGG8xY6PBvvjgt9jQShlnPrZ3UY8Bvwy6rynhXBaV0V0TTL0gEx7eh/K1
# o8Miaru6s/7FyqOLeUS4vTHh9TgBL5DtxCYurXbSBVtL1Fj44+Od/6cmC9mmvrti
# yG709Y3Rd3YdJj2f3GJq7Y7KdWq0QYhatKhBeg4fxjhg0yut2g6aM1mxjNPrE48z
# 6HWCNGu9gMK5ZudldRw4a45Z06Aoktof0CqOyTErvq0YjoE4Xpa0+87T/PVUXNqf
# 7Y+qSU7+9LtLQuMYR4w3cSPjuNusvLf9gBnch5RqM7kaDtYWDgLyB42EfsxeMqwK
# WwA+TVi0HrWRqfSx2olbE56hJcEkMjOSKz3sRuupFCX3UroyYf52L+2iVTrda8XW
# esPG62Mnn3T8AuLfzeJFuAbfOSERx7IFZO92UPoXE1uEjL5skl1yTZB3MubgOA4F
# 8KoRNhviFAEST+nG8c8uIsbZeb08SeYQMqjVEmkwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVZzCCFWMCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAlKLM6r4lfM52wAAAAACUjAN
# BglghkgBZQMEAgEFAKCBrjAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgAlBgjRWC
# vX2XrrPOuIS/GBBmIqW9uI2mkRKXhH2aXaUwQgYKKwYBBAGCNwIBDDE0MDKgFIAS
# AE0AaQBjAHIAbwBzAG8AZgB0oRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQBbJtxFFd1bUhczWxx5TmJpB+rJsfwCcWuhEgzbiX+c
# 9PUpRaSQX+yYLK1TsWzc52VkWqSZYrRpR2MytJiAjZrxG2FZGO4g7GXOtqDtKDUK
# E97oRUoWHY8LdD4i0SE2szKnql94farlJq754Dz56lqYF3Nr4nld2xsvDmu5okue
# qy5vOyG8dCtLXKt2nEWcoX2P5l9ax6uS5bxE91KfxeNBgnp7nyzY2396GftuazEm
# 0gbTzieW0rIOzL3j6guuYpWBwPyZZ/FWPaX4Vh5Btp+zHV8o55RT3zJ3ep9mU8GL
# 6eBpH4tTQ0SRg2bpRV89V4Cq1enCmCZh+EKmPKvjh+LUoYIS8TCCEu0GCisGAQQB
# gjcDAwExghLdMIIS2QYJKoZIhvcNAQcCoIISyjCCEsYCAQMxDzANBglghkgBZQME
# AgEFADCCAVUGCyqGSIb3DQEJEAEEoIIBRASCAUAwggE8AgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEIJzfMdKoc57ms8Fli0RZxFC+JhX1BlmlgzjlU9cS
# bFWFAgZhwMdj884YEzIwMjIwMTA1MTIxMTMxLjIwNlowBIACAfSggdSkgdEwgc4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1p
# Y3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMg
# VFNTIEVTTjo2MEJDLUUzODMtMjYzNTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgU2VydmljZaCCDkQwggT1MIID3aADAgECAhMzAAABWiy5bkQ0y28oAAAA
# AAFaMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MB4XDTIxMDExNDE5MDIxNloXDTIyMDQxMTE5MDIxNlowgc4xCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVy
# YXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo2MEJD
# LUUzODMtMjYzNTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vydmlj
# ZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALC9XBxXDa0nCK70Hf+G
# ih6NxRl1mAhzFJdok8bs3xpJ87TM28rEeHkZAaE+Kb9Gi9UvTpQ3zrEWyWSpIQky
# xv/Wf0cIhA1mJOqyu20TN3l96ZvgzYrzO/rQlPvbKW79oAO4+YFsekQCtrzM9hQo
# S5BYGwPh9Qz66BuSxH9QweywNBQsjkVoikpBxkS+EXSIzpba2afvnRMX7LLe2ery
# c+PlPXmTSOfH1WNykc25u9zo6ZX0gAd4jUpBzdMLnHCtE62bL2PO00cmAJsitqga
# ov+3lFrfd0sPACwTGO9iymlJlb2savwjqSnj5RzG4RxG6rU2i7etbnQTozR73OHM
# GOUCAwEAAaOCARswggEXMB0GA1UdDgQWBBRkcyU/9RyPkn7QBoXZOTQ8wN4xZzAf
# BgNVHSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBH
# hkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNU
# aW1TdGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUF
# BzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0
# YVBDQV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsG
# AQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IBAQAAAG3sfFgbUiw4gWMV8VOxlbIG/CIM
# SiciDtIZnPL84OMN4lJeV5LeJr+HYBcox5ruWZm49K29iBmJv6ViXMtP81pYZ1EF
# M7306Y+zLIh/tS574PeWsHvPD0QOxQ4HOM2GNPvFAdUvo8z5pgV/5E+lPu61uUCI
# BTDESiHO+N7ragqb3METPqRKPLNAJcKPDcalKznmGPlnzY6P1zop/7a90VcBHRKK
# Q/hTvn/8C8Y6b+Mvk5kYJh67KNbVVcuuBWyFSMZTHGenHnuHVg9svH7+lm/V/wIb
# ZUKKJJO0HQmyodySeD/JLC7NNsDYRpFN+29dLRtx0eWyZosJmT8qKbBIMIIGcTCC
# BFmgAwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJv
# b3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1WhcN
# MjUwNzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCASIw
# DQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkdDbx3EYo6IOz8E5f1+n9plGt0
# VBDVpQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMnBDEfQRsalR3OCROOfGEwWbEw
# RA/xYIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeGMoQe
# dGFnkV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8RsEnHSRnEnIaIYqvS2SJUGKx
# Xf13Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v0Ev9buWayrGo8noqCjHw2k4G
# kbaICDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN/LzAyURdXhacAQVPIk0CAwEA
# AaOCAeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ80N7
# fEYbxTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMC
# AYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvX
# zpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20v
# cGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYI
# KwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDCBoAYDVR0g
# AQH/BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYIKwYB
# BQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0AGUA
# bQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAAfmiFEN4sbgmD+BcQM9naOh
# IW+z66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4vceoniXj+bzta1RXCCtRgkQS
# +7lTjMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzymXlK
# kVIArzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8z+0DpZaPWSm8tv0E4XCfMkon
# /VWvL/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVKC5Em4jnsGUpxY517IW3DnKOi
# PPp/fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs9/S/
# fmNZJQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF0M2n0O99g/DhO3EJ3110mCII
# YdqwUB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+YWtvd6mBy6cJrDm77MbL2IK0
# cs0d9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt6o3gMy4SKfXAL1QnIffIrE7a
# KLixqduWsqdCosnPGUFN4Ib5KpqjEWYw07t0MkvfY3v1mYovG8chr1m1rtxEPJdQ
# cdeh0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc1bN+
# NR4Iuto229Nfj950iEkSoYIC0jCCAjsCAQEwgfyhgdSkgdEwgc4xCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBP
# cGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo2
# MEJDLUUzODMtMjYzNTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZaIjCgEBMAcGBSsOAwIaAxUAzIAFmL3GHHWcAJYi3haGwlplGi6ggYMwgYCk
# fjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIF
# AOV/tOIwIhgPMjAyMjAxMDUxMDEwNDJaGA8yMDIyMDEwNjEwMTA0MlowdzA9Bgor
# BgEEAYRZCgQBMS8wLTAKAgUA5X+04gIBADAKAgEAAgImfwIB/zAHAgEAAgIQ1zAK
# AgUA5YEGYgIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIB
# AAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAKSdjiED+vnRIBpp
# ZfQtd6Pz3+KmkXVsUXh7ssMErjXxC7P67o+a8jXy6SCLyLDaqQJ48rAP6RdUsRZl
# /ZUEvdVAB0G3zYzvCChQXyn5PVOxY/yryRQi460BEczCXCBu+zr7IAgQ7IVknWmh
# VOiujLSuQa5sMeOkg/yxKbuIegUMMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTACEzMAAAFaLLluRDTLbygAAAAAAVowDQYJYIZIAWUD
# BAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0B
# CQQxIgQgjshUHv2H+1xCusgsEDqPd1Av8C4GIMzpZTMBfe3Wg+swgfoGCyqGSIb3
# DQEJEAIvMYHqMIHnMIHkMIG9BCCT/KgmdMSy5F0ww4Iar9cmf5Is3pM0hUuIInL5
# bbF/sDCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB
# Wiy5bkQ0y28oAAAAAAFaMCIEIFIChwh74rqvDtBWxJW19RDGHJn+xrmGN+vxHzH7
# B7NnMA0GCSqGSIb3DQEBCwUABIIBALAqLemmtzHettLM8mj+oHi78Bi426wcK98k
# opCfW0UZI1AIuFdJmfM0y+PwQRwECF2VcuHh4vMdjChptKQ/VkJPnaUT5WwnENKU
# x9aX7hFizID6ewFAXGAMBWf6SyVLzOe0bAstihdxzsMOtjwaujTbn1FXl3m65/0I
# YK4zvim4nG5pdz1aPDDoNGuwS11vgKeEu/ItQ5ONpMxu4cb7foAYPMcP7nPsA/Yg
# JemrsrawQ2uEqPgrjx91DwczZZGSTsmv3J2BBJDrcj88BzlboVagb+hdbYXDgPTw
# aqg6BPnzGKlpzwUNNUXUcM/pTS0f3rVnL/F9+gYxRGtDbEcVC2g=
# SIG # End signature block
