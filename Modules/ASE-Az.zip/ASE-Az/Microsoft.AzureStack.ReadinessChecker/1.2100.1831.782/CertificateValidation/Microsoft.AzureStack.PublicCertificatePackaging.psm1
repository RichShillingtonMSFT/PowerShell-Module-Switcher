Import-Module $PSScriptRoot\PublicCertHelper.psm1 -Force -DisableNameChecking
$certificateConfigDataFile = Import-PowerShellDataFile -Path $PSScriptRoot\Microsoft.AzureStack.CertificateConfig.psd1

class AzsCertificate {
    [string]$ExportFilePath
    [string]$RelativePath
    [string]$FilePath
    [string]$FileName
    [string]$FileExtension
    [secureString]$pfxPassword
    [string]$certificateStore
    [string]$CertificateStorePath
    [System.Security.Cryptography.X509Certificates.X509Certificate2]$certificate
    [bool]$CertificateGroupComplete
    [string]$certificateGroup
    [string]$certificateGroupItem
    [string]$certificateType
    [string]$ErrorMessage
    [bool]$SingleCertificate
}

function ConvertTo-AzsPFX {
    <#
    .SYNOPSIS
        Converts certificates to Azure Stack certificates by packaging them with their private keys and chains into structured folders.
    .DESCRIPTION
        Reads directory for (configurable) file extensions suitable for certificate import (non recursive)
        Imports each file found in (configurable) cert store, defaults to localmachine/Trust, must be localmachine.
        Resolves certificates against Azure Stack config
        Exports certificates as PFX with chain into well structured path e.g. ExportPath\FQDN\CertificateType\Certificate
        ExportPath is user specified, FQDN is read from certificate, CertificateType is read from config, Certificate is read from config.
    .EXAMPLE
        $ExportPath = "$env:USERPROFILE\Documents\AzureStack"
        $pfxPassword = Read-Host -AsSecureString -Prompt "PFX Password"
        ConvertTo-AzsPFX -Path $env:USERPROFILE\Documents\AzureStackCSR -pfxPassword $pfxPassword -ExportPath $ExportPath
        Read certificate files from documents\AzureStack and output PFXs in a folder structure for Azs.
    .PARAMETER Path
        Path containing certificate files to be converted.
    .PARAMETER Filter
        The type of certificate files to convert, valid values: CER, CERT, SST, P7B, PFX.
    .PARAMETER PfxPassword
        Password for inbound and outbound PFX files. If inbound PFX does not have a password, this should be omitted and a prompt will appear during export.
    .PARAMETER ExternalFQDN
        ExternalFQDN of certificates, can be omitted, and will be detected, in the case of detection failure, use this parameter.
    .PARAMETER ExportPath
        Folder where certificate will be exported.
    .PARAMETER CertificateStore
        Certificate store used for packaging, must been a valid path in the local machine store.
    .PARAMETER DisableValidation
        Disables validation after the packaging is complete.
    .PARAMETER DisableChainCheck
        Do not check the chain as part of pre-packaging checks. Time consuming and not a true test of the Azure Stack PKI trust posture if ran externally.
    .PARAMETER OutputPath
        Directory path for log and report output.
    .PARAMETER CleanReport
        Remove all previous progress and create a clean report.
    .NOTES
        Ensure Certificates private key and chain is present in the local machine store when targetting public certificate files.
        Only target one ExternalFQDN at a time.
    #>
    [cmdletbinding(SupportsShouldProcess, ConfirmImpact = 'Medium')]
    param (
        [Parameter(Mandatory = $true, HelpMessage = 'Path containing certificate files to be converted.')]
        [ValidateScript( { Test-Path $PSITEM -PathType Container <# provide valid folder #> })]
        [string]
        $Path,

        [Parameter(Mandatory = $false, HelpMessage = 'The type of certificate files to convert, valid values: CER, CERT, SST, P7B, PFX.')]
        [ValidateSet('CER', 'CERT', 'SST', 'P7B', 'PFX')]
        [string]
        $Filter = 'CER',

        [Parameter(Mandatory = $false, HelpMessage = 'Password for inbound and outbound PFX files. If inbound PFX does not have a password, this should be omitted and a prompt will appear during export.')]
        [SecureString]
        $PfxPassword,

        [Parameter(Mandatory = $false, HelpMessage = 'ExternalFQDN of certificates, can be omitted, and will be detected, in the case of detection failure, use this parameter.')]
        [ValidateScript( { [System.Uri]::CheckHostName($PSITEM) -eq 'dns' <# provide valid fully qualified domain name #> })]
        [string]
        $ExternalFQDN,

        [Parameter(Mandatory = $true, HelpMessage = 'Folder where certificate will be exported.')]
        [ValidateScript( { Test-Path $PSITEM -PathType Container -IsValid <# provide valid path #> })]
        [string]
        $ExportPath,

        [Parameter(Mandatory = $false, HelpMessage = 'Certificate store used for packaging, must been a valid path in the local machine store.')]
        [ValidateScript( { Test-Path $PSITEM -PathType Container; $PSITEM -match "Cert:\LocalMachine\" <# provide valid localmachine certificate store #> })]
        [string]
        $certificateStore = "Cert:\LocalMachine\Trust",

        [Parameter(Mandatory = $false, HelpMessage = "Do not run validation after converting certificates.")]
        [switch]
        $DisableValidation,

        [Parameter(Mandatory = $false, HelpMessage = "Do not check the chain as part of pre-packaging checks.")]
        [switch]
        $DisableChainCheck,

        [Parameter(Mandatory = $false, HelpMessage = "Directory path for log and report output.")]
        [string]$OutputPath = "$ENV:TEMP\AzsReadinessChecker",

        [Parameter(Mandatory = $false, HelpMessage = "Remove all previous progress and create a clean report.")]
        [switch]$CleanReport = $false
    )
    $thisFunction = $MyInvocation.MyCommand.Name
    $GLOBAL:OutputPath = $OutputPath
    Import-Module $PSScriptRoot\..\Microsoft.AzureStack.ReadinessChecker.Reporting.psm1 -Force
    Import-Module $PSScriptRoot\..\Microsoft.AzureStack.ReadinessChecker.Utilities.psm1 -Force
    Write-Header -invocation $MyInvocation -params $PSBoundParameters

    # Ensure we are elevated
    if (Test-Elevation)
    {
        Write-AzsReadinessLog -Message ("Powershell running as Administrator. Continuing.") -Type Info
    }
    else
    {
        Write-AzsReadinessLog -Message ("Running as administrator is required for this operation.  `nPlease restart PowerShell as Administrator and retry.") -Type Error -toScreen
        Write-AzsReadinessLog -Message ("This is because this operation must load sensitive key material in order to read certificate attributes.") -Type Error -toScreen
        throw "This operation requires elevation."
    }

    Write-AzsReadinessLog -message ("`nStage 1: Scanning Certificates" -f $path, $filter) -Type Info -Function $thisFunction -toScreen
    $CertificateFiles = Get-ChildItem -Path $path -Filter ('*.{0}' -f $filter)

    if (-not $CertificateFiles) {
        Write-AzsReadinessLog -message "No certificate files detected in $path with filter: $filter. `nEnsure the path to the certificates is valid. `nExiting" -Type Error -Function $thisFunction -toScreen
        break
    }
    else {
        Write-AzsReadinessLog -message ("`tPath: {0} Filter: {1} Certificate count: {2}" -f $path, $filter, $CertificateFiles.count) -Type Info -Function $thisFunction -toScreen
    }

    # Create array for potential Azure Stack certificates
    $azsCertificates = @()
    $azsCertificates = $CertificateFiles | ForEach-Object { `
            $hash = @{
            FilePath         = $PSItem.FullName
            FileName         = $PSItem.Name
            FileExtension    = $PSItem.Extension
            PfxPassword      = $pfxPassword
            CertificateStore = $certificateStore
        }
        New-Object -TypeName AzsCertificate -Property $hash
    }

    $azsCertificates | Foreach-Object { Write-AzsReadinessLog -message ("`t{0}" -f $PSItem.FileName) -Type Info -Function $thisFunction -toScreen }

    # import/retrieve certificate
    $index = 0
    $azsCertificates | ForEach-Object { `
            # import cert as cert or pfx
            if ($PSItem.FileExtension -match 'pfx') {
            Write-AzsReadinessLog -message ("Inspecting PFX {0} using password supplied" -f $PSItem.FileName) -Type Info -Function $thisFunction
            try {
                $PSItem.Certificate = Import-AzsCertificate -pfxPath $PSItem.FilePath -pfxPassword $PSItem.pfxPassword -certificateStore $PSItem.certificateStore
            }
            catch {
                $azsCertificates[$index].ErrorMessage = "Importfailure: {0}" -f $_.Exception.Message
            }
        }
        else {
            # expect the pkey to be available locally for this path
            Write-AzsReadinessLog -message ("Importing {0}" -f $PSItem.FileName) -Type Info -Function $thisFunction
            try {
                $importResult = Import-Certificate -FilePath $PSItem.FilePath -CertStoreLocation $PSItem.certificateStore
                if ($importResult -is [System.Security.Cryptography.X509Certificates.X509Certificate2]) {
                    $ImportedLeafCertificate = $importResult
                }
                else {
                    # in the case of p7b the full chain will be passed back, we only want to return the leaf.
                    $ImportedLeafCertificate = $importResult | Where-Object { $_.Subject -notin $importResult.issuer }
                    if ($ImportedLeafCertificate -isnot [System.Security.Cryptography.X509Certificates.X509Certificate2]) {
                        throw "Unexpected import result. Check contents of $($PSItem.FileName)"
                    }
                }
                $PSItem.Certificate = $ImportedLeafCertificate
            }
            catch {
                $azsCertificates[$index].ErrorMessage = "ImportFailure: {0}" -f $_.Exception.Message
            }
        }
        $index++
    }

    if (-not $ExternalFQDN) {
        $ExternalFQDNDetection = @()
        $ExternalFQDNDetection += $azsCertificates.Certificate | ForEach-Object {Get-AzsExternalDomain -certificate $PSItem -dnsNamesFromConfig (Get-AzsCertificateDnsNamesFromConfig)} | Sort-Object | Get-Unique
        if ([System.Uri]::CheckHostName($ExternalFQDNDetection) -eq 'dns') {
            $ExternalFQDN = $ExternalFQDNDetection
            Write-AzsReadinessLog -message ("`nDetected ExternalFQDN: {0}" -f $ExternalFQDN) -Type Info -Function $thisFunction -toScreen
        }
        else {
            Write-AzsReadinessLog -message ("Detection of ExternalFQDN failed. Names detected: {0}" -f ($ExternalFQDNDetection -join ',')) -Type Error -Function $thisFunction -toScreen
            Write-AzsReadinessLog -message ("Please retry using -externalFQDN to target a single external namespace and continue.") -Type Error -Function $thisFunction -toScreen
            break
        }
    }

    # detect potential certificate usage
    # set a flag for single certificate, so we can avoid nested folders
    $matchedAzsCertificates = @()
    $matchedAzsCertificates += foreach ($azsCertificate in $azsCertificates) {
        [array] $relativePaths = Get-AzsCertificateRelativePath -certificate $azsCertificate.certificate -ExternalFQDN $ExternalFQDN -Verbose
        if ($relativePaths.count -eq 0) {
            Write-AzsReadinessLog -message ("`nCertificate {0} did not match any AzureStack namespace requirements with the specified an ExternalFQDN. Skipping certificate." -f $azsCertificate.FileName) -Type Warning -Function $thisFunction -toScreen
        }
        elseif ($relativePaths.count -eq 1) {
            $azsCertificate.RelativePath = $relativePaths.relativePath
            $azsCertificate.SingleCertificate = $relativePaths.SingleCertificate
            Write-AzsReadinessLog -message ("`nCertificate {0} matched {1}. Single Certifcate requirement: {2}" -f $azsCertificate.FileName, $azsCertificate.RelativePath, $azsCertificate.SingleCertificate) -Type Info -Function $thisFunction
            Write-Output $azsCertificate
        }
        elseif ($relativePaths.count -gt 1) {
            foreach ($relativePath in $relativePaths) {
                # create a new certificate for each matched certificate
                $NewAzsCertificate = New-Object -TypeName AzsCertificate
                foreach ($property in $azsCertificate.psobject.Properties.Name) {
                    $NewAzsCertificate.$property = $azsCertificate.$property
                }
                $NewAzsCertificate.RelativePath = $relativePath.RelativePath
                $NewAzsCertificate.SingleCertificate = $relativePath.SingleCertificate
                Write-AzsReadinessLog -message ("`nCertificate {0} matched {1}." -f $NewAzsCertificate.FileName, $NewAzsCertificate.RelativePath) -Type Info -Function $thisFunction
                Write-Output $NewAzsCertificate
            }
        }
        else {
            throw "unexpected error"
        }

    }

    Write-AzsReadinessLog -message ("`nStage 2: Exporting Certificates") -Type Info -Function $thisFunction -toScreen
    if (-not $pfxPassword) {
        $pfxPassword = Read-Host "Provide PFX Password for export" -AsSecureString
        $matchedAzsCertificates | ForEach-Object { if (-not $PSItem.pfxPassword) { $PSItem.pfxPassword = $pfxPassword }}
    }
    # keep track of what has been processed to avoid collisions
    $relativePathsProcessed = @()
    # export certificate if it doesn't collide with anything else (existing file or previous)
    $matchedAzsCertificates | ForEach-Object { `
        $PSItem.certificateGroupItem = Split-Path $PSItem.RelativePath -leaf
        $PSItem.CertificateStorePath = (Join-Path $PSItem.certificateStore $PSItem.Certificate.Thumbprint)
        # ExportFilePath should be nulled if export unsuccesful
        if ($PSItem.SingleCertificate) {
            $relativeFileName = ("{0}\{1}.pfx" -f (Split-Path -Path $PSItem.RelativePath -Parent), ($PSItem.certificateGroupItem.replace(' ', '')))
        }
        else {
            $relativeFileName = ("{0}\{1}.pfx" -f $PSItem.RelativePath, ($PSItem.certificateGroupItem.replace(' ', '')))
        }
        $ExportFilePath = Join-Path $ExportPath $relativeFileName
        Write-AzsReadinessLog -message ("Preparing to export {0} as {1}" -f $PSItem.FileName, $PSItem.RelativePath) -Type Info -Function $thisFunction

        # If path exists, move on
        # TO DO: AppServices DefaultDomain cert can overwrite
        $pathExists = Test-Path $ExportFilePath

        $CertCollision = $PSItem.RelativePath -in $relativePathsProcessed
        $relativePathsProcessed = $PSItem.RelativePath

        if ($pathExists -or $CertCollision) {
            $errorMsg = "Path exists detected: {0}. Certificate Collision detected: {1}. Cannot export to {2}" -f $pathExists, $CertCollision, $relativeFileName
            Write-AzsReadinessLog -message $ErrorMsg -Type Warning -Function $thisFunction
            $ExportFilePath = $null
        }
        else {
            try {
                $partialValidation = PartialValidation -certificate (Get-Item $PSItem.CertificateStorePath) -disableChainCheck:$disableChainCheck
                if (-not (Test-Path (Split-Path -Path $ExportFilePath -Parent))) {
                    New-Item (Split-Path -Path $ExportFilePath -Parent) -ItemType Directory -Force | Out-Null
                }
                Export-AzsCertificate -filePath $ExportFilePath -certPath $PSItem.CertificateStorePath -pfxPassword $PSItem.pfxPassword
                Write-AzsReadinessLog -message "`t$relativeFileName" -Type Info -Function $thisFunction -toScreen
            }
            catch {
                Write-AzsReadinessLog -Message ("Unable to export certificate {0}. Error: {1}" -f $PSItem.RelativePath, $_.exception.message) -Type Error -Function $thisFunction
                $errorMsg = $_.exception.message
                $ExportFilePath = $null
            }
        }
        $PSItem.ExportFilePath = $ExportFilePath
        $PSItem.ErrorMessage = $errorMsg
    }

    # Cleaning certificate array and reporting discards
    $discardedCertificates = $matchedAzsCertificates | Where-Object { -not $_.ExportFilePath }
    if ($discardedCertificates) {
        Write-AzsReadinessLog -Message "`nWARNING: Following certificates will be discarded:" -Type Warning -Function $thisFunction -toScreen
        $discardedCertificates | Format-Table FileName, ErrorMessage
    }

    $matchedAzsCertificates = $matchedAzsCertificates | Where-Object ExportFilePath

    # Write group and type information to work out what "sets" are complete.
    $matchedAzsCertificates | ForEach-Object {
        if ($PSItem.ExportFilePath) {
            $certificateTypeToMatch = Split-Path -Path (Split-Path -Path $PSItem.RelativePath -Parent) -Leaf
            $PSItem.certificateGroup = Set-CertificateGroup -certificateType $certificateTypeToMatch -ExternalFqdn $ExternalFQDN -certificates $matchedAzsCertificates
        }
    }

    $uniqueCertGroups = $matchedAzsCertificates | Where-Object CertificateGroup | Select-Object -expand CertificateGroup | Sort-Object | Get-Unique
    Write-AzsReadinessLog -Message ("Detected complete certificate group for {0}." -f ($uniqueCertGroups -join ',')) -Type Info -Function $thisFunction

    if (-not $DisableValidation -and $uniqueCertGroups) {
        Write-AzsReadinessLog -Message "`nStage 3: Validating Certificates" -Type Info -Function $thisFunction -toScreen
        foreach ($uniqueCertGroup in $uniqueCertGroups) {
            $validationSet = $matchedAzsCertificates | Where-Object CertificateGroup -eq $uniqueCertGroup
            if ($null -notin $validationSet.ExportFilePath) {
                # get unique certificate sets for validation e.g. deployment, iothub etc.
                $singleCertificateSet = $validationSet.SingleCertificate | Sort-Object | Get-Unique

                if ($singleCertificateSet) {
                    $certificatePath = $validationSet.ExportFilePath | ForEach-Object { Split-Path -Path $PSITEM -Parent } | Sort-Object | Get-Unique
                    $CertificateType = $validationSet.RelativePath | ForEach-Object { Split-Path -Path $PSITEM -Parent } | Sort-Object | Get-Unique
                }
                else {
                    $certificatePath = $validationSet.ExportFilePath | ForEach-Object { Split-Path -Parent -Path (Split-Path -Path $PSITEM -Parent) } | Sort-Object | Get-Unique
                    $CertificateType = $validationSet.RelativePath | ForEach-Object { Split-Path -Parent -Path (Split-Path -Path $PSITEM -Parent) } | Sort-Object | Get-Unique
                }

                # check there's only one group before proceding
                $CertificateGroup = $validationSet.CertificateGroup | Sort-Object | Get-Unique
                if ($certificatePath.count -ne 1 -and $CertificateGroup.count -ne 1 -and $certificateType.count -ne 1) {
                    Write-Warning $validationSet
                    throw ("Expected 1 certificate path, set and type. Detected {0} path, {1} sets and {2} types" -f $certificatePath.count, $CertificateGroup.count, $CertificateType.count)
                }

                $ValidationParams = @{
                    CertificateType = $certificatePath.split('\')[-1]
                    CertificatePath = $certificatePath
                    ExternalFQDN    = $CertificateType.split('\')[0]
                    pfxPassword     = $pfxPassword
                    OutputPath      = $OutputPath
                    CleanReport     = $CleanReport
                }

                if ($ValidationParams.CertificateType -eq 'Deployment') {
                    $ValidationParams.Add('IdentitySystem', $CertificateGroup.split('-')[-1])
                }
                Write-AzsReadinessLog -Message ("`nValidating {0} certificates in {1} " -f $uniqueCertGroup, $certificatePath) -Type Info -Function $thisFunction -toScreen
                Invoke-AzsCertificateValidation @ValidationParams
            }
            else {
                Write-AzsReadinessLog -Message ("Certificate validation was skipped due to incomplete certificate validation set {0}" -f $uniqueCertGroup, $_.exception.message) -Type Error -Function $thisFunction -toScreen
                Write-Output $validationSet
            }
        }
    }
    else {
        Write-AzsReadinessLog -Message ("Certificate validation was skipped.") -Type Info -Function $thisFunction -toScreen
    }
    Write-Footer -invocation $MyInvocation
}

function Get-AzsCertificateRelativePath {
    <#
    .SYNOPSIS
        Resolve Certificate Config from Certificate
    .DESCRIPTION
        Helper function to determine what type of Azure Stack certificate (if any) a certificate is.
        The resolution is determined by DNSName, other attributes are intended to be validated later (once packaged).
    .EXAMPLE
        Find-AzsCertificate -certificate $certificate -ExternalFQDN $ExternalFQDN
        Resolve Certificate Config from Certificate
    .INPUTS
        x509certificate
    .OUTPUTS
        Azure Stack CertificateConfig
    .NOTES
        General notes
    #>
    [cmdletbinding()]
    param ([System.Security.Cryptography.X509Certificates.X509Certificate2]$certificate, $externalFQDN, $certificateTypeConfiguration)
    $thisFunction = $MyInvocation.MyCommand.Name
    #TO DO handle (no)externalFQDN

    # Make sure we've got cert config for all certs
    if (-not $certificateTypeConfiguration) {
        $certificateTypeConfiguration = Import-PowerShellDataFile $PSScriptRoot\Microsoft.AzureStack.CertificateConfig.psd1
    }
    $certificateTypes = ($certificateTypeConfiguration).CertificateTypes

    # include only hub and RP certificates until support for ASE and Hardware certs is required by this cmdlet.
    foreach ($certificateTypeKey in ($certificateTypes.Keys | Where-Object {$PSITEM -notmatch 'Hardware|AzureStackEdge'})) {
        if ($certificateTypes.$certificateTypeKey.Keys.count -eq 1) {
            $singleCertConfig = $true
        }
        else {
            $singleCertConfig = $false
        }
        foreach ($key in $certificateTypes.$certificateTypeKey.keys) {
            $testDNSNames = Test-DNSNames -cert $Certificate -ExpectedDomain $ExternalFQDN -certConfig $certificateTypes.$certificateTypeKey.$key
            if ($testDNSNames.Result -eq 'OK') {
                $relativePath = "$ExternalFQDN\$certificateTypeKey\$key"
                @{relativePath = $relativePath; SingleCertificate = $singleCertConfig }
            }
        }
    }
}

function PartialValidation {
    <#
    .SYNOPSIS
        Packaging Validation
    .DESCRIPTION
        Packaging Validation to ensure the private key and chain is present
    #>
    param ($certificate, [switch]$DisableChainCheck)
    $thisFunction = $MyInvocation.MyCommand.Name
    if (-not $DisableChainCheck) {
        # Make sure chain is available for packaging
        Write-AzsReadinessLog -message ("Checking the certificate chain is available for packaging") -Type Info -Function $thisFunction
        $ChainCheck = Test-TrustedChain -cert $Certificate
        if ('PartialChain' -in $ChainCheck.outputObject.ChainStatus.Status) {
            Write-AzsReadinessLog -message ("Partial Chain detected") -Type Info -Function $thisFunction
            $missingChainElements = @()
            foreach ($issuer in $ChainCheck.outputObject.ChainElements.Certificate.Issuer) {
                if ($issuer -notin $ChainCheck.outputObject.ChainElements.Certificate.Subject) {
                    $missingChainElements += $issuer
                }
            }
            if ($missingChainElements) {
                Write-AzsReadinessLog -Message ("Missing chain elements {0}. Include certificates for all issuers in the chain in $path" -f ($missingChainElements -join '|')) -Type Error -Function $thisFunction
                throw "Missing Chain"
            }
        }
        if ('UntrustedRoot' -in $ChainCheck.outputObject.ChainStatus.Status) {
            Write-AzsReadinessLog -Message ("UntrustedRoot detected, if this is not on-stamp, this could be by design.") -Type Info -Function $thisFunction
        }
    }

    # Make sure Private Key is available
    $CheckPrivateKey = Test-PrivateKey -cert $Certificate
    if ($CheckPrivateKey.Result -ne 'OK') {
        Write-AzsReadinessLog -Message ("Certificate [{0}] has a problem with its private key. Error: {1}" -f $Certificate.Subject, ($CheckPrivateKey.FailureDetail -join ',')) -Type Error -Function $thisFunction
        throw "No Private Key"
    }
    return $true
}

function Get-AzsCertificateDnsNamesFromConfig {
    <#
    .SYNOPSIS
        Get All Dns Names from config
    .DESCRIPTION
        Get All Dns Name from config
    .EXAMPLE
        PS C:\> Get-AzsCertificateDnsNamesFromConfig
        Get All Dns Names from config
    #>
    # read config and return all DNSNames
    $thisFunction = $MyInvocation.MyCommand.Name
    $certificateConfigDataFile = Import-PowerShellDataFile -Path $PSScriptRoot\Microsoft.AzureStack.CertificateConfig.psd1
    $certificateTypes = $certificateConfigDataFile.CertificateTypes
    foreach ($certificateType in $certificateTypes.Keys) {
        $certificateTypes.$certificateType.keys | Foreach-Object { `
                $certificateTypes.$certificateType.$PSITEM.DNSName | Foreach-Object { `
                    $PSITEM
            }
        }
    }
}

function Get-AzsExternalDomain {
    <#
    .SYNOPSIS
        Determines External Domain for Azs Certificate
    .DESCRIPTION
        Read all dnsnames (sans domain) from config
        Iterate through every name on the certificate and every name from the config
        If there's a match return the domain sans the names the from the config.
        If the result is unique return the fqdn.
    .EXAMPLE
        Get-AzsExternalDomain -dnsNamesFromConfig (Get-AzsCertificateDnsNamesFromConfig) -certificate $Certificate
        Determines External Domain for Azs Certificate
    .INPUTS
        Inputs (if any)
    .OUTPUTS
        Output (if any)
    .NOTES
        General notes
    #>
    param ([System.Security.Cryptography.X509Certificates.X509Certificate2]$certificate, $dnsNamesFromConfig)
    $thisFunction = $MyInvocation.MyCommand.Name
    # Get DNSNames from Certificate
    $certDNSNames = $certificate.DnsNameList.Unicode

    $fqdns = @()
    # Go through each name on certificate and check each DNS name from config,
    # extract it and return if successful
    $fqdns += foreach ($certDNSName in $certDNSNames) {
        foreach ($dnsName in $certDNSNames) {
            foreach ($dnsConfig in $dnsNamesFromConfig) {
                $cfg = [regex]::Escape($dnsConfig)
                # attempt to remove the config dns name from the certificate dnsname and if successful return the resultant string
                if ($certDNSName -match ('^{0}.|^{1}.' -f $cfg, $cfg.replace($cfg.split('.')[0], '\*'))) {
                    $fqdn = [regex]::Replace($certDNSName, ('^{0}.' -f $cfg), '')
                    if ($fqdn -ne $certDNSName) {
                        $fqdn
                    }
                }
            }
        }
    }

    $uniqueFqdns = $fqdns | Sort-Object | Get-Unique
    if ($uniqueFqdns.count -eq 1) {
        Write-AzsReadinessLog -Message ("Detected an ExternalFQDN: $uniqueFqdns for Certificate {0}" -f $certificate.subject) -Type Info -Function $thisFunction
        $uniqueFqdns
    }
    else {
        Write-AzsReadinessLog -Message ("Cannot detect externalFQDN for Certificate {0}. Detected {1} fqdns: {2}" -f $certificate.subject,$uniqueFqdns.count,($uniqueFqdns -join ',')) -Type Warning -Function $thisFunction
    }
}

function Set-CertificateGroup {
    <#
    .SYNOPSIS
        Set Certificate Group information
    .DESCRIPTION
        Set Certificate Group information
    .EXAMPLE
        PS C:\> Set-CertificateGroup -certificateType Deployment -ExternalFqdn $ExternalFQDN -certificates $AzsCertificates
        Set Certificate Group information
    .NOTES
        General notes
    #>
    param ($certificateType = 'Deployment', $ExternalFqdn, $certificates)
    $thisFunction = $MyInvocation.MyCommand.Name
    # Get Certificate Configs for target certificateType
    $certificateConfigDataFile = Import-PowerShellDataFile -Path $PSScriptRoot\Microsoft.AzureStack.CertificateConfig.psd1
    $certificateConfig = $certificateConfigDataFile.CertificateTypes[$certificateType]

    # Get certificates matching certificateType and ExternalFQDN
    $certificateSet = $certificates | Where-Object { $_.RelativePath -like "$ExternalFqdn\$CertificateType\*"}
    if (-not $certificateSet) {
        return $null
    }
    [array] $certificatesPresent = $certificateSet.RelativePath | Foreach-Object { $PSITEM.split('\')[2] }
    [array] $certificatesExpected = $certificateConfig.Keys

    # Compare certificates against config
    [array] $compareResult = Compare-Object $certificatesPresent $certificatesExpected -PassThru | Sort-Object

    # null = full set
    # ADFS and Graph missing only means AAD support
    # anything else is not a full set.
    if ($null -eq $compareResult) {
        # if deployment then ADFS is supported by this set
        Write-AzsReadinessLog -message ("Detected certificate group {0} for {1}" -f $certificateType, $externalFQDN) -Type Info -Function $thisFunction
        if ($certificateType -eq 'Deployment') {
            $certificateType = 'Deployment-ADFS'
        }
        $certificateSetValue = "$ExternalFqdn-$CertificateType"
    }
    elseif (($compareResult -join ',') -eq 'ADFS,Graph') {
        Write-AzsReadinessLog -message ("Detected certificate group {0} for {1}, but ADFS and Graph are missing, only support for Deployment AAD" -f $certificateType, $externalFQDN) -Type Info -Function $thisFunction
        $certificateType = 'Deployment-AAD'
        $certificateSetValue = "$ExternalFqdn-$CertificateType"

    }
    else {
        Write-AzsReadinessLog -message ("No match found: Compare output {0}" -f ($compareResult -join ',')) -Type Warning -Function $thisFunction
    }
    $certificateSetValue
}
# SIG # Begin signature block
# MIIjkgYJKoZIhvcNAQcCoIIjgzCCI38CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCnQNj8yN4GtXPx
# o89xuychKJjqXQCqqpwC0u+waCGF86CCDYEwggX/MIID56ADAgECAhMzAAACUosz
# qviV8znbAAAAAAJSMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjEwOTAyMTgzMjU5WhcNMjIwOTAxMTgzMjU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDQ5M+Ps/X7BNuv5B/0I6uoDwj0NJOo1KrVQqO7ggRXccklyTrWL4xMShjIou2I
# sbYnF67wXzVAq5Om4oe+LfzSDOzjcb6ms00gBo0OQaqwQ1BijyJ7NvDf80I1fW9O
# L76Kt0Wpc2zrGhzcHdb7upPrvxvSNNUvxK3sgw7YTt31410vpEp8yfBEl/hd8ZzA
# v47DCgJ5j1zm295s1RVZHNp6MoiQFVOECm4AwK2l28i+YER1JO4IplTH44uvzX9o
# RnJHaMvWzZEpozPy4jNO2DDqbcNs4zh7AWMhE1PWFVA+CHI/En5nASvCvLmuR/t8
# q4bc8XR8QIZJQSp+2U6m2ldNAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUNZJaEUGL2Guwt7ZOAu4efEYXedEw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDY3NTk3MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAFkk3
# uSxkTEBh1NtAl7BivIEsAWdgX1qZ+EdZMYbQKasY6IhSLXRMxF1B3OKdR9K/kccp
# kvNcGl8D7YyYS4mhCUMBR+VLrg3f8PUj38A9V5aiY2/Jok7WZFOAmjPRNNGnyeg7
# l0lTiThFqE+2aOs6+heegqAdelGgNJKRHLWRuhGKuLIw5lkgx9Ky+QvZrn/Ddi8u
# TIgWKp+MGG8xY6PBvvjgt9jQShlnPrZ3UY8Bvwy6rynhXBaV0V0TTL0gEx7eh/K1
# o8Miaru6s/7FyqOLeUS4vTHh9TgBL5DtxCYurXbSBVtL1Fj44+Od/6cmC9mmvrti
# yG709Y3Rd3YdJj2f3GJq7Y7KdWq0QYhatKhBeg4fxjhg0yut2g6aM1mxjNPrE48z
# 6HWCNGu9gMK5ZudldRw4a45Z06Aoktof0CqOyTErvq0YjoE4Xpa0+87T/PVUXNqf
# 7Y+qSU7+9LtLQuMYR4w3cSPjuNusvLf9gBnch5RqM7kaDtYWDgLyB42EfsxeMqwK
# WwA+TVi0HrWRqfSx2olbE56hJcEkMjOSKz3sRuupFCX3UroyYf52L+2iVTrda8XW
# esPG62Mnn3T8AuLfzeJFuAbfOSERx7IFZO92UPoXE1uEjL5skl1yTZB3MubgOA4F
# 8KoRNhviFAEST+nG8c8uIsbZeb08SeYQMqjVEmkwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVZzCCFWMCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAlKLM6r4lfM52wAAAAACUjAN
# BglghkgBZQMEAgEFAKCBrjAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgNmExjtju
# sMLM68KxEQ9ORYSyVQJH/GnIdybvJqtnkzUwQgYKKwYBBAGCNwIBDDE0MDKgFIAS
# AE0AaQBjAHIAbwBzAG8AZgB0oRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQC1qDRr8kF1NUh1Pzkj1Hs45vazrlG7cpSJuWf772HY
# x7/5UaMlO+EkxWJWyDd9nWaxco16bqtKnwm6J7WvmWX7ZARZqIa3NADZPuC70kOZ
# oWJbWn5GWjsrKaQx7incZNsgCxT+noIj4RXqKZT4kA1TM9Xjw3G863L4H6jcX6QF
# vjRUi2Mz79VHuXByfnDa0eMCPGozELXdW+zvAAcbAERzJea05JhUtsJGxiCsgFa3
# FoaDcNzqkdi7IcUOVCRkXfzOBLZ7C18idbryTrnziRZ+BkWvxG+qGeCP7Sg0tRk3
# hxYamM0wEeMP4RoOp+cbynLTpHmHLECcvwKhz/W0Z8mBoYIS8TCCEu0GCisGAQQB
# gjcDAwExghLdMIIS2QYJKoZIhvcNAQcCoIISyjCCEsYCAQMxDzANBglghkgBZQME
# AgEFADCCAVUGCyqGSIb3DQEJEAEEoIIBRASCAUAwggE8AgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEILSUFRG/gOjrTcbTtEQQDrZMnPYYSG+C3aDw9Rhj
# /DZ6AgZhvMAePRwYEzIwMjIwMTA1MTIxMTM5LjE0M1owBIACAfSggdSkgdEwgc4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1p
# Y3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMg
# VFNTIEVTTjo0NjJGLUUzMTktM0YyMDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgU2VydmljZaCCDkQwggT1MIID3aADAgECAhMzAAABWHBaIve+luYDAAAA
# AAFYMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MB4XDTIxMDExNDE5MDIxNFoXDTIyMDQxMTE5MDIxNFowgc4xCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVy
# YXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo0NjJG
# LUUzMTktM0YyMDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vydmlj
# ZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKEfC5dg9auw0KAFGwv1
# 7yMFG8SfqgUUFC8Dzwa8mrps0eyhRQ2Nv9K7/sz/fVE1o/1fZp4q4SGitcsjPGtO
# njWx45VIFTINQpdoOhmsPdnFy3gBXpMGtTfXqLnnUE4+VmKC2vAhOZ06U6vt5Cc0
# cJoqEJtzOWRwEaz8BoX2nCX1RBXkH3PiAu7tWJv3V8zhRSPLFmeiJ+CIway04AUg
# mrwXEQHvJHgb6PiLCxgE2VABCDNT5CVyieNapcZiKx16QbDle7KOwkjMEIKkcxR+
# 32dDMtzCtpIUDgrKxmjx+Gm94jHieohOHUuhl3u3hlAYfv2SA/86T1UNAiBQg3Wu
# 9xsCAwEAAaOCARswggEXMB0GA1UdDgQWBBRLcNkbfZ0cGB/u536ge5Mn06L5WDAf
# BgNVHSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBH
# hkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNU
# aW1TdGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUF
# BzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0
# YVBDQV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsG
# AQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IBAQA53ygDWovQrh8fuliNXW0CUBTzfA4S
# l4h+IPEh5lNdrhDFy6T4MA9jup1zzlFkpYrUc0sTfQCAOnAjmunPgnmaS5bSf2VH
# 8Mg34U2qgPLInMAkGaBs/BzabJ65YKe1P5IKZN7Wj2bRfCK03ES8kS7g6YQH67ix
# MCQCLDreWDKJYsNs0chNpJOAzyJeGfyRUe+TUUbFwjsC/18KmYODVgpRSYZx0W7j
# rGqlJVEehuwpSIsGOYCBMnJDNdKnP+13Cg68cVtCNX6kJdvUFH0ZiuPMlBYD7GrC
# PqARlSn+vxffMivu2DMJJLkeywxSfD52sDV+NBf5IniuKFcE9y0m9m2jMIIGcTCC
# BFmgAwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJv
# b3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1WhcN
# MjUwNzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCASIw
# DQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkdDbx3EYo6IOz8E5f1+n9plGt0
# VBDVpQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMnBDEfQRsalR3OCROOfGEwWbEw
# RA/xYIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeGMoQe
# dGFnkV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8RsEnHSRnEnIaIYqvS2SJUGKx
# Xf13Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v0Ev9buWayrGo8noqCjHw2k4G
# kbaICDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN/LzAyURdXhacAQVPIk0CAwEA
# AaOCAeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ80N7
# fEYbxTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMC
# AYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvX
# zpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20v
# cGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYI
# KwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDCBoAYDVR0g
# AQH/BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYIKwYB
# BQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0AGUA
# bQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAAfmiFEN4sbgmD+BcQM9naOh
# IW+z66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4vceoniXj+bzta1RXCCtRgkQS
# +7lTjMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzymXlK
# kVIArzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8z+0DpZaPWSm8tv0E4XCfMkon
# /VWvL/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVKC5Em4jnsGUpxY517IW3DnKOi
# PPp/fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs9/S/
# fmNZJQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF0M2n0O99g/DhO3EJ3110mCII
# YdqwUB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+YWtvd6mBy6cJrDm77MbL2IK0
# cs0d9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt6o3gMy4SKfXAL1QnIffIrE7a
# KLixqduWsqdCosnPGUFN4Ib5KpqjEWYw07t0MkvfY3v1mYovG8chr1m1rtxEPJdQ
# cdeh0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc1bN+
# NR4Iuto229Nfj950iEkSoYIC0jCCAjsCAQEwgfyhgdSkgdEwgc4xCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBP
# cGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo0
# NjJGLUUzMTktM0YyMDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZaIjCgEBMAcGBSsOAwIaAxUAqckrcxrn0Qshpuozjp+l+DSfNL+ggYMwgYCk
# fjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIF
# AOV/ohcwIhgPMjAyMjAxMDUwODUwMzFaGA8yMDIyMDEwNjA4NTAzMVowdzA9Bgor
# BgEEAYRZCgQBMS8wLTAKAgUA5X+iFwIBADAKAgEAAgIozQIB/zAHAgEAAgIQ+DAK
# AgUA5YDzlwIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIB
# AAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBABPx/4Ut/29gApwX
# AEsyAczNHLqVvQIEvvWC8kB5G7ERyH/ibiL1Zfls6d/lDBFa9/4vq93dBYdAs6El
# D9zpbnFXpIYntiFyaNi+3LtXM7psgxVDi4FenVfFPBEPU0mjGgwKVRkoCdV0PFG6
# pbBq3bKnHnFKBFvOaRzQu+beHM04MYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTACEzMAAAFYcFoi976W5gMAAAAAAVgwDQYJYIZIAWUD
# BAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0B
# CQQxIgQganBh9errat3O3R8rBvDMUsWmysBfs2EYBvRJ8C+eBLswgfoGCyqGSIb3
# DQEJEAIvMYHqMIHnMIHkMIG9BCDySjONbIY1l2zKT4ba4sCI4WkBC6sIfR9uSVNV
# x3DTBzCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB
# WHBaIve+luYDAAAAAAFYMCIEIBv89EWWazbb5AonEHGKNrqdJ9lMThx1cmuw09Wn
# 5x5QMA0GCSqGSIb3DQEBCwUABIIBAId8plKbk3rF/WVl+pRPrbzlT1FGT+jZEosq
# 5XudrkGEUUMWHp3+Diiq1kNWfYDFbcJcrR2WttXCDs9uS9JqxzhaWszyefA/o1Le
# uYGZvMNxFQkVzKFgmwDBaI//ASYzzcrC3m3rIICjPzOCCLzJA57lgdchPiJYKczX
# Fa8bGXEnUgjwSD/p3TQ4WnWWM9vrZSG3n1ho6bNJdGL0DkUsiAVqAtFLTU7QGYOB
# cMBYO7Wa2ujcV5s013294lweK6GZ6wi082foLJfViGSBxDXTtFdLnl627i3TXnXs
# Z7m1ZpSZAxEHuGbnQwRygKZZP5abTEH8dZiOSQcyo9oYgG/g7/8=
# SIG # End signature block
