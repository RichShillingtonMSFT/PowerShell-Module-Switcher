Import-Module $PSScriptRoot\Microsoft.AzureStack.PublicCertificateRequest.Internal.psm1 -Force
Import-Module $PSScriptRoot\..\Microsoft.AzureStack.ReadinessChecker.Utilities.psm1 -Force

function New-AzsCertificateSigningRequest {
    <#
    .SYNOPSIS
        Wrapper function to build SANs and call internal certreq.exe function for multiSAN CSR or SingleSAN CSR
    .DESCRIPTION
        Imports the standard Azure Stack SANs and builds the SAN list, required/recommended certificate attributes and
        calls internal functions to generate multiple Certificate Signing Request files.
    .EXAMPLE
        $certificateRequestParams = @{
            'CertificateType' = 'Deployment'
            'IdentitySystem' = 'AAD'
            'regionName' = 'azurestack'
            'externalFQDN' = 'contoso.com'
            'subject' = "C=US,ST=Washington,L=Redmond,O=Microsoft,OU=Azure Stack"
            'requestType' = 'MultipleCSR'
            'OutputRequestPath' = "$ENV:USERPROFILE\Documents\AzsCertRequests"
        }
        New-AzsCertificateSigningRequest @certificateRequestParams
        Generates multiple CSRs for deployment of Azure Stack Hub e.g. portal.azurestack.contoso.com, management.azurestack.contoso.com etc..
    .EXAMPLE
        $certificateRequestParams = @{
            'CertificateType' = 'Deployment'
            'IdentitySystem' = 'AAD'
            'regionName' = 'azurestack'
            'externalFQDN' = 'contoso.com'
            'subject' = "C=US,ST=Washington,L=Redmond,O=Microsoft,OU=Azure Stack"
            'KeyLength' = 4096
            'requestType' = 'MultipleCSR'
            'OutputRequestPath' = "$ENV:USERPROFILE\Documents\AzsCertRequests"
        }
        New-AzsCertificateSigningRequest @certificateRequestParams
        Generates multiple CSRs for deployment of Azure Stack with Key Length of 4096 (rather than default 2048)
    .EXAMPLE
        $certificateRequestParams = @{
            'CertificateType' = 'Deployment'
            'IdentitySystem' = 'AAD'
            'regionName' = 'azurestack'
            'externalFQDN' = 'contoso.com'
            'subject' = "C=US,ST=Washington,L=Redmond,O=Microsoft,OU=Azure Stack"
            'HashAlgorithm' = 'SHA384'
            'requestType' = 'MultipleCSR'
            'OutputRequestPath' = "$ENV:USERPROFILE\Documents\AzsCertRequests"
        }
        New-AzsCertificateSigningRequest @certificateRequestParams
        Generates multiple CSRs for deployment of Azure Stack with signature algorithm of SHA384 (rather than default SHA256)
    .EXAMPLE
        $certificateRequestParams = @{
            'CertificateType' = 'AppServices' # or DataboxEdge, DBAdapter, EventHubs, IoTHub.
            'regionName' = 'azurestack'
            'externalFQDN' = 'contoso.com'
            'subject' = "C=US,ST=Washington,L=Redmond,O=Microsoft,OU=Azure Stack"
            'OutputRequestPath' = "$ENV:USERPROFILE\Documents\AzsCertRequests"
        }
        New-AzsCertificateSigningRequest @certificateRequestParams
        Generates multiple CSRs for AppServices of Azure Stack
    .EXAMPLE
        $certificateRequestParams = @{
            CertificateType = 'AzureStackEdgeDevice'
            DeviceName = 'DBG-KARB2NP5J'
            NodeSerialNumber = 'WIN-KARB2NP5J3O'
            externalFQDN = 'azurestackedge.contoso.com'
            OutputRequestPath = "$ENV:USERPROFILE\Documents\AzsCertRequests"
        }
        New-AzsCertificateSigningRequest @certificateRequestParams
        Generates multiple CSRs for Azure Stack Edge device certificates
    .EXAMPLE
        $certificateRequestParams = @{
            CertificateType = 'AzureStackEdgeVPN'
            Subject = "C=US,ST=Washington,L=Redmond,O=Microsoft,OU=Azure Stack Edge"
            externalFQDN = 'azurestackedge.contoso.com'
            OutputRequestPath = "$ENV:USERPROFILE\Documents\AzsCertRequests"
        }
        New-AzsCertificateSigningRequest @certificateRequestParams
        Generates a CSR for a Azure Stack Edge VPN certificate
    .EXAMPLE
        $certificateRequestParams = @{
            CertificateType = 'AzureStackEdgeVPN'
            Subject = "C=US,ST=Washington,L=Redmond,O=Microsoft,OU=Azure Stack Edge"
            EnhancedKeyUsage = @('Server Authentication',@{'Custom Usage' = '1.3.6.1.5.7.8.2.1'})
            externalFQDN = 'azurestackedge.contoso.com'
            OutputRequestPath = "$ENV:USERPROFILE\Documents\AzsCertRequests"
        }
        New-AzsCertificateSigningRequest @certificateRequestParams
        Generates a CSRs for a Azure Stack Edge VPN certificate with custom OID for enhanced key usage.
        Note: You should include the required usage for the certificate and the custom usage as a hashtable where key = friendlyName; value = OID
    .EXAMPLE
        New-AzsCertificateSigningRequest -certificateType Deployment -StampEndpoint portal.azurestack.contoso.com -OutputRequestPath "$ENV:USERPROFILE\Documents\AzsCertRequests"
        Connects to existing endpoint https://portal.azurestack.contoso.com read the current SSL certificate, clones the attributes and creates Certificate Signing Requests with those attributes.
        For use with renewal of soon-to-be expired certs.
    .OUTPUTS
        None - This is a wrapper function that calls an internal function to generate the encoded CSR
    .PARAMETER CertificateType
        Specifies the Azure Stack certificate type to generate a request for e.g. Deployment, AppServices, EventHubs, IoTHub etc.
    .PARAMETER RegionName
        Specifies the Azure Stack deployment's region name, must be alphanumeric.
    .PARAMETER externalFQDN
        Specifies the Azure Stack deployment's External FQDN, also aliased as ExternalFQDN and FQDN, must be valid DNSHostName
    .PARAMETER DeviceName
        Specifies the serial number of an Azure Stack Edge device.
    .PARAMETER NodeSerialNumber
        Specifies the node name(s) of an Azure Stack Edge device.
    .PARAMETER DistinguishedName
        Specifies a DistinguishedName to be used on the certificate.  Must be a valid System.Security.Cryptography.X509Certificates.X500DistinguishedName value.
        Common Name (CN) is not required, the appropriate value for the Azure Stack Service will be placed in the Common Name (CN).
        If a Common Name (CN) is given it will be honoured on every certificate request if supplied.
        Also aliased as subject.
    .PARAMETER DistinguishedNameFlag
        Specifies a string for the distinguished name flag to be used in the distinguished name.  UseUTF8Encoding is selected by default. More information on x500DistinguishNameFlags
        can be found at https://aka.ms/dnflags
    .PARAMETER KeyLength
        Defines the length of the public and private key for the certificate request generation. Default is 2048. Valid values 2048, 4096, 8192
    .PARAMETER HashAlgorithm
        Hash Algorithm to be used for the certificate request generation. Default is SHA256. Valid values SHA256, SHA384, SHA512
    .PARAMETER EnhancedKeyUsage
        Extended (Enhanced) Key Usage to be included in the certificate request. Provide the required usage for the target certificate as well as the custom usage in hashtable format.
        e.g. @('Client Authentication','Server Authentication',@{'Custom Usage' = '1.3.6.1.5.7.8.2.1'}) will request Client and Server Auth key usage and the custom usage.
    .PARAMETER RequestType
        Specifies the SAN type of the certificate request. Valid values: MultipleCSR, SingleCSR.
        SingleCSR generates one certificate request for all services (not recommended for production). User will be prompted to confirm use.
        MultipleCSR generates multiple certificate requests, one for each service (strongly recommended in production environments).
    .PARAMETER StampEndpoint
        Provide a dns hostname of an existing stamp endpoint (region.external.fqdn) to clone the certificate attributes to be used to generate the certificate signing request.
    .PARAMETER OutputRequestPath
        Specifies the destination path for certificate request files, directory must already exist.
    .PARAMETER IdentitySystem
        Specifies the Azure Stack deployment's Identity System valid values, AAD or ADFS, for Azure Active Directory and Active Directory Federated Services respectively
    .PARAMETER OutputPath
        Specifies custom path to save Readiness JSON report and Verbose log file.
    .PARAMETER ForceTLS12
        Force the use of TLS 1.2, true by default, set to false to use to system default.
    .PARAMETER LowPrivilege
        Use in low privilege environment were elevation is not allowed. Generates INF certificate request templates.
    .LINK
        Generate Azure Stack Certificate Requests - https://aka.ms/AzsCSR
        Azure Stack Readiness Checker Tool - https://aka.ms/AzsReadinessChecker
    .NOTES
    #>
    [outputType([string])]
    [cmdletbinding()]
    [Alias("New-AzsCSR", "New-AzsCertificateRequest", "Write-AzsCertificateRequestFile")]
    param (
        [Parameter(Mandatory = $true, HelpMessage = "Specify the Azure Stack certificate type to generate a request")]
        [ArgumentCompleter({Get-AzsCertificateRequestTypes | Sort-Object})]
        [ValidateScript({$_ -in (Get-AzsCertificateRequestTypes)})]
        [string]
        $CertificateType,

        [Parameter(Mandatory = $false, HelpMessage = "Enter Azure Stack Hub Region Name")]
        [string]$RegionName,

        [Parameter(Mandatory = $false, HelpMessage = "Enter Azure Stack Fully Qualified Domain Name (without region name)")]
        [Alias("FQDN", "ExternalDomainName")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        [string]$ExternalFQDN,

        [Parameter(Mandatory = $false, HelpMessage = 'Provide subject name as a string, CN is not required and will be overwritten. E.g. "C=US,ST=Washington,L=Redmond,O=Microsoft,OU=Azure Stack"')]
        [Alias("Subject")]
        [System.Security.Cryptography.X509Certificates.X500DistinguishedName]$DistinguishedName,

        [Parameter(Mandatory = $false, HelpMessage = 'Provide X500DistinguishedNameFlags if The distinguished name has special characteristics. Default UseUTF8Encoding.')]
        [System.Security.Cryptography.X509Certificates.X500DistinguishedNameFlags]$DistinguishedNameFlag = 'UseUTF8Encoding',

        [Parameter(Mandatory = $false, HelpMessage = 'Provide Key Length: 2048, 4096 or 8192')]
        [ValidateSet(2048, 4096, 8192)]
        [int]$KeyLength = 2048,

        [Parameter(Mandatory = $false, HelpMessage = 'Provide Hash Algorithm: SHA256, SHA384 or SHA512')]
        [ValidateSet('SHA256', 'SHA384', 'SHA512')]
        [System.Security.Cryptography.HashAlgorithmName]$HashAlgorithm = 'SHA256',

        [Parameter(Mandatory = $false, HelpMessage = "Optionally provide Extended (Enhanced) Key Usage. By default, certificate config will be used. e.g. @('Client Authentication', 'Server Authentication', @{'Custom Usage' = '1.3.6.1.5.15.7.3.2'})")]
        $EnhancedKeyUsage,

        [Parameter(Mandatory = $false, HelpMessage = "Enter Certificate Request generation type ('Single' = Request individual wildcard certificates, 'Multiple' = Request single multi domain wildcard certificates")]
        [ValidateSet('MultipleCSR', 'SingleCSR')]
        [string]$requestType = 'MultipleCSR',

        [Parameter(Mandatory = $false, HelpMessage = "Enter Azure Stack Identity System (AAD or ADFS) when generating deployment certificates")]
        [ValidateSet('AAD', 'ADFS')]
        [string]$IdentitySystem,

        [Parameter(Mandatory = $false, HelpMessage = "Optionally provide an existing stamp endpoint (region.fqdn) to clone the certificate attributes to be used to generate the certificate signing request.")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        $StampEndpoint,

        [Parameter(Mandatory = $false, HelpMessage = "Force the use of TLS 1.2, true by default")]
        [bool]$ForceTLS12 = $true,

        [Parameter(Mandatory = $true, HelpMessage = "Destination Path for Certificate Request(s)")]
        [ValidateScript( {Test-Path -Path $_ -PathType Container <# should be a valid directory path #>})]
        [string]$OutputRequestPath,

        [Parameter(Mandatory = $false, HelpMessage = "Directory path for log and report output")]
        [string]$OutputPath = "$ENV:TEMP\AzsReadinessChecker",

        [Parameter(Mandatory = $false, HelpMessage = "Use in low privilege environment were elevation is not allowed. Generates INF certificate request templates.")]
        [switch]$LowPrivilege
    )
    DynamicParam {
        if ('AzureStackEdgeDevice' -in $certificateType) {
            $ParamAttrib = New-Object  System.Management.Automation.ParameterAttribute
            $ParamAttrib.Mandatory = $true
            $ParamAttrib.ParameterSetName = 'AzureStackEdgeDevice'

            $AttribColl = New-Object  System.Collections.ObjectModel.Collection[System.Attribute]
            $AttribColl.Add($ParamAttrib)

            # Create addition parameters for AzureStackEdge
            $RuntimeParamDic = New-Object  System.Management.Automation.RuntimeDefinedParameterDictionary

            $RuntimeParam = New-Object  System.Management.Automation.RuntimeDefinedParameter('DeviceName', [string],  $AttribColl)
            $RuntimeParamDic.Add('DeviceName', $RuntimeParam)

            $RuntimeParam = New-Object  System.Management.Automation.RuntimeDefinedParameter('NodeSerialNumber', [string[]],  $AttribColl)
            $RuntimeParamDic.Add('NodeSerialNumber', $RuntimeParam)
        }
        if ($RuntimeParamDic) {
            return $RuntimeParamDic
        }
    }
    process
    {

        $thisFunction = $MyInvocation.MyCommand.Name
        $GLOBAL:OutputPath = $OutputPath

        Import-Module $PSScriptRoot\..\Microsoft.AzureStack.ReadinessChecker.Reporting.psm1 -Force
        Import-Module $PSScriptRoot\Microsoft.AzureStack.PublicCertificateRequest.Internal.psm1 -Force
        Write-Header -invocation $MyInvocation -params $PSBoundParameters

        if (-not $LowPrivilege)
        {
            if (Test-Elevation)
            {
                Write-AzsReadinessLog -Message ("Powershell running as Administrator. Continuing.") -Type Info
            }
            else
            {
                Write-AzsReadinessLog -Message ("Running as administrator is required for this operation.  `nPlease restart PowerShell as Administrator and retry.") -Type Error -toScreen
                Write-AzsReadinessLog -Message ("This is because certificate request generation creates sensitive key material in the local certificate store") -Type Error -toScreen
                Write-AzsReadinessLog -Message ("If you are unable to elevate to Administrator, you can create the Certificate Request Template files by running the previous command and adding -LowPrivilege.") -Type Error -toScreen
                throw "This operation requires elevation."
            }
        }
        else {
            Write-AzsReadinessLog -Message ("LowPrivilege:$lowPrivilege. Skipping elevation check. Continuing.") -Type Info
        }

        $certificateConfigDataFile = Import-PowerShellDataFile -Path $PSScriptRoot\Microsoft.AzureStack.CertificateConfig.psd1

        try {
            # gather attributes from an existing certificate
            if ($StampEndpoint) {

                # Get intended certificate config
                $StampEndpointExpectedConfig = $certificateConfigDataFile.CertificateTypes[$PSBoundParameters.CertificateType]
                $FixedEndpoint = Get-FixedEndPoints -certificateConfig $StampEndpointExpectedConfig -stampEndpoint $stampEndpoint

                # Force Security Profile to TLS1.2
                if ($ForceTLS12) {
                    # Change Security Protocol to TLS1.2 for the session and track for clean up later.
                    $restoreSecurityProtocol = [Net.ServicePointManager]::SecurityProtocol
                    $tempSecurityProtocol = [Net.SecurityProtocolType]::Tls12
                    Set-SecurityProtocol -securityProtocol $tempSecurityProtocol
                }

                # check each endpoint for the certificate and break at the first match
                foreach ($Endpoint in $FixedEndpoint) {
                    $csrParams = Get-AzsCSRParameters -StampEndpoint $Endpoint
                    if ($csrParams) {
                        break
                    }
                }

                if (-not $csrParams){
                    $csrParamError = ("Failed to query {0} for existing certificate. Please create certificate signing request as a new request." -f ($FixedEndpoint -join ','))
                    Write-AzsReadinessLog -Message $csrParamError -Type Error
                    throw $csrParamError
                }

                foreach ($key in $csrParams.Keys) {
                    Set-Variable -Name $key -Value $csrParams.$key
                }
            }

            # Join RegionName and ExternalFQDN
            if ($regionName -and $CertificateType -ne 'AzureStackEdgeDevice') {
                $ExternalFQDN = "{0}" -f (($regionName,$ExternalFQDN) -join '.')
            }

            # Check Extended Key Usage
            if ($EnhancedKeyUsage) {
                ConvertTo-EnhancedKeyUsage -EnhancedKeyUsages $EnhancedKeyUsage
            }

            foreach ($certificateType in $PSBoundParameters.CertificateType)
            {
                Write-AzsReadinessLog -Message ("Starting Certificate Request Process for {0}" -f $certificateType) -Type Info -Function $thisFunction -toScreen

                # Check the DistinguishedName is good to use.
                if ($DistinguishedName) {
                    $testDistinguishedName = Test-DistinguishedName -DistinguishedName $DistinguishedName -DistinguishedNameFlag $DistinguishedNameFlag
                    if (-not $testDistinguishedName) {
                        Write-AzsReadinessLog -Message ("Distinguished name '{0}' cannot be processed with x500DistinguishedName with flag '{1}', explicitly provide the right flag with -DistinguishedNameFlag. See https://aka.ms/azscsr for more information." -f $DistinguishedName,$DistinguishedNameFlag) -Type Error -Function $thisFunction -toScreen
                        break
                    }
                }

                # Check the user provided appropriate parameters
                # IdentitySystem if Deployment certificates are being generated (dynamic parameter do not allow this valdiate on the param block)
                if ($certificateType -eq 'Deployment' -AND -not $IdentitySystem) {
                    throw "CertificateType is Deployment and IdentitySystem not provided. Please re-run providing -IdentitySystem valid values are AAD or ADFS."
                }
                # NodeSerialNumber is AzureStackEdgeDevice
                if ($certificateType -eq 'AzureStackEdgeDevice' -and !$PSBoundParameters.NodeSerialNumber) {
                    throw "CertificateType is $certificateType and NodeSerialNumber not provided. Please re-run providing -NodeSerialNumber and the appropriate value for your system."
                }

                $certificateConfig = $certificateConfigDataFile.CertificateTypes[$CertificateType]
                if ($certificateType -eq 'Deployment' -AND $IdentitySystem -eq 'AAD') {
                    Write-AzsReadinessLog -Message "CertificateType is Deployment and IdentitySystem is AAD, removing Graph and ADFS from config" -Type Info -Function $thisFunction
                    $certificateConfig.Remove('Graph')
                    $certificateConfig.Remove('ADFS')
                }

                # Adding support for multiple node certs, adding and setting DNSName (template) in one go.
                if ($CertificateType -eq 'AzureStackEdgeDevice') {
                    if ($PSBoundParameters.nodeSerialNumber.count -gt 1) {
                        $num = 0
                        $PSBoundParameters.nodeSerialNumber | ForEach-Object {
                            $newNode = $certificateConfig.node.Clone()
                            $nodeKey = "Node{0:d2}" -f $num
                            $certificateConfig.Add($nodeKey,$newNode)
                            $certificateConfig[$nodeKey].DnsName = $PSITEM
                            $num++
                        }
                        $certificateConfig.remove('Node')
                    }
                }

                # attributes should be user specified (globally), certificate specific or defaults
                $CertificateDefaults = $certificateConfigDataFile.CertificateDefaults
                foreach ($certificate in  $certificateConfig.Keys) {
                   Write-AzsReadinessLog -Message ("Starting attribute calculation for certificate {0}." -f $certificate) -Type Info -Function $thisFunction
                    foreach ($attribute in $certificateConfig.$Certificate.keys | where-Object {$PSITEM -notin 'DNSName', 'IncludeTests', 'ExcludeTests'}) {
                        Write-AzsReadinessLog -Message ("Starting attribute {0}." -f $attribute) -Type Info -Function $thisFunction
                        # user first
                        if ($attribute -in $PSBoundParameters.Keys) {
                            Write-AzsReadinessLog -Message ("Attribute {0} found on user parameters supplied. Replacing default value ({1}) with ({2})." -f $attribute,$CertificateDefaults[$attribute],$PSBoundParameters[$attribute]) -Type Info -Function $thisFunction
                            $certificateConfig.$Certificate.$attribute = $PSBoundParameters[$attribute]
                        }
                        else {
                            if ($certificateConfig.$Certificate.$attribute -eq 'default') {
                                Write-AzsReadinessLog -Message ("Attribute {0} should be default value ({1})." -f $attribute,$CertificateDefaults[$attribute]) -Type Info -Function $thisFunction
                                $certificateConfig.$Certificate.$attribute = $CertificateDefaults.$attribute
                            }
                            else {
                                Write-AzsReadinessLog -Message ("Attribute {0} is non default, keeping certificate config ({1})." -f $attribute,(($certificateConfig.$Certificate.$attribute) -join ',')) -Type Info -Function $thisFunction
                            }
                        }
                    }
                }

                if ($requestType -eq 'SingleCSR') {
                    # Handle SANs for AzureStackEdge certificates with DeviceName, NodeSerialNumbers
                    # Append region & fqdn to dnsname for the rest
                    if ($CertificateType -match 'AzureStackEdge') {
                        foreach ($key in $certificateConfig.Keys) {
                            $certificateConfig.$key.DNSName = $certificateConfig.$key.DNSName | Foreach-Object { `
                                $PSITEM.replace('[[DeviceName]]',$PSBoundParameters.DeviceName).replace('[[NodeSerialNumber]]',$PSBoundParameters.NodeSerialNumber)
                            }
                        }
                    }

                    # If region name exists, append region & fqdn to dnsname, otherwise just use fqdn
                    $subjectAlternativeNames = $certificateConfig.Keys | ForEach-Object {$certificateConfig.$PSITEM.DNSName} | Foreach-Object { `
                        if ($PSITEM -ne '') {
                            "{0}.{1}" -f $PSITEM,$externalFQDN
                        }
                        else {
                            $externalFQDN
                        }
                    } | Sort-Object
                    $commonName = $subjectAlternativeNames | Sort-Object | Select-Object -First 1

                    # Set subject to first SAN or (if supplied) honour users common name
                    $certificateSubjectParams = @{
                        distinguishedName           = $DistinguishedName
                        DistinguishedNameFlag       = $DistinguishedNameFlag
                        commonName                  = $commonName
                    }
                    $certificateSubject = Set-CertificateSubject @certificateSubjectParams

                    # set request path to include regionname/devicename, externalfqdn and SingleCSR
                    if ($PSCmdlet.ParameterSetName -eq 'AzureStackEdgeDevice') {
                        $leaf = "{0}_{1}_{2}_SingleCSR" -f $CertificateType,$PSBoundParameters.DeviceName,$ExternalFQDN.replace('.','_')
                        $OutputRequestPathSeed = Join-Path -Path $OutputRequestPath -ChildPath $leaf
                    }
                    else {
                        $OutputRequestPathSeed = Join-Path -Path $OutputRequestPath -ChildPath ("{0}_{1}_SingleCSR" -f $CertificateType,$ExternalFQDN.replace('.','_'))
                    }

                    # TO DO remove this hardcoding of CN for AzureStackEdgeDevice
                    if ($key -in $certificateConfigDataFile.CertificateTypes.AzureStackEdgeDevice.Keys) {
                        $certificateSubject = [System.Security.Cryptography.X509Certificates.X500DistinguishedName]::new("CN=$commonName")
                    }

                    # Call CSR generation
                    $csrParams = @{
                        'subject'                   = $certificateSubject.decode($DistinguishedNameFlag)
                        'subjectAltNames'           = $SubjectAlternativeNames
                        'KeyLength'                 = $certificateConfig.keys | ForEach-Object {$certificateConfig.$PSITEM.KeyLength} | Sort-Object -Descending | Select-Object -first 1
                        'HashAlgorithm'             = $certificateConfig.keys | ForEach-Object {$certificateConfig.$PSITEM.HashAlgorithm} | Sort-Object -Descending | Select-Object -first 1
                        'KeyUsageEKUExtension'      = $certificateConfig.keys | ForEach-Object {$certificateConfig.$PSITEM.EnhancedKeyUsage.Keys} | Sort-Object | Get-Unique
                        'KeyUsage'                  = $certificateConfig.keys | ForEach-Object {$certificateConfig.$PSITEM.KeyUsage.Keys} | Sort-Object | Get-Unique
                        'DistinguishedNameFlag'     = $DistinguishedNameFlag
                        'OutputRequestPath'         = $OutputRequestPathSeed
                        'LowPrivilege'              = $LowPrivilege
                    }
                    Write-AzsCertificateRequestFileInternal @csrParams
                }
                else {
                    foreach ($key in $certificateConfig.Keys) {
                        # Handle SANs for AzureStackEdgeDevice appliance certificates with DeviceName and NodeSerialNumbers
                        # Append region & fqdn to dnsname for the rest
                        $AzureStackEdgeDeviceApplianceCertificates = $certificateConfigDataFile.CertificateTypes.AzureStackEdgeDevice.Keys + `
                                                                     $certificateConfigDataFile.CertificateTypes.AzureStackEdgeVPN.Keys
                        if ($key -in $AzureStackEdgeDeviceApplianceCertificates) {
                            $certificateConfig.$key.DNSName = $certificateConfig.$key.DNSName | Foreach-Object { `
                                $PSITEM.replace('[[DeviceName]]',$PSBoundParameters.DeviceName).replace('[[NodeSerialNumber]]',$PSBoundParameters.NodeSerialNumber)
                            } | Sort-Object
                        }

                        # If region name exists, append region & fqdn to dnsname, otherwise just use fqdn
                        $subjectAlternativeNames = $certificateConfig.$key.DNSName | Foreach-Object { `
                            if ($PSITEM -ne '') {
                                "{0}.{1}" -f $PSITEM,$externalFQDN
                            }
                            else {
                                $externalFQDN
                            }
                        } | Sort-Object

                        # Set subject to first SAN or (if supplied) honour users common name
                        $commonName = $subjectAlternativeNames | Sort-Object -Descending | Select-Object -First 1
                        $certificateSubjectParams = @{
                            distinguishedName           = $DistinguishedName
                            DistinguishedNameFlag       = $DistinguishedNameFlag
                            commonName                  = $commonName
                        }
                        $certificateSubject = Set-CertificateSubject @certificateSubjectParams

                        # TO DO remove this hardcoding of CN for AzureStackEdgeDevice
                        if ($key -in $certificateConfigDataFile.CertificateTypes.AzureStackEdgeDevice.Keys) {
                            $certificateSubject = [System.Security.Cryptography.X509Certificates.X500DistinguishedName]::new("CN=$commonName")
                        }

                        # Check the object type of EKU
                        if ($certificateConfig.$key.EnhancedKeyUsage -is [HashTable]) {
                            $KeyUsageEKUExtension = $certificateConfig.$key.EnhancedKeyUsage.Keys
                        }
                        else {
                            $KeyUsageEKUExtension = $certificateConfig.$key.EnhancedKeyUsage
                        }

                        $OutputRequestPathSeed = Join-Path -Path $OutputRequestPath -ChildPath $commonName.Replace('.', '_').Replace('*', 'wildcard')
                        # Call CSR generation

                        $csrParams = @{
                            'subject'                   = $certificateSubject.decode($DistinguishedNameFlag)
                            'subjectAltNames'           = $SubjectAlternativeNames
                            'KeyLength'                 = $certificateConfig.$key.KeyLength
                            'HashAlgorithm'             = $certificateConfig.$key.HashAlgorithm
                            'KeyUsageEKUExtension'      = $KeyUsageEKUExtension
                            'KeyUsage'                  = $certificateConfig.$key.KeyUsage.Keys
                            'DistinguishedNameFlag'     = $DistinguishedNameFlag
                            'OutputRequestPath'         = $OutputRequestPathSeed
                            'LowPrivilege'              = $LowPrivilege
                        }
                        Write-AzsCertificateRequestFileInternal @csrParams
                    }
                }
                if ($LowPrivilege) {
                    Write-AzsReadinessLog -Message ("ACTIONS REQUIRED: `n`t 1) Copy templates from {0} to a system that allows elevation. `n`t 2) Run 'certreq -new <example.inf> <example.req>' to generate Certificate Request files." -f $OutputRequestPath) -Type Info -Function $thisFunction -toScreen
                }
            }
        }
        catch {
            Write-AzsReadinessLog -Message ("New-AzsCertificateSigningRequest failed with exception: {0}" -f $_.exception) -Type Error -Function $thisFunction -toScreen
        }
        finally {
            # Restore TLS back to default
            if ($ForceTLS12 -and $restoreSecurityProtocol) {
                Set-SecurityProtocol -securityProtocol $restoreSecurityProtocol
            }
            Write-Footer -invocation $MyInvocation
        }

    }
}

function Get-AzsCertificateRequestTypes {
    param ([string[]]$certificateTypeExclusions = @('Hardware'))
    $certificateConfigDataFile = Import-PowerShellDataFile -Path $PSScriptRoot\Microsoft.AzureStack.CertificateConfig.psd1
    $certificateTypes = $certificateConfigDataFile.CertificateTypes | Select-Object -ExpandProperty Keys | Where-Object {$PSITEM -notin $certificateTypeExclusions}
    $certificateTypes | Sort-Object
}

function New-SelfSignedHardwareCertificate {
    <#
    .SYNOPSIS
        Generates Self Signed Certificates for use with Hardware baseboard interfaces
    .DESCRIPTION
        Generates Self Signed Certificates for use with Hardware baseboard interfaces
        Overwrites existing pfx with the same name OutputPath\DNSName.pfx
    .EXAMPLE
        $outputPath = "$ENV:USERPROFILE\Documents\AzureStackCSR"
        $pfxPassword = Read-Host -Prompt "PFX Password" -AsSecureString
        New-SelfSignedHardwareCertificate -CertificateType BMC -DnsRecord node01-bmc -pfxPassword $pfxPassword -OutputPath $ENV:USERPROFILE\Documents\AzureStackCSR
        Creates a self-signed certificate for BMC with a dnsname of node01-bmc and places the pfx in $ENV:USERPROFILE\Documents\AzureStackCSR\node01-bmc.pfx
    .EXAMPLE
        $json = Get-Content "C:\Users\jerskine\OneDrive - Microsoft\DocumentsMSOneDrive\AzureStack\AzsReadinessChecker\TestAssets\DeploymentData.json" | Convertfrom-Json
        $outputPath = "$ENV:USERPROFILE\Documents\AzureStackCSR"
        $pfxPassword = Read-Host -Prompt "PFX Password" -AsSecureString
        $NodeDnsNames = $json.DeploymentData.PhysicalNodes.Name | Foreach-Object {"{0}.{1}.{2}" -f $PSITEM,$json.DeploymentData.RegionName, $json.DeploymentData.ExternalDomainFQDN}
        $NodeDnsNames | Foreach-Object {New-SelfSignedHardwareCertificate -CertificateType BMC -DnsRecord $PSITEM -pfxPassword $pfxPassword -OutputPath $outputPath}
        Creates a self-signed certificate for BMC for each node in a deploymentdata.json
    .OUTPUTS
        PFX File Path - String
    .NOTES
        Intended for deployment team usage at deployment site.
    #>
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'Medium')]
    param (
        [Parameter(Mandatory = $true, HelpMessage = "DNS Name for Certificate")]
        [string]
        $DnsRecord,
        [Parameter(Mandatory = $true, HelpMessage = "Password for Certificate")]
        [securestring]
        $pfxPassword,
        [Parameter(Mandatory = $true, HelpMessage = "Destination Path for Certificate")]
        [ValidateScript( {Test-Path -Path $_ -PathType Container <# should be a valid directory path #>})]
        [string]$OutputPath,
        [Parameter(Mandatory = $false, HelpMessage = "Leave certificate in store and pass System.Security.Cryptography.X509Certificates.X509Certificate2 object")]
        [switch]$passThru
    )
    DynamicParam {
        #Certificate Type Param
        $ParamAttrib = New-Object  System.Management.Automation.ParameterAttribute
        $ParamAttrib.Mandatory = $true
        $ParamAttrib.ParameterSetName = '__AllParameterSets'

        $AttribColl = New-Object  System.Collections.ObjectModel.Collection[System.Attribute]
        $AttribColl.Add($ParamAttrib)

        $certificateConfigDataFile = Import-PowerShellDataFile -Path $PSScriptRoot\Microsoft.AzureStack.CertificateConfig.psd1
        $certificateTypes = $certificateConfigDataFile.CertificateTypes.Hardware | Select-Object -ExpandProperty Keys
        $AttribColl.Add((New-Object  System.Management.Automation.ValidateSetAttribute($certificateTypes)))

        $RuntimeParam = New-Object  System.Management.Automation.RuntimeDefinedParameter('CertificateType', [string],  $AttribColl)

        $RuntimeParamDic = New-Object  System.Management.Automation.RuntimeDefinedParameterDictionary
        $RuntimeParamDic.Add('CertificateType', $RuntimeParam)

        return $RuntimeParamDic
    }
    process
    {
        try {
            # Ensure we are elevated
            if (Test-Elevation)
            {
                Write-AzsReadinessLog -Message ("Powershell running as Administrator. Continuing.") -Type Info
            }
            else
            {
                Write-AzsReadinessLog -Message ("Running as administrator is required for this operation.  `nPlease restart PowerShell as Administrator and retry.") -Type Error -toScreen
                Write-AzsReadinessLog -Message ("This is because sensitive key material must be generated in order to create a self signed certificate.") -Type Error -toScreen
                throw "This operation requires elevation."
            }

            Import-Module $PSScriptRoot\PublicCertHelper.psd1 -force
            $certPath = 'cert:/localmachine/my'

            # Get Certificate from config
            $certificateConfig = $certificateConfigDataFile.CertificateTypes.Hardware[$PSBoundParameters.CertificateType]

            # Get certificate default and replace with any values with user supplied values
            $CertificateDefaults = $certificateConfigDataFile.CertificateDefaults

            $certConfig = @{}
            foreach ($key in $certificateConfig.Keys) {
                if ($certificateConfig.$key -eq 'default') {
                    $certConfig.Add($key,$CertificateDefaults.$key)
                }
                else {
                    $certConfig.Add($key,$certificateConfig.$key)
                }
            }

            $NewCertParams = @{
                dnsname = $DnsRecord
                KeyUsage = @($certConfig.KeyUsage.Keys)
                HashAlgorithm = $certConfig.HashAlgorithm
                KeyLength = $certConfig.KeyLength
                NotAfter = [System.Datetime]::Now.AddYears(2)
                KeyUsageProperty = 'All'
                Provider = "Microsoft Enhanced RSA and AES Cryptographic Provider"
                KeyExportPolicy = 'Exportable'
                certstorelocation = $certPath
            }

            $certificate = New-SelfSignedCertificate @NewCertParams
            $filePath = Join-Path -Path $OutputPath -ChildPath "$DnsRecord.pfx"
            Export-AzsCertificate -filePath $filePath -certPath $certificate -pfxPassword $pfxPassword
        }
        catch {
            throw $_.exception
        }
        finally {
            if ($passThru) {
                $certificate
            }
            else {
                $certificate | Remove-Item -Force -ErrorAction Continue
                $filePath
            }
        }
    }
}

function ConvertTo-PEM {
    <#
    .SYNOPSIS
        Write the certificate in pem format.
    .DESCRIPTION
        Write the certificate in pem format.
    .EXAMPLE
        $cert = Get-Item Cert:\LocalMachine\my\04B781836CD350D78888FAC5612BCEBA9C2FA25F
        $path = "C:\scratch\{0}.key" -f $cert.Thumbprint
        ConvertTo-PEM -certificate $cert -path $path
        Convert the certificate to PEM format and generate key file.
#>
    [CmdletBinding()]
    param (
        [System.Security.Cryptography.X509Certificates.X509Certificate2]
        $certificate,
        [ValidateScript( { Test-Path $PSITEM -PathType Container } <#parent path must exist#>)]
        [string]$path
    )
    try {
        # Ensure we are elevated
        if (Test-Elevation)
        {
            Write-AzsReadinessLog -Message ("Powershell running as Administrator. Continuing.") -Type Info
        }
        else
        {
            Write-AzsReadinessLog -Message ("Running as administrator is required for this operation.  `nPlease restart PowerShell as Administrator and retry.") -Type Error -toScreen
            Write-AzsReadinessLog -Message ("This is because sensitive key material must be loaded in order to write it to file.") -Type Error -toScreen
            throw "This operation requires elevation."
        }

        # build string
        $sb = [System.Text.StringBuilder]::new()
        [void]$sb.AppendLine('-----BEGIN CERTIFICATE-----')
        $base64 = [System.Convert]::ToBase64String($certificate.RawData, "InsertLineBreaks")
        [void]$sb.AppendLine($base64)
        [void]$sb.AppendLine('-----END CERTIFICATE-----')

        # write to file
        $filePath = "{0}\{1}.pem" -f $Path, $certificate.Thumbprint
        $stream = [System.IO.StreamWriter]::new($filePath)
        $stream.WriteLine($sb.ToString())
        $stream.close()
        Write-Verbose "Finished $filePath"

        if ($certificate.HasPrivateKey) {
            $key = Write-PrivateKeyFile -path $path -certificate $certificate
        }
        else {
            Write-Verbose "Certificate does not contain private key, key file cannot be written"
        }

        if (-not $key) {
            Write-Verbose "Failed to create key file"
        }
        $path
    }
    catch {
        throw $_
    }
}

function Write-PrivateKeyFile {
    <#
    .SYNOPSIS
        Write the private key of a certificate in pem format.
    .DESCRIPTION
        Write the private key of a certificate in pem format.
    .EXAMPLE
        $cert = Get-Item Cert:\LocalMachine\my\04B781836CD350D78888FAC5612BCEBA9C2FA25F
        $path = "C:\scratch\{0}.key" -f $cert.Thumbprint
        Write-PrivateKeyFile -certificate $cert -path $path
        Write the private key of certificate to a file named after the certificate thumbprint.
#>
    [CmdletBinding()]
    param (
        [System.Security.Cryptography.X509Certificates.X509Certificate2]
        $certificate,
        [ValidateScript( { Test-Path $PSITEM -PathType Container } <#parent path must exist#>)]
        [string]$path
    )

    try {
        # Get key material
        $key = [System.Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPrivateKey($certificate)
        $Pkcs8 = $key.key.Export([System.Security.Cryptography.CngKeyBlobFormat]::Pkcs8PrivateBlob)
        $base64 = [Convert]::ToBase64String($Pkcs8, "InsertLineBreaks")

        # Build key string
        $sb = [System.Text.StringBuilder]::new()
        [void]$sb.AppendLine('-----BEGIN RSA PRIVATE KEY-----')
        [void]$sb.AppendLine($base64)
        [void]$sb.AppendLine("-----END RSA PRIVATE KEY-----")

        # write to file
        $filePath = "{0}\{1}.key" -f $Path, $certificate.Thumbprint
        $stream = [System.IO.StreamWriter]::new($filePath)
        $stream.WriteLine($sb.ToString())
        $stream.close()
        Write-Verbose "Finished $filePath"
        $path
    }
    catch {
        Write-Verbose "Unable to create private key file err: $($_.exception.message)"
    }
}

function New-AzsEdgeDeviceCertificateSigningRequest {
    <#
    .SYNOPSIS
        Generates Certificate Signing Requests for Azure Stack Edge Device Certificates
    .DESCRIPTION
        Calls New-AzsCertificateSigningRequest with neccessary parameters to generate CSR for Azure Stack Edge Device certificates
    .EXAMPLE
        $certificateRequestParams = @{
            DeviceName = 'DBG-KARB2NP5J'
            NodeSerialNumber = 'WIN-KARB2NP5J3O'
            externalFQDN = 'azurestackedge.contoso.com'
            OutputRequestPath = "$ENV:USERPROFILE\Documents\AzsCertRequests"
        }
        New-AzsEdgeDeviceCertificateSigningRequest @certificateRequestParams
        Generates Certificate Signing Requests for Azure Stack Edge Device Certificates
    .EXAMPLE
        $certificateRequestParams = @{
            DeviceName = 'DBG-KARB2NP5J'
            NodeSerialNumber = 'WIN-KARB2NP5J3O','WIN-GBWB7ML4K9O'
            externalFQDN = 'azurestackedge.contoso.com'
            OutputRequestPath = "$ENV:USERPROFILE\Documents\AzsCertRequests"
        }
        New-AzsEdgeDeviceCertificateSigningRequest @certificateRequestParams
        Generates Certificate Signing Requests for multi-node Azure Stack Edge Device Certificates
    .PARAMETER DeviceName
        Specifies the serial number of an Azure Stack Edge device.
    .PARAMETER NodeSerialNumber
        Specifies the node name(s) of an Azure Stack Edge device.
    .PARAMETER externalFQDN
        Specifies the Azure Stack deployment's External FQDN, also aliased as ExternalFQDN and FQDN, must be valid DNSHostName
    .PARAMETER OutputRequestPath
        Specifies the destination path for certificate request files, directory must already exist.
    .PARAMETER LowPrivilege
        Use in low privilege environment were elevation is not allowed. Generates INF certificate request templates.
#>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false, HelpMessage = 'Provide subject name as a string, CN is not required and will be overwritten. E.g. "C=US,ST=Washington,L=Redmond,O=Microsoft,OU=Azure Stack"')]
        [Alias("Subject")]
        [System.Security.Cryptography.X509Certificates.X500DistinguishedName]$DistinguishedName,

        [Parameter(Mandatory = $false, HelpMessage = 'Provide X500DistinguishedNameFlags if The distinguished name has special characteristics. Default UseUTF8Encoding.')]
        [System.Security.Cryptography.X509Certificates.X500DistinguishedNameFlags]$DistinguishedNameFlag = 'UseUTF8Encoding',

        [Parameter(Mandatory = $true, HelpMessage = "Enter the Device Name of an Azure Stack Edge device.")]
        [string]$DeviceName,

        [Parameter(Mandatory = $true, HelpMessage = "Enter the Node Serial Number of an Azure Stack Edge device.")]
        [string[]]$NodeSerialNumber,

        [Parameter(Mandatory = $false, HelpMessage = 'Provide Key Length: 2048, 4096 or 8192')]
        [ValidateSet(2048, 4096, 8192)]
        [int]$KeyLength = 2048,

        [Parameter(Mandatory = $false, HelpMessage = 'Provide Hash Algorithm: SHA256, SHA384 or SHA512')]
        [ValidateSet('SHA256', 'SHA384', 'SHA512')]
        [System.Security.Cryptography.HashAlgorithmName]$HashAlgorithm = 'SHA256',

        [Parameter(Mandatory = $false, HelpMessage = "Optionally provide Extended (Enhanced) Key Usage. By default, certificate config will be used. e.g. @('Client Authentication', 'Server Authentication', @{'Custom Usage' = '1.3.6.1.5.15.7.3.2'})")]
        $EnhancedKeyUsage,

        [Parameter(Mandatory = $false, HelpMessage = "Enter Certificate Request generation type ('Single' = Request individual wildcard certificates, 'Multiple' = Request single multi domain wildcard certificates")]
        [ValidateSet('MultipleCSR', 'SingleCSR')]
        [string]$requestType = 'MultipleCSR',

        [Parameter(Mandatory = $true, HelpMessage = "Enter Azure Stack Fully Qualified Domain Name (without region name)")]
        [Alias("FQDN", "ExternalDomainName")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        [string]$ExternalFQDN,

        [Parameter(Mandatory = $true, HelpMessage = "Destination Path for Certificate Request(s)")]
        [ValidateScript( {Test-Path -Path $_ -PathType Container <# should be a valid directory path #>})]
        [string]$OutputRequestPath,

        [Parameter(Mandatory = $false, HelpMessage = "Directory path for log and report output")]
        [string]$OutputPath = "$ENV:TEMP\AzsReadinessChecker",

        [Parameter(Mandatory = $false, HelpMessage = "Use in low privilege environment were elevation is not allowed. Generates INF certificate request templates.")]
        [switch]$LowPrivilege

    )
    New-AzsCertificateSigningRequest @PSBoundParameters -CertificateType AzureStackEdgeDevice
}

function New-AzsEdgeVPNCertificateSigningRequest {
    <#
    .SYNOPSIS
        Generates Certificate Signing Requests for Azure Stack Edge VPN Certificates
    .DESCRIPTION
        Calls New-AzsCertificateSigningRequest with neccessary parameters to generate CSR for Azure Stack Edge VPN certificates
    .EXAMPLE
        $certificateRequestParams = @{
            Subject = "C=US,ST=Washington,L=Redmond,O=Microsoft,OU=Azure Stack Edge"
            externalFQDN = 'azurestackedge.contoso.com'
            OutputRequestPath = "$ENV:USERPROFILE\Documents\AzsCertRequests"
        }
        New-AzsEdgeVPNCertificateSigningRequest @certificateRequestParams
        Generates Certificate Signing Requests for Azure Stack Edge VPN Certificates
    .PARAMETER externalFQDN
        Specifies the Azure Stack deployment's External FQDN, also aliased as ExternalFQDN and FQDN, must be valid DNSHostName
    .PARAMETER DistinguishedName
        Specifies a DistinguishedName to be used on the certificate.  Must be a valid System.Security.Cryptography.X509Certificates.X500DistinguishedName value.
        Common Name (CN) is not required, the appropriate value for the Azure Stack Service will be placed in the Common Name (CN).
        If a Common Name (CN) is given it will be honoured on every certificate request if supplied.
        Also aliased as subject.
    .PARAMETER DistinguishedNameFlag
        Specifies a string for the distinguished name flag to be used in the distinguished name.  UseUTF8Encoding is selected by default. More information on x500DistinguishNameFlags
        can be found at https://aka.ms/dnflags
    .PARAMETER KeyLength
        Defines the length of the public and private key for the certificate request generation. Default is 2048. Valid values 2048, 4096, 8192
    .PARAMETER HashAlgorithm
        Hash Algorithm to be used for the certificate request generation. Default is SHA256. Valid values SHA256, SHA384, SHA512
    .PARAMETER EnhancedKeyUsage
        Extended (Enhanced) Key Usage to be included in the certificate request. Provide the required usage for the target certificate as well as the custom usage in hashtable format.
        e.g. @('Client Authentication','Server Authentication',@{'Custom Usage' = '1.3.6.1.5.7.8.2.1'}) will request Client and Server Auth key usage and the custom usage.
    .PARAMETER RequestType
        Specifies the SAN type of the certificate request. Valid values: MultipleCSR, SingleCSR.
        SingleCSR generates one certificate request for all services (not recommended for production). User will be prompted to confirm use.
        MultipleCSR generates multiple certificate requests, one for each service (strongly recommended in production environments).
    .PARAMETER OutputRequestPath
        Specifies the destination path for certificate request files, directory must already exist.
    .PARAMETER OutputPath
        Specifies custom path to save verbose log file.
    .PARAMETER LowPrivilege
        Use in low privilege environment were elevation is not allowed. Generates INF certificate request templates.
#>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true, HelpMessage = 'Provide subject name as a string, CN is not required and will be overwritten. E.g. "C=US,ST=Washington,L=Redmond,O=Microsoft,OU=Azure Stack"')]
        [Alias("Subject")]
        [System.Security.Cryptography.X509Certificates.X500DistinguishedName]$DistinguishedName,

        [Parameter(Mandatory = $false, HelpMessage = 'Provide X500DistinguishedNameFlags if The distinguished name has special characteristics. Default UseUTF8Encoding.')]
        [System.Security.Cryptography.X509Certificates.X500DistinguishedNameFlags]$DistinguishedNameFlag = 'UseUTF8Encoding',

        [Parameter(Mandatory = $false, HelpMessage = 'Provide Key Length: 2048, 4096 or 8192')]
        [ValidateSet(2048, 4096, 8192)]
        [int]$KeyLength = 2048,

        [Parameter(Mandatory = $false, HelpMessage = 'Provide Hash Algorithm: SHA256, SHA384 or SHA512')]
        [ValidateSet('SHA256', 'SHA384', 'SHA512')]
        [System.Security.Cryptography.HashAlgorithmName]$HashAlgorithm = 'SHA256',

        [Parameter(Mandatory = $false, HelpMessage = "Optionally provide Extended (Enhanced) Key Usage. By default, certificate config will be used. e.g. @('Client Authentication', 'Server Authentication', @{'Custom Usage' = '1.3.6.1.5.15.7.3.2'})")]
        $EnhancedKeyUsage,

        [Parameter(Mandatory = $false, HelpMessage = "Enter Certificate Request generation type ('Single' = Request individual wildcard certificates, 'Multiple' = Request single multi domain wildcard certificates")]
        [ValidateSet('MultipleCSR', 'SingleCSR')]
        [string]$requestType = 'MultipleCSR',

        [Parameter(Mandatory = $true, HelpMessage = "Enter Azure Stack Fully Qualified Domain Name (without region name)")]
        [Alias("FQDN", "ExternalDomainName")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        [string]$ExternalFQDN,

        [Parameter(Mandatory = $true, HelpMessage = "Destination Path for Certificate Request(s)")]
        [ValidateScript( {Test-Path -Path $_ -PathType Container <# should be a valid directory path #>})]
        [string]$OutputRequestPath,

        [Parameter(Mandatory = $false, HelpMessage = "Directory path for log and report output")]
        [string]$OutputPath = "$ENV:TEMP\AzsReadinessChecker",

        [Parameter(Mandatory = $false, HelpMessage = "Use in low privilege environment were elevation is not allowed. Generates INF certificate request templates.")]
        [switch]$LowPrivilege

    )
    New-AzsCertificateSigningRequest @PSBoundParameters -CertificateType AzureStackEdgeVPN
}

function New-AzsHubDeploymentCertificateSigningRequest {
    <#
    .SYNOPSIS
        Generates Certificate Signing Requests for Azure Stack Hub Deployment Certificates
    .DESCRIPTION
        Calls New-AzsCertificateSigningRequest with neccessary parameters to generate CSR for Azure Stack Hub Deployment certificates
    .EXAMPLE
        $certificateRequestParams = @{
            'IdentitySystem' = 'AAD'
            'regionName' = 'azurestack'
            'externalFQDN' = 'contoso.com'
            'subject' = "C=US,ST=Washington,L=Redmond,O=Microsoft,OU=Azure Stack"
            'OutputRequestPath' = "$ENV:USERPROFILE\Documents\AzsCertRequests"
        }
        New-AzsHubDeploymentCertificateSigningRequest @certificateRequestParams
        Generates Certificate Signing Requests for Azure Stack Hub Deployment Certificates
    .EXAMPLE
        New-AzsHubDeploymentCertificateSigningRequest -StampEndpoint portal.azurestack.contoso.com -OutputRequestPath "$ENV:USERPROFILE\Documents\AzsCertRequests"
        Connects to existing endpoint https://portal.azurestack.contoso.com read the current SSL certificate, clones the attributes and creates Certificate Signing Requests with those attributes.
        For use with renewal of soon-to-be expired certs.
    .PARAMETER RegionName
        Specifies the Azure Stack deployment's region name, must be alphanumeric.
    .PARAMETER externalFQDN
        Specifies the Azure Stack deployment's External FQDN, also aliased as ExternalFQDN and FQDN, must be valid DNSHostName
    .PARAMETER DistinguishedName
        Specifies a DistinguishedName to be used on the certificate.  Must be a valid System.Security.Cryptography.X509Certificates.X500DistinguishedName value.
        Common Name (CN) is not required, the appropriate value for the Azure Stack Service will be placed in the Common Name (CN).
        If a Common Name (CN) is given it will be honoured on every certificate request if supplied.
        Also aliased as subject.
    .PARAMETER DistinguishedNameFlag
        Specifies a string for the distinguished name flag to be used in the distinguished name.  UseUTF8Encoding is selected by default. More information on x500DistinguishNameFlags
        can be found at https://aka.ms/dnflags
    .PARAMETER KeyLength
        Defines the length of the public and private key for the certificate request generation. Default is 2048. Valid values 2048, 4096, 8192
    .PARAMETER HashAlgorithm
        Hash Algorithm to be used for the certificate request generation. Default is SHA256. Valid values SHA256, SHA384, SHA512
    .PARAMETER EnhancedKeyUsage
        Extended (Enhanced) Key Usage to be included in the certificate request. Provide the required usage for the target certificate as well as the custom usage in hashtable format.
        e.g. @('Client Authentication','Server Authentication',@{'Custom Usage' = '1.3.6.1.5.7.8.2.1'}) will request Client and Server Auth key usage and the custom usage.
    .PARAMETER RequestType
        Specifies the SAN type of the certificate request. Valid values: MultipleCSR, SingleCSR.
        SingleCSR generates one certificate request for all services (not recommended for production). User will be prompted to confirm use.
        MultipleCSR generates multiple certificate requests, one for each service (strongly recommended in production environments).
    .PARAMETER IdentitySystem
        Specifies the Azure Stack deployment's Identity System valid values, AAD or ADFS, for Azure Active Directory and Active Directory Federated Services respectively
    .PARAMETER StampEndpoint
        Provide a dns hostname of an existing stamp endpoint (region.external.fqdn) to clone the certificate attributes to be used to generate the certificate signing request.
    .PARAMETER OutputRequestPath
        Specifies the destination path for certificate request files, directory must already exist.
    .PARAMETER ForceTLS12
        Force the use of TLS 1.2, true by default, set to false to use to system default.
    .PARAMETER LowPrivilege
        Use in low privilege environment were elevation is not allowed. Generates INF certificate request templates.
    .INPUTS
        Inputs (if any)
    .OUTPUTS
        Output (if any)
    .LINK
        Generate Azure Stack Certificate Requests - https://aka.ms/AzsCSR
        Azure Stack Readiness Checker Tool - https://aka.ms/AzsReadinessChecker
    .NOTES
        General notes
    #>
    [CmdletBinding(DefaultParameterSetName = 'Manual')]
    param (
        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = "Enter Azure Stack Hub Region Name")]
        [string]$RegionName,

        [Parameter(Mandatory = $true, ParameterSetName = 'Manual', HelpMessage = "Enter Azure Stack Fully Qualified Domain Name (without region name)")]
        [Alias("FQDN", "ExternalDomainName")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        [string]$ExternalFQDN,

        [Parameter(Mandatory = $true, ParameterSetName = 'Manual', HelpMessage = 'Provide subject name as a string, CN is not required and will be overwritten. E.g. "C=US,ST=Washington,L=Redmond,O=Microsoft,OU=Azure Stack"')]
        [Alias("Subject")]
        [System.Security.Cryptography.X509Certificates.X500DistinguishedName]$DistinguishedName,

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = 'Provide X500DistinguishedNameFlags if The distinguished name has special characteristics. Default UseUTF8Encoding.')]
        [System.Security.Cryptography.X509Certificates.X500DistinguishedNameFlags]$DistinguishedNameFlag = 'UseUTF8Encoding',

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = 'Provide Key Length: 2048, 4096 or 8192')]
        [ValidateSet(2048, 4096, 8192)]
        [int]$KeyLength = 2048,

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = 'Provide Hash Algorithm: SHA256, SHA384 or SHA512')]
        [ValidateSet('SHA256', 'SHA384', 'SHA512')]
        [System.Security.Cryptography.HashAlgorithmName]$HashAlgorithm = 'SHA256',

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = "Optionally provide Extended (Enhanced) Key Usage. By default, certificate config will be used. e.g. @('Client Authentication', 'Server Authentication', @{'Custom Usage' = '1.3.6.1.5.15.7.3.2'})")]
        $EnhancedKeyUsage,

        [Parameter(Mandatory = $true, ParameterSetName = 'ExistingEndpoint', HelpMessage = "Optionally provide an existing stamp endpoint (region.fqdn) to clone the certificate attributes to be used to generate the certificate signing request.")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        $StampEndpoint,

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = "Enter Azure Stack Identity System (AAD or ADFS) when generating deployment certificates")]
        [ValidateSet('AAD', 'ADFS')]
        [string]$IdentitySystem,

        [Parameter(Mandatory = $false, HelpMessage = "Enter Certificate Request generation type ('Single' = Request individual wildcard certificates, 'Multiple' = Request single multi domain wildcard certificates")]
        [ValidateSet('MultipleCSR', 'SingleCSR')]
        [string]$requestType = 'MultipleCSR',

        [Parameter(Mandatory = $true, HelpMessage = "Destination Path for Certificate Request(s)")]
        [ValidateScript( {Test-Path -Path $_ -PathType Container <# should be a valid directory path #>})]
        [string]$OutputRequestPath,

        [Parameter(Mandatory = $false, ParameterSetName = 'ExistingEndpoint', HelpMessage = "Force the use of TLS 1.2, true by default")]
        [bool]$ForceTLS12 = $true,

        [Parameter(Mandatory = $false, HelpMessage = "Directory path for log and report output")]
        [string]$OutputPath = "$ENV:TEMP\AzsReadinessChecker",

        [Parameter(Mandatory = $false, HelpMessage = "Use in low privilege environment were elevation is not allowed. Generates INF certificate request templates.")]
        [switch]$LowPrivilege

    )
    New-AzsCertificateSigningRequest @PSBoundParameters -CertificateType Deployment
}

function New-AzsHubAppServicesCertificateSigningRequest {
    <#
    .SYNOPSIS
        Generates Certificate Signing Requests for Azure Stack Hub AppServices Resource Provider Certificates
    .DESCRIPTION
        Calls New-AzsCertificateSigningRequest with neccessary parameters to generate CSR for Azure Stack Hub AppServices Resource Provider certificates
    .EXAMPLE
        $certificateRequestParams = @{
            'regionName' = 'azurestack'
            'externalFQDN' = 'contoso.com'
            'subject' = "C=US,ST=Washington,L=Redmond,O=Microsoft,OU=Azure Stack"
            'OutputRequestPath' = "$ENV:USERPROFILE\Documents\AzsCertRequests"
        }
        New-AzsHubAppServicesCertificateSigningRequest @certificateRequestParams
        Generates Certificate Signing Requests for Azure Stack Hub AppServices Resource Provider Certificates
    .EXAMPLE
        New-AzsHubAppServicesCertificateSigningRequest -StampEndpoint portal.azurestack.contoso.com -OutputRequestPath "$ENV:USERPROFILE\Documents\AzsCertRequests"
        Connects to existing endpoint https://portal.azurestack.contoso.com read the current SSL certificate, clones the attributes and creates Certificate Signing Requests with those attributes.
        For use with renewal of soon-to-be expired certs.
    .PARAMETER RegionName
        Specifies the Azure Stack deployment's region name, must be alphanumeric.
    .PARAMETER externalFQDN
        Specifies the Azure Stack deployment's External FQDN, also aliased as ExternalFQDN and FQDN, must be valid DNSHostName
    .PARAMETER DistinguishedName
        Specifies a DistinguishedName to be used on the certificate.  Must be a valid System.Security.Cryptography.X509Certificates.X500DistinguishedName value.
        Common Name (CN) is not required, the appropriate value for the Azure Stack Service will be placed in the Common Name (CN).
        If a Common Name (CN) is given it will be honoured on every certificate request if supplied.
        Also aliased as subject.
    .PARAMETER DistinguishedNameFlag
        Specifies a string for the distinguished name flag to be used in the distinguished name.  UseUTF8Encoding is selected by default. More information on x500DistinguishNameFlags
        can be found at https://aka.ms/dnflags
    .PARAMETER KeyLength
        Defines the length of the public and private key for the certificate request generation. Default is 2048. Valid values 2048, 4096, 8192
    .PARAMETER HashAlgorithm
        Hash Algorithm to be used for the certificate request generation. Default is SHA256. Valid values SHA256, SHA384, SHA512
    .PARAMETER EnhancedKeyUsage
        Extended (Enhanced) Key Usage to be included in the certificate request. Provide the required usage for the target certificate as well as the custom usage in hashtable format.
        e.g. @('Client Authentication','Server Authentication',@{'Custom Usage' = '1.3.6.1.5.7.8.2.1'}) will request Client and Server Auth key usage and the custom usage.
    .PARAMETER StampEndpoint
        Provide a dns hostname of an existing stamp endpoint (region.external.fqdn) to clone the certificate attributes to be used to generate the certificate signing request.
    .PARAMETER RequestType
        Specifies the SAN type of the certificate request. Valid values: MultipleCSR, SingleCSR.
        SingleCSR generates one certificate request for all services (not recommended for production). User will be prompted to confirm use.
        MultipleCSR generates multiple certificate requests, one for each service (strongly recommended in production environments).
    .PARAMETER OutputRequestPath
        Specifies the destination path for certificate request files, directory must already exist.
    .PARAMETER ForceTLS12
        Force the use of TLS 1.2, true by default, set to false to use to system default.
    .PARAMETER LowPrivilege
        Use in low privilege environment were elevation is not allowed. Generates INF certificate request templates.
    .INPUTS
        Inputs (if any)
    .OUTPUTS
        Output (if any)
    .LINK
        Generate Azure Stack Certificate Requests - https://aka.ms/AzsCSR
        Azure Stack Readiness Checker Tool - https://aka.ms/AzsReadinessChecker
    .NOTES
        General notes
    #>
    [CmdletBinding(DefaultParameterSetName = 'Manual')]
    param (
        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = "Enter Azure Stack Hub Region Name")]
        [string]$RegionName,

        [Parameter(Mandatory = $true, ParameterSetName = 'Manual', HelpMessage = "Enter Azure Stack Fully Qualified Domain Name (without region name)")]
        [Alias("FQDN", "ExternalDomainName")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        [string]$ExternalFQDN,

        [Parameter(Mandatory = $true, ParameterSetName = 'Manual', HelpMessage = 'Provide subject name as a string, CN is not required and will be overwritten. E.g. "C=US,ST=Washington,L=Redmond,O=Microsoft,OU=Azure Stack"')]
        [Alias("Subject")]
        [System.Security.Cryptography.X509Certificates.X500DistinguishedName]$DistinguishedName,

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = 'Provide X500DistinguishedNameFlags if The distinguished name has special characteristics. Default UseUTF8Encoding.')]
        [System.Security.Cryptography.X509Certificates.X500DistinguishedNameFlags]$DistinguishedNameFlag = 'UseUTF8Encoding',

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = 'Provide Key Length: 2048, 4096 or 8192')]
        [ValidateSet(2048, 4096, 8192)]
        [int]$KeyLength = 2048,

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = 'Provide Hash Algorithm: SHA256, SHA384 or SHA512')]
        [ValidateSet('SHA256', 'SHA384', 'SHA512')]
        [System.Security.Cryptography.HashAlgorithmName]$HashAlgorithm = 'SHA256',

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = "Optionally provide Extended (Enhanced) Key Usage. By default, certificate config will be used. e.g. @('Client Authentication', 'Server Authentication', @{'Custom Usage' = '1.3.6.1.5.15.7.3.2'})")]
        $EnhancedKeyUsage,

        [Parameter(Mandatory = $true, ParameterSetName = 'ExistingEndpoint', HelpMessage = "Optionally provide an existing stamp endpoint (region.external.fqdn) to clone the certificate attributes to be used to generate the certificate signing request.")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        $StampEndpoint,

        [Parameter(Mandatory = $false, HelpMessage = "Enter Certificate Request generation type ('Single' = Request individual wildcard certificates, 'Multiple' = Request single multi domain wildcard certificates")]
        [ValidateSet('MultipleCSR', 'SingleCSR')]
        [string]$requestType = 'MultipleCSR',

        [Parameter(Mandatory = $true, HelpMessage = "Destination Path for Certificate Request(s)")]
        [ValidateScript( {Test-Path -Path $_ -PathType Container <# should be a valid directory path #>})]
        [string]$OutputRequestPath,

        [Parameter(Mandatory = $false, ParameterSetName = 'ExistingEndpoint', HelpMessage = "Force the use of TLS 1.2, true by default")]
        [bool]$ForceTLS12 = $true,

        [Parameter(Mandatory = $false, HelpMessage = "Directory path for log and report output")]
        [string]$OutputPath = "$ENV:TEMP\AzsReadinessChecker",

        [Parameter(Mandatory = $false, HelpMessage = "Use in low privilege environment were elevation is not allowed. Generates INF certificate request templates.")]
        [switch]$LowPrivilege

    )
    New-AzsCertificateSigningRequest @PSBoundParameters -CertificateType AppServices
}

function New-AzsHubEventHubsCertificateSigningRequest {
    <#
    .SYNOPSIS
        Generates Certificate Signing Requests for Azure Stack Hub Event Hubs Resource Provider Certificates
    .DESCRIPTION
        Calls New-AzsCertificateSigningRequest with neccessary parameters to generate CSR for Azure Stack Hub Event Hubs Resource Provider certificates
    .EXAMPLE
        $certificateRequestParams = @{
            'regionName' = 'azurestack'
            'externalFQDN' = 'contoso.com'
            'subject' = "C=US,ST=Washington,L=Redmond,O=Microsoft,OU=Azure Stack"
            'OutputRequestPath' = "$ENV:USERPROFILE\Documents\AzsCertRequests"
        }
        New-AzsHubEventHubsCertificateSigningRequest @certificateRequestParams
        Generates Certificate Signing Requests for Azure Stack Hub EventHubs Resource Provider Certificates
    .EXAMPLE
        New-AzsHubEventHubsCertificateSigningRequest -StampEndpoint portal.azurestack.contoso.com -OutputRequestPath "$ENV:USERPROFILE\Documents\AzsCertRequests"
        Connects to existing endpoint https://portal.azurestack.contoso.com read the current SSL certificate, clones the attributes and creates Certificate Signing Requests with those attributes.
        For use with renewal of soon-to-be expired certs.
    .PARAMETER RegionName
        Specifies the Azure Stack deployment's region name, must be alphanumeric.
    .PARAMETER externalFQDN
        Specifies the Azure Stack deployment's External FQDN, also aliased as ExternalFQDN and FQDN, must be valid DNSHostName
    .PARAMETER DistinguishedName
        Specifies a DistinguishedName to be used on the certificate.  Must be a valid System.Security.Cryptography.X509Certificates.X500DistinguishedName value.
        Common Name (CN) is not required, the appropriate value for the Azure Stack Service will be placed in the Common Name (CN).
        If a Common Name (CN) is given it will be honoured on every certificate request if supplied.
        Also aliased as subject.
    .PARAMETER DistinguishedNameFlag
        Specifies a string for the distinguished name flag to be used in the distinguished name.  UseUTF8Encoding is selected by default. More information on x500DistinguishNameFlags
        can be found at https://aka.ms/dnflags
    .PARAMETER KeyLength
        Defines the length of the public and private key for the certificate request generation. Default is 2048. Valid values 2048, 4096, 8192
    .PARAMETER HashAlgorithm
        Hash Algorithm to be used for the certificate request generation. Default is SHA256. Valid values SHA256, SHA384, SHA512
    .PARAMETER EnhancedKeyUsage
        Extended (Enhanced) Key Usage to be included in the certificate request. Provide the required usage for the target certificate as well as the custom usage in hashtable format.
        e.g. @('Client Authentication','Server Authentication',@{'Custom Usage' = '1.3.6.1.5.7.8.2.1'}) will request Client and Server Auth key usage and the custom usage.
    .PARAMETER RequestType
        Specifies the SAN type of the certificate request. Valid values: MultipleCSR, SingleCSR.
        SingleCSR generates one certificate request for all services (not recommended for production). User will be prompted to confirm use.
        MultipleCSR generates multiple certificate requests, one for each service (strongly recommended in production environments).
    .PARAMETER StampEndpoint
        Provide a dns hostname of an existing stamp endpoint (region.external.fqdn) to clone the certificate attributes to be used to generate the certificate signing request.
    .PARAMETER OutputRequestPath
        Specifies the destination path for certificate request files, directory must already exist.
    .PARAMETER ForceTLS12
        Force the use of TLS 1.2, true by default, set to false to use to system default.
    .PARAMETER LowPrivilege
        Use in low privilege environment were elevation is not allowed. Generates INF certificate request templates.
    .INPUTS
        Inputs (if any)
    .OUTPUTS
        Output (if any)
    .LINK
        Generate Azure Stack Certificate Requests - https://aka.ms/AzsCSR
        Azure Stack Readiness Checker Tool - https://aka.ms/AzsReadinessChecker
    .NOTES
        General notes
    #>
    [CmdletBinding(DefaultParameterSetName = 'Manual')]
    param (
        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = "Enter Azure Stack Hub Region Name")]
        [string]$RegionName,

        [Parameter(Mandatory = $true, ParameterSetName = 'Manual', HelpMessage = "Enter Azure Stack Fully Qualified Domain Name (without region name)")]
        [Alias("FQDN", "ExternalDomainName")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        [string]$ExternalFQDN,

        [Parameter(Mandatory = $true, ParameterSetName = 'Manual', HelpMessage = 'Provide subject name as a string, CN is not required and will be overwritten. E.g. "C=US,ST=Washington,L=Redmond,O=Microsoft,OU=Azure Stack"')]
        [Alias("Subject")]
        [System.Security.Cryptography.X509Certificates.X500DistinguishedName]$DistinguishedName,

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = 'Provide X500DistinguishedNameFlags if The distinguished name has special characteristics. Default UseUTF8Encoding.')]
        [System.Security.Cryptography.X509Certificates.X500DistinguishedNameFlags]$DistinguishedNameFlag = 'UseUTF8Encoding',

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = 'Provide Key Length: 2048, 4096 or 8192')]
        [ValidateSet(2048, 4096, 8192)]
        [int]$KeyLength = 2048,

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = 'Provide Hash Algorithm: SHA256, SHA384 or SHA512')]
        [ValidateSet('SHA256', 'SHA384', 'SHA512')]
        [System.Security.Cryptography.HashAlgorithmName]$HashAlgorithm = 'SHA256',

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = "Optionally provide Extended (Enhanced) Key Usage. By default, certificate config will be used. e.g. @('Client Authentication', 'Server Authentication', @{'Custom Usage' = '1.3.6.1.5.15.7.3.2'})")]
        $EnhancedKeyUsage,

        [Parameter(Mandatory = $true, ParameterSetName = 'ExistingEndpoint', HelpMessage = "Optionally provide an existing stamp endpoint (region.external.fqdn) to clone the certificate attributes to be used to generate the certificate signing request.")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        $StampEndpoint,

        [Parameter(Mandatory = $false, HelpMessage = "Enter Certificate Request generation type ('Single' = Request individual wildcard certificates, 'Multiple' = Request single multi domain wildcard certificates")]
        [ValidateSet('MultipleCSR', 'SingleCSR')]
        [string]$requestType = 'MultipleCSR',

        [Parameter(Mandatory = $true, HelpMessage = "Destination Path for Certificate Request(s)")]
        [ValidateScript( {Test-Path -Path $_ -PathType Container <# should be a valid directory path #>})]
        [string]$OutputRequestPath,

        [Parameter(Mandatory = $false, ParameterSetName = 'ExistingEndpoint', HelpMessage = "Force the use of TLS 1.2, true by default")]
        [bool]$ForceTLS12 = $true,

        [Parameter(Mandatory = $false, HelpMessage = "Directory path for log and report output")]
        [string]$OutputPath = "$ENV:TEMP\AzsReadinessChecker",

        [Parameter(Mandatory = $false, HelpMessage = "Use in low privilege environment were elevation is not allowed. Generates INF certificate request templates.")]
        [switch]$LowPrivilege

    )
    New-AzsCertificateSigningRequest @PSBoundParameters -CertificateType EventHubs
}

function New-AzsHubIoTHubCertificateSigningRequest {
    <#
    .SYNOPSIS
        Generates Certificate Signing Requests for Azure Stack Hub IoTHub Resource Provider Certificates
    .DESCRIPTION
        Calls New-AzsCertificateSigningRequest with neccessary parameters to generate CSR for Azure Stack Hub IoTHub Resource Provider certificates
    .EXAMPLE
        $certificateRequestParams = @{
            'regionName' = 'azurestack'
            'externalFQDN' = 'contoso.com'
            'subject' = "C=US,ST=Washington,L=Redmond,O=Microsoft,OU=Azure Stack"
            'OutputRequestPath' = "$ENV:USERPROFILE\Documents\AzsCertRequests"
        }
        New-AzsHubIoTHubCertificateSigningRequest @certificateRequestParams
        Generates Certificate Signing Requests for Azure Stack Hub IoTHub Resource Provider Certificates
    .EXAMPLE
        New-AzsHubIoTHubCertificateSigningRequest -StampEndpoint portal.azurestack.contoso.com -OutputRequestPath "$ENV:USERPROFILE\Documents\AzsCertRequests"
        Connects to existing endpoint https://portal.azurestack.contoso.com read the current SSL certificate, clones the attributes and creates Certificate Signing Requests with those attributes.
        For use with renewal of soon-to-be expired certs.
    .PARAMETER RegionName
        Specifies the Azure Stack deployment's region name, must be alphanumeric.
    .PARAMETER externalFQDN
        Specifies the Azure Stack deployment's External FQDN, also aliased as ExternalFQDN and FQDN, must be valid DNSHostName
    .PARAMETER DistinguishedName
        Specifies a DistinguishedName to be used on the certificate.  Must be a valid System.Security.Cryptography.X509Certificates.X500DistinguishedName value.
        Common Name (CN) is not required, the appropriate value for the Azure Stack Service will be placed in the Common Name (CN).
        If a Common Name (CN) is given it will be honoured on every certificate request if supplied.
        Also aliased as subject.
    .PARAMETER DistinguishedNameFlag
        Specifies a string for the distinguished name flag to be used in the distinguished name.  UseUTF8Encoding is selected by default. More information on x500DistinguishNameFlags
        can be found at https://aka.ms/dnflags
    .PARAMETER KeyLength
        Defines the length of the public and private key for the certificate request generation. Default is 2048. Valid values 2048, 4096, 8192
    .PARAMETER HashAlgorithm
        Hash Algorithm to be used for the certificate request generation. Default is SHA256. Valid values SHA256, SHA384, SHA512
    .PARAMETER EnhancedKeyUsage
        Extended (Enhanced) Key Usage to be included in the certificate request. Provide the required usage for the target certificate as well as the custom usage in hashtable format.
        e.g. @('Client Authentication','Server Authentication',@{'Custom Usage' = '1.3.6.1.5.7.8.2.1'}) will request Client and Server Auth key usage and the custom usage.
    .PARAMETER RequestType
        Specifies the SAN type of the certificate request. Valid values: MultipleCSR, SingleCSR.
        SingleCSR generates one certificate request for all services (not recommended for production). User will be prompted to confirm use.
        MultipleCSR generates multiple certificate requests, one for each service (strongly recommended in production environments).
    .PARAMETER StampEndpoint
        Provide a dns hostname of an existing stamp endpoint (region.external.fqdn) to clone the certificate attributes to be used to generate the certificate signing request.
    .PARAMETER OutputRequestPath
        Specifies the destination path for certificate request files, directory must already exist.
    .PARAMETER ForceTLS12
        Force the use of TLS 1.2, true by default, set to false to use to system default.
    .PARAMETER LowPrivilege
        Use in low privilege environment were elevation is not allowed. Generates INF certificate request templates.
    .INPUTS
        Inputs (if any)
    .OUTPUTS
        Output (if any)
    .LINK
        Generate Azure Stack Certificate Requests - https://aka.ms/AzsCSR
        Azure Stack Readiness Checker Tool - https://aka.ms/AzsReadinessChecker
    .NOTES
        General notes
    #>
    [CmdletBinding(DefaultParameterSetName = 'Manual')]
    param (
        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = "Enter Azure Stack Hub Region Name")]
        [string]$RegionName,

        [Parameter(Mandatory = $true, ParameterSetName = 'Manual', HelpMessage = "Enter Azure Stack Fully Qualified Domain Name (without region name)")]
        [Alias("FQDN", "ExternalDomainName")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        [string]$ExternalFQDN,

        [Parameter(Mandatory = $true, ParameterSetName = 'Manual', HelpMessage = 'Provide subject name as a string, CN is not required and will be overwritten. E.g. "C=US,ST=Washington,L=Redmond,O=Microsoft,OU=Azure Stack"')]
        [Alias("Subject")]
        [System.Security.Cryptography.X509Certificates.X500DistinguishedName]$DistinguishedName,

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = 'Provide X500DistinguishedNameFlags if The distinguished name has special characteristics. Default UseUTF8Encoding.')]
        [System.Security.Cryptography.X509Certificates.X500DistinguishedNameFlags]$DistinguishedNameFlag = 'UseUTF8Encoding',

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = 'Provide Key Length: 2048, 4096 or 8192')]
        [ValidateSet(2048, 4096, 8192)]
        [int]$KeyLength = 2048,

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = 'Provide Hash Algorithm: SHA256, SHA384 or SHA512')]
        [ValidateSet('SHA256', 'SHA384', 'SHA512')]
        [System.Security.Cryptography.HashAlgorithmName]$HashAlgorithm = 'SHA256',

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = "Optionally provide Extended (Enhanced) Key Usage. By default, certificate config will be used. e.g. @('Client Authentication', 'Server Authentication', @{'Custom Usage' = '1.3.6.1.5.15.7.3.2'})")]
        $EnhancedKeyUsage,

        [Parameter(Mandatory = $true, ParameterSetName = 'ExistingEndpoint', HelpMessage = "Optionally provide an existing stamp endpoint (region.external.fqdn) to clone the certificate attributes to be used to generate the certificate signing request.")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        $StampEndpoint,

        [Parameter(Mandatory = $false, HelpMessage = "Enter Certificate Request generation type ('Single' = Request individual wildcard certificates, 'Multiple' = Request single multi domain wildcard certificates")]
        [ValidateSet('MultipleCSR', 'SingleCSR')]
        [string]$requestType = 'MultipleCSR',

        [Parameter(Mandatory = $true, HelpMessage = "Destination Path for Certificate Request(s)")]
        [ValidateScript( {Test-Path -Path $_ -PathType Container <# should be a valid directory path #>})]
        [string]$OutputRequestPath,

        [Parameter(Mandatory = $false, ParameterSetName = 'ExistingEndpoint', HelpMessage = "Force the use of TLS 1.2, true by default")]
        [bool]$ForceTLS12 = $true,

        [Parameter(Mandatory = $false, HelpMessage = "Directory path for log and report output")]
        [string]$OutputPath = "$ENV:TEMP\AzsReadinessChecker",

        [Parameter(Mandatory = $false, HelpMessage = "Use in low privilege environment were elevation is not allowed. Generates INF certificate request templates.")]
        [switch]$LowPrivilege

    )
    New-AzsCertificateSigningRequest @PSBoundParameters -CertificateType IoTHub
}

function New-AzsHubDBAdapterCertificateSigningRequest {
    <#
    .SYNOPSIS
        Generates Certificate Signing Requests for Azure Stack Hub DBAdapter Resource Provider Certificates
    .DESCRIPTION
        Calls New-AzsCertificateSigningRequest with neccessary parameters to generate CSR for Azure Stack Hub DBAdapter Resource Provider certificates
    .EXAMPLE
        $certificateRequestParams = @{
            'regionName' = 'azurestack'
            'externalFQDN' = 'contoso.com'
            'subject' = "C=US,ST=Washington,L=Redmond,O=Microsoft,OU=Azure Stack"
            'OutputRequestPath' = "$ENV:USERPROFILE\Documents\AzsCertRequests"
        }
        New-AzsHubDBAdapterCertificateSigningRequest @certificateRequestParams
        Generates Certificate Signing Requests for Azure Stack Hub DBAdapter Resource Provider Certificates
    .EXAMPLE
        New-AzsHubDBAdapterCertificateSigningRequest -StampEndpoint portal.azurestack.contoso.com -OutputRequestPath "$ENV:USERPROFILE\Documents\AzsCertRequests"
        Connects to existing endpoint https://portal.azurestack.contoso.com read the current SSL certificate, clones the attributes and creates Certificate Signing Requests with those attributes.
        For use with renewal of soon-to-be expired certs.
    .PARAMETER RegionName
        Specifies the Azure Stack deployment's region name, must be alphanumeric.
    .PARAMETER externalFQDN
        Specifies the Azure Stack deployment's External FQDN, also aliased as ExternalFQDN and FQDN, must be valid DNSHostName
    .PARAMETER DistinguishedName
        Specifies a DistinguishedName to be used on the certificate.  Must be a valid System.Security.Cryptography.X509Certificates.X500DistinguishedName value.
        Common Name (CN) is not required, the appropriate value for the Azure Stack Service will be placed in the Common Name (CN).
        If a Common Name (CN) is given it will be honoured on every certificate request if supplied.
        Also aliased as subject.
    .PARAMETER DistinguishedNameFlag
        Specifies a string for the distinguished name flag to be used in the distinguished name.  UseUTF8Encoding is selected by default. More information on x500DistinguishNameFlags
        can be found at https://aka.ms/dnflags
    .PARAMETER KeyLength
        Defines the length of the public and private key for the certificate request generation. Default is 2048. Valid values 2048, 4096, 8192
    .PARAMETER HashAlgorithm
        Hash Algorithm to be used for the certificate request generation. Default is SHA256. Valid values SHA256, SHA384, SHA512
    .PARAMETER EnhancedKeyUsage
        Extended (Enhanced) Key Usage to be included in the certificate request. Provide the required usage for the target certificate as well as the custom usage in hashtable format.
        e.g. @('Client Authentication','Server Authentication',@{'Custom Usage' = '1.3.6.1.5.7.8.2.1'}) will request Client and Server Auth key usage and the custom usage.
    .PARAMETER RequestType
        Specifies the SAN type of the certificate request. Valid values: MultipleCSR, SingleCSR.
        SingleCSR generates one certificate request for all services (not recommended for production). User will be prompted to confirm use.
        MultipleCSR generates multiple certificate requests, one for each service (strongly recommended in production environments).
    .PARAMETER StampEndpoint
        Provide a dns hostname of an existing stamp endpoint (region.external.fqdn) to clone the certificate attributes to be used to generate the certificate signing request.
    .PARAMETER OutputRequestPath
        Specifies the destination path for certificate request files, directory must already exist.
    .PARAMETER ForceTLS12
        Force the use of TLS 1.2, true by default, set to false to use to system default.
    .PARAMETER LowPrivilege
        Use in low privilege environment were elevation is not allowed. Generates INF certificate request templates.
    .INPUTS
        Inputs (if any)
    .OUTPUTS
        Output (if any)
    .LINK
        Generate Azure Stack Certificate Requests - https://aka.ms/AzsCSR
        Azure Stack Readiness Checker Tool - https://aka.ms/AzsReadinessChecker
    .NOTES
        General notes
    #>
    [CmdletBinding(DefaultParameterSetName = 'Manual')]
    param (
        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = "Enter Azure Stack Hub Region Name")]
        [string]$RegionName,

        [Parameter(Mandatory = $true, ParameterSetName = 'Manual', HelpMessage = "Enter Azure Stack Fully Qualified Domain Name (without region name)")]
        [Alias("FQDN", "ExternalDomainName")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        [string]$ExternalFQDN,

        [Parameter(Mandatory = $true, ParameterSetName = 'Manual', HelpMessage = 'Provide subject name as a string, CN is not required and will be overwritten. E.g. "C=US,ST=Washington,L=Redmond,O=Microsoft,OU=Azure Stack"')]
        [Alias("Subject")]
        [System.Security.Cryptography.X509Certificates.X500DistinguishedName]$DistinguishedName,

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = 'Provide X500DistinguishedNameFlags if The distinguished name has special characteristics. Default UseUTF8Encoding.')]
        [System.Security.Cryptography.X509Certificates.X500DistinguishedNameFlags]$DistinguishedNameFlag = 'UseUTF8Encoding',

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = 'Provide Key Length: 2048, 4096 or 8192')]
        [ValidateSet(2048, 4096, 8192)]
        [int]$KeyLength = 2048,

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = 'Provide Hash Algorithm: SHA256, SHA384 or SHA512')]
        [ValidateSet('SHA256', 'SHA384', 'SHA512')]
        [System.Security.Cryptography.HashAlgorithmName]$HashAlgorithm = 'SHA256',

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = "Optionally provide Extended (Enhanced) Key Usage. By default, certificate config will be used. e.g. @('Client Authentication', 'Server Authentication', @{'Custom Usage' = '1.3.6.1.5.15.7.3.2'})")]
        $EnhancedKeyUsage,

        [Parameter(Mandatory = $true, ParameterSetName = 'ExistingEndpoint', HelpMessage = "Optionally provide an existing stamp endpoint (region.external.fqdn) to clone the certificate attributes to be used to generate the certificate signing request.")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        $StampEndpoint,

        [Parameter(Mandatory = $false, HelpMessage = "Enter Certificate Request generation type ('Single' = Request individual wildcard certificates, 'Multiple' = Request single multi domain wildcard certificates")]
        [ValidateSet('MultipleCSR', 'SingleCSR')]
        [string]$requestType = 'MultipleCSR',

        [Parameter(Mandatory = $true, HelpMessage = "Destination Path for Certificate Request(s)")]
        [ValidateScript( {Test-Path -Path $_ -PathType Container <# should be a valid directory path #>})]
        [string]$OutputRequestPath,

        [Parameter(Mandatory = $false, ParameterSetName = 'ExistingEndpoint', HelpMessage = "Force the use of TLS 1.2, true by default")]
        [bool]$ForceTLS12 = $true,

        [Parameter(Mandatory = $false, HelpMessage = "Directory path for log and report output")]
        [string]$OutputPath = "$ENV:TEMP\AzsReadinessChecker",

        [Parameter(Mandatory = $false, HelpMessage = "Use in low privilege environment were elevation is not allowed. Generates INF certificate request templates.")]
        [switch]$LowPrivilege

    )
    New-AzsCertificateSigningRequest @PSBoundParameters -CertificateType DBAdapter
}

function New-AzsHubDataBoxEdgeCertificateSigningRequest {
    <#
    .SYNOPSIS
        Generates Certificate Signing Requests for Azure Stack Hub Databox Edge Resource Provider Certificates
    .DESCRIPTION
        Calls New-AzsCertificateSigningRequest with neccessary parameters to generate CSR for Azure Stack Hub DBAdapter Resource Provider certificates
    .EXAMPLE
        $certificateRequestParams = @{
            'regionName' = 'azurestack'
            'externalFQDN' = 'contoso.com'
            'subject' = "C=US,ST=Washington,L=Redmond,O=Microsoft,OU=Azure Stack"
            'OutputRequestPath' = "$ENV:USERPROFILE\Documents\AzsCertRequests"
        }
        New-AzsHubDataBoxEdgeCertificateSigningRequest @certificateRequestParams
        Generates Certificate Signing Requests for Azure Stack Hub Databox Edge Resource Provider Certificates
    .EXAMPLE
        New-AzsHubDataBoxEdgeCertificateSigningRequest -StampEndpoint portal.azurestack.contoso.com -OutputRequestPath "$ENV:USERPROFILE\Documents\AzsCertRequests"
        Connects to existing endpoint https://portal.azurestack.contoso.com read the current SSL certificate, clones the attributes and creates Certificate Signing Requests with those attributes.
        For use with renewal of soon-to-be expired certs.
    .PARAMETER RegionName
        Specifies the Azure Stack deployment's region name, must be alphanumeric.
    .PARAMETER externalFQDN
        Specifies the Azure Stack deployment's External FQDN, also aliased as ExternalFQDN and FQDN, must be valid DNSHostName
    .PARAMETER DistinguishedName
        Specifies a DistinguishedName to be used on the certificate.  Must be a valid System.Security.Cryptography.X509Certificates.X500DistinguishedName value.
        Common Name (CN) is not required, the appropriate value for the Azure Stack Service will be placed in the Common Name (CN).
        If a Common Name (CN) is given it will be honoured on every certificate request if supplied.
        Also aliased as subject.
    .PARAMETER DistinguishedNameFlag
        Specifies a string for the distinguished name flag to be used in the distinguished name.  UseUTF8Encoding is selected by default. More information on x500DistinguishNameFlags
        can be found at https://aka.ms/dnflags
    .PARAMETER KeyLength
        Defines the length of the public and private key for the certificate request generation. Default is 2048. Valid values 2048, 4096, 8192
    .PARAMETER HashAlgorithm
        Hash Algorithm to be used for the certificate request generation. Default is SHA256. Valid values SHA256, SHA384, SHA512
    .PARAMETER EnhancedKeyUsage
        Extended (Enhanced) Key Usage to be included in the certificate request. Provide the required usage for the target certificate as well as the custom usage in hashtable format.
        e.g. @('Client Authentication','Server Authentication',@{'Custom Usage' = '1.3.6.1.5.7.8.2.1'}) will request Client and Server Auth key usage and the custom usage.
    .PARAMETER RequestType
        Specifies the SAN type of the certificate request. Valid values: MultipleCSR, SingleCSR.
        SingleCSR generates one certificate request for all services (not recommended for production). User will be prompted to confirm use.
        MultipleCSR generates multiple certificate requests, one for each service (strongly recommended in production environments).
    .PARAMETER StampEndpoint
        Provide a dns hostname of an existing stamp endpoint (region.external.fqdn) to clone the certificate attributes to be used to generate the certificate signing request.
    .PARAMETER OutputRequestPath
        Specifies the destination path for certificate request files, directory must already exist.
    .PARAMETER ForceTLS12
        Force the use of TLS 1.2, true by default, set to false to use to system default.
    .PARAMETER LowPrivilege
        Use in low privilege environment were elevation is not allowed. Generates INF certificate request templates.
    .INPUTS
        Inputs (if any)
    .OUTPUTS
        Output (if any)
    .LINK
        Generate Azure Stack Certificate Requests - https://aka.ms/AzsCSR
        Azure Stack Readiness Checker Tool - https://aka.ms/AzsReadinessChecker
    .NOTES
        General notes
    #>
    [CmdletBinding(DefaultParameterSetName = 'Manual')]
    param (
        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = "Enter Azure Stack Hub Region Name")]
        [string]$RegionName,

        [Parameter(Mandatory = $true, ParameterSetName = 'Manual', HelpMessage = "Enter Azure Stack Fully Qualified Domain Name (without region name)")]
        [Alias("FQDN", "ExternalDomainName")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        [string]$ExternalFQDN,

        [Parameter(Mandatory = $true, ParameterSetName = 'Manual', HelpMessage = 'Provide subject name as a string, CN is not required and will be overwritten. E.g. "C=US,ST=Washington,L=Redmond,O=Microsoft,OU=Azure Stack"')]
        [Alias("Subject")]
        [System.Security.Cryptography.X509Certificates.X500DistinguishedName]$DistinguishedName,

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = 'Provide X500DistinguishedNameFlags if The distinguished name has special characteristics. Default UseUTF8Encoding.')]
        [System.Security.Cryptography.X509Certificates.X500DistinguishedNameFlags]$DistinguishedNameFlag = 'UseUTF8Encoding',

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = 'Provide Key Length: 2048, 4096 or 8192')]
        [ValidateSet(2048, 4096, 8192)]
        [int]$KeyLength = 2048,

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = 'Provide Hash Algorithm: SHA256, SHA384 or SHA512')]
        [ValidateSet('SHA256', 'SHA384', 'SHA512')]
        [System.Security.Cryptography.HashAlgorithmName]$HashAlgorithm = 'SHA256',

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = "Optionally provide Extended (Enhanced) Key Usage. By default, certificate config will be used. e.g. @('Client Authentication', 'Server Authentication', @{'Custom Usage' = '1.3.6.1.5.15.7.3.2'})")]
        $EnhancedKeyUsage,

        [Parameter(Mandatory = $true, ParameterSetName = 'ExistingEndpoint', HelpMessage = "Optionally provide an existing stamp endpoint (region.external.fqdn) to clone the certificate attributes to be used to generate the certificate signing request.")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        $StampEndpoint,

        [Parameter(Mandatory = $false, HelpMessage = "Enter Certificate Request generation type ('Single' = Request individual wildcard certificates, 'Multiple' = Request single multi domain wildcard certificates")]
        [ValidateSet('MultipleCSR', 'SingleCSR')]
        [string]$requestType = 'MultipleCSR',

        [Parameter(Mandatory = $true, HelpMessage = "Destination Path for Certificate Request(s)")]
        [ValidateScript( {Test-Path -Path $_ -PathType Container <# should be a valid directory path #>})]
        [string]$OutputRequestPath,

        [Parameter(Mandatory = $false, ParameterSetName = 'ExistingEndpoint', HelpMessage = "Force the use of TLS 1.2, true by default")]
        [bool]$ForceTLS12 = $true,

        [Parameter(Mandatory = $false, HelpMessage = "Directory path for log and report output")]
        [string]$OutputPath = "$ENV:TEMP\AzsReadinessChecker",

        [Parameter(Mandatory = $false, HelpMessage = "Use in low privilege environment were elevation is not allowed. Generates INF certificate request templates.")]
        [switch]$LowPrivilege

    )
    New-AzsCertificateSigningRequest @PSBoundParameters -CertificateType DataBoxEdge
}

function New-AzsHubAzureContainerRegistryCertificateSigningRequest {
    <#
    .SYNOPSIS
        Generates Certificate Signing Requests for Azure Stack Hub Azure Container Registry Resource Provider Certificates
    .DESCRIPTION
        Calls New-AzsCertificateSigningRequest with neccessary parameters to generate CSR for Azure Stack Hub Azure Container Registry Resource Provider certificates
    .EXAMPLE
        $certificateRequestParams = @{
            'regionName' = 'azurestack'
            'externalFQDN' = 'contoso.com'
            'subject' = "C=US,ST=Washington,L=Redmond,O=Microsoft,OU=Azure Stack"
            'OutputRequestPath' = "$ENV:USERPROFILE\Documents\AzsCertRequests"
        }
        New-AzsHubAzureContainerRegistryCertificateSigningRequest @certificateRequestParams
        Generates Certificate Signing Requests for Azure Stack Hub Azure Container Registry Resource Provider Certificates
    .EXAMPLE
        New-AzsHubAzureContainerRegistryCertificateSigningRequest -StampEndpoint azurestack.contoso.com -OutputRequestPath "$ENV:USERPROFILE\Documents\AzsCertRequests"
        Connects to existing endpoint read the current SSL certificate, clones the attributes and creates Certificate Signing Requests with those attributes.
        For use with renewal of soon-to-be expired certs.
    .PARAMETER RegionName
        Specifies the Azure Stack deployment's region name, must be alphanumeric.
    .PARAMETER externalFQDN
        Specifies the Azure Stack deployment's External FQDN, also aliased as ExternalFQDN and FQDN, must be valid DNSHostName
    .PARAMETER DistinguishedName
        Specifies a DistinguishedName to be used on the certificate.  Must be a valid System.Security.Cryptography.X509Certificates.X500DistinguishedName value.
        Common Name (CN) is not required, the appropriate value for the Azure Stack Service will be placed in the Common Name (CN).
        If a Common Name (CN) is given it will be honoured on every certificate request if supplied.
        Also aliased as subject.
    .PARAMETER DistinguishedNameFlag
        Specifies a string for the distinguished name flag to be used in the distinguished name.  UseUTF8Encoding is selected by default. More information on x500DistinguishNameFlags
        can be found at https://aka.ms/dnflags
    .PARAMETER KeyLength
        Defines the length of the public and private key for the certificate request generation. Default is 2048. Valid values 2048, 4096, 8192
    .PARAMETER HashAlgorithm
        Hash Algorithm to be used for the certificate request generation. Default is SHA256. Valid values SHA256, SHA384, SHA512
    .PARAMETER EnhancedKeyUsage
        Extended (Enhanced) Key Usage to be included in the certificate request. Provide the required usage for the target certificate as well as the custom usage in hashtable format.
        e.g. @('Client Authentication','Server Authentication',@{'Custom Usage' = '1.3.6.1.5.7.8.2.1'}) will request Client and Server Auth key usage and the custom usage.
    .PARAMETER RequestType
        Specifies the SAN type of the certificate request. Valid values: MultipleCSR, SingleCSR.
        SingleCSR generates one certificate request for all services (not recommended for production). User will be prompted to confirm use.
        MultipleCSR generates multiple certificate requests, one for each service (strongly recommended in production environments).
    .PARAMETER StampEndpoint
        Provide a dns hostname of an existing stamp endpoint (region.external.fqdn) to clone the certificate attributes to be used to generate the certificate signing request.
    .PARAMETER OutputRequestPath
        Specifies the destination path for certificate request files, directory must already exist.
    .PARAMETER ForceTLS12
        Force the use of TLS 1.2, true by default, set to false to use to system default.
    .PARAMETER LowPrivilege
        Use in low privilege environment were elevation is not allowed. Generates INF certificate request templates.
    .INPUTS
        Inputs (if any)
    .OUTPUTS
        Output (if any)
    .LINK
        Generate Azure Stack Certificate Requests - https://aka.ms/AzsCSR
        Azure Stack Readiness Checker Tool - https://aka.ms/AzsReadinessChecker
    .NOTES
        General notes
    #>
    [CmdletBinding(DefaultParameterSetName = 'Manual')]
    param (
        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = "Enter Azure Stack Hub Region Name")]
        [string]$RegionName,

        [Parameter(Mandatory = $true, ParameterSetName = 'Manual', HelpMessage = "Enter Azure Stack Fully Qualified Domain Name (without region name)")]
        [Alias("FQDN", "ExternalDomainName")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        [string]$ExternalFQDN,

        [Parameter(Mandatory = $true, ParameterSetName = 'Manual', HelpMessage = 'Provide subject name as a string, CN is not required and will be overwritten. E.g. "C=US,ST=Washington,L=Redmond,O=Microsoft,OU=Azure Stack"')]
        [Alias("Subject")]
        [System.Security.Cryptography.X509Certificates.X500DistinguishedName]$DistinguishedName,

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = 'Provide X500DistinguishedNameFlags if The distinguished name has special characteristics. Default UseUTF8Encoding.')]
        [System.Security.Cryptography.X509Certificates.X500DistinguishedNameFlags]$DistinguishedNameFlag = 'UseUTF8Encoding',

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = 'Provide Key Length: 2048, 4096 or 8192')]
        [ValidateSet(2048, 4096, 8192)]
        [int]$KeyLength = 2048,

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = 'Provide Hash Algorithm: SHA256, SHA384 or SHA512')]
        [ValidateSet('SHA256', 'SHA384', 'SHA512')]
        [System.Security.Cryptography.HashAlgorithmName]$HashAlgorithm = 'SHA256',

        [Parameter(Mandatory = $false, ParameterSetName = 'Manual', HelpMessage = "Optionally provide Extended (Enhanced) Key Usage. By default, certificate config will be used. e.g. @('Client Authentication', 'Server Authentication', @{'Custom Usage' = '1.3.6.1.5.15.7.3.2'})")]
        $EnhancedKeyUsage,

        [Parameter(Mandatory = $true, ParameterSetName = 'ExistingEndpoint', HelpMessage = "Optionally provide an existing stamp endpoint (region.external.fqdn) to clone the certificate attributes to be used to generate the certificate signing request.")]
        [ValidateScript( {[System.Uri]::CheckHostName($_) -eq 'dns' <#FQDN must be valid DNSHostName#>})]
        $StampEndpoint,

        [Parameter(Mandatory = $false, HelpMessage = "Enter Certificate Request generation type ('Single' = Request individual wildcard certificates, 'Multiple' = Request single multi domain wildcard certificates")]
        [ValidateSet('MultipleCSR', 'SingleCSR')]
        [string]$requestType = 'MultipleCSR',

        [Parameter(Mandatory = $true, HelpMessage = "Destination Path for Certificate Request(s)")]
        [ValidateScript( {Test-Path -Path $_ -PathType Container <# should be a valid directory path #>})]
        [string]$OutputRequestPath,

        [Parameter(Mandatory = $false, ParameterSetName = 'ExistingEndpoint', HelpMessage = "Force the use of TLS 1.2, true by default")]
        [bool]$ForceTLS12 = $true,

        [Parameter(Mandatory = $false, HelpMessage = "Directory path for log and report output")]
        [string]$OutputPath = "$ENV:TEMP\AzsReadinessChecker",

        [Parameter(Mandatory = $false, HelpMessage = "Use in low privilege environment were elevation is not allowed. Generates INF certificate request templates.")]
        [switch]$LowPrivilege

    )
    New-AzsCertificateSigningRequest @PSBoundParameters -CertificateType ACR
}

function Get-AzsCSRParameters {
    <#
    .SYNOPSIS
        Get CSR parameters from existing endpoint.
    .DESCRIPTION
        Get CSR parameters from existing endpoint.
    .EXAMPLE
        PS C:\>  Get-AzsCSRParameters -StampEndpoint management.east.azurestack.contoso.com
        Explanation of what the example does
    .INPUTS
        Uri - System.Uri
    .OUTPUTS
        Hashtable
    .NOTES
        General notes
    #>
    param ([System.Uri]$StampEndpoint,$OutputRequestPath,$OutputPath)

    Write-AzsReadinessLog -Message ("Querying StampEndpoint {0} for existing certificate" -f $StampEndpoint) -Type Info -ToScreen
    if (Resolve-DnsName -Name $StampEndpoint -ErrorAction SilentlyContinue -QuickTimeout) {
        #try and retrieve certificate inventory from SSL endpoint
        try {
            foreach ($port in 443,44300) {
                try {
                    $Timeout = 1000
                    $tcpClient = New-Object System.Net.Sockets.TcpClient
                    $portOpened = $tcpClient.ConnectAsync($StampEndpoint.OriginalString, $port).Wait($Timeout)
                    if ($portOpened) {
                        #create service connection point to the target SSL endpoint
                        $SSLEndPoint = "https://{0}:{1}" -f $StampEndpoint, $port
                        Write-AzsReadinessLog -Message ("Testing StampEndpoint {0}." -f $SSLEndPoint) -Type Info -ToScreen
                        try {
                            $null = Invoke-WebRequest $SSLEndPoint -TimeoutSec 3 -ErrorAction SilentlyContinue -UseBasicParsing
                        }
                        catch {
                            if ($_.exception.InnerException.Message -like '*The client and server cannot communicate, because they do not possess a common algorithm*') {
                                # this shouldnt happen we force tls1.2 by default, the user can override this and set the protocol settings system-wide or process-wide.
                                throw "TLS mismatch. Ensure the client is using a TLS version that matches the end point.  Using -ForceTLS12 parameter can toggle between TLS1.2 and system settings."
                            }
                            Write-AzsReadinessLog -Message ("Errors are expected. Web request returned: {0}" -f $_.exception.message) -Type Info
                        }

                        # read certificate
                        [System.Security.Cryptography.X509Certificates.X509Certificate2]$certificate = Get-SslCertificateChain -Url $sslEndPoint | Select-Object -last 1

                        # if we were succesfully, break so we dont waste time checking other ports.
                        if ($certificate) { break }
                        else {
                            throw "Unable to read certificate from $SSLEndPoint. Refer to the above in this case."
                        }
                    }
                }
                catch {
                    throw $_.exception.message # allow errors, we only want the certificate from the handshake and will catch a null certificate instead.
                }

            }

            Import-Module $PSScriptRoot\Microsoft.AzureStack.PublicCertificatePackaging.psm1 -force
            $externalFqdn = Get-AzsExternalDomain -dnsNamesFromConfig (Get-AzsCertificateDnsNamesFromConfig) -certificate $Certificate

            # If subject contains a DNSName, remove it to let the tool populate it normally,
            # We don't want to take a single distinguished name throughout all certificates e.g. cn=adminportal on portal certificate etc.
            # If subject does not contain a DNSName, the previous certificate had a custom subject that must be honoured. e.g. CN=Contoso Cloud.
            foreach ($name in $certificate.DnsNameList.Unicode) {
                if ($certificate.SubjectName.Name -like "*CN=$Name*") {
                    $subject = $certificate.SubjectName.Format($true) -split "`n" | Where-Object { $PSITEM -inotmatch 'cn=' -and $PSITEM -ne ""}
                }
                break
            }
            if (-not $subject) {
                $subject = $certificate.SubjectName.Name
                Write-AzsReadinessLog -Message ("Custom subject detected {0}." -f $subject) -Type Info
            }
            else {
                $subject = $subject.replace("`r","") -join ', '
                Write-AzsReadinessLog -Message ("Tool generated subject detected {0}. Removing common name and continuing." -f $subject) -Type Info
            }

            # convert Oid to HashAlgorithm Name
            try {
                [System.Security.Cryptography.HashAlgorithmName]$algorithm = ($certificate.SignatureAlgorithm.FriendlyName | select-string -Pattern 'SHA[0-9]{3}').Matches[0].value
                if (-not $algorithm) {
                    throw $_
                }
            }
            catch {
                $errmsg = ("Unable to convert {0} to type System.Security.Cryptography.HashAlgorithmName Error:{1}" -f $certificate.SignatureAlgorithm.FriendlyName, $_.exception.message)
                Write-AzsReadinessLog -Message $errmsg -Type Error -toScreen
                throw $_.exception.Message
            }

            # construct params needed to request new certificate.
            $params = @{
                DistinguishedName = $subject.ToString()
                ExternalFQDN      = $externalFqdn
                KeyLength         = $certificate.PublicKey.Key.KeySize
                HashAlgorithm     = $algorithm
            }

            # If this is Azure Stack Hub Deployment certificates, get IdentitySystem and add to parameters
            if ((Get-PSCallStack).arguments -match 'CertificateType=Deployment') {
                try {
                    $ADFSRequest = Invoke-WebRequest "https://management.$externalFqdn/metadata/endpoints?api-version=2015-01-01" -UseBasicParsing -ErrorAction SilentlyContinue
                    $loginEndPoint = ($ADFSRequest.Content | ConvertFrom-Json).Authentication.LoginEndpoint
                    if ($loginEndPoint -like '*ADFS*') {
                        $params.Add('IdentitySystem','ADFS')
                        Write-AzsReadinessLog -Message ("ADFS detected. Login endpoint $loginEndPoint") -Type Info
                    }
                    else {
                        Write-AzsReadinessLog -Message ("ADFS not detected. Login endpoint $loginEndPoint") -Type Info
                        $params.Add('IdentitySystem','AAD')
                    }
                }
                catch {
                    Write-AzsReadinessLog -Message ("Checking for ADFS endpoint failed with {0}. Setting identity system to AAD." -f $_.exception.message) -Type Info
                    $params.Add('IdentitySystem','AAD')
                }
            }

            $paramToString = ($params.GetEnumerator() | ForEach-Object { "$($_.Key)=$($_.Value)" }) -join ';'
            Write-AzsReadinessLog -Message ("Found CSR params {0}" -f ($paramToString)) -Type Info
            $params
        }
        catch {
            $ConnectionError = $_.exception.message
            Write-AzsReadinessLog -Message ("Failed to query {0} for existing certificate. Error: {1}" -f $SSLEndPoint,$ConnectionError) -Type Error -ToScreen
            break
        }
    }
    else {
        Write-AzsReadinessLog -Message ("Unable to resolve StampEndpoint {0}. Ensure StampEndpoint can be resolved." -f $StampEndpoint) -Type Error -ToScreen
        break
    }
}

function Get-FixedEndPoints {
    <#
    .SYNOPSIS
        Resolve fixed endpoints to check existing certificates against.
    .DESCRIPTION
        Resolve fixed endpoints to check existing certificates against, first by using FixedEndPoint property of
        certificate configuration, and fall back to dnsname and remove any wildcards.
    #>
    [cmdletbinding()]
    param (
        [ValidateNotNullOrEmpty()]
        $certificateConfig,
        [ValidateNotNullOrEmpty()]
        $stampEndpoint)

    $fixedEndPoints = @()
    $fixedEndPoints = $certificateConfig.Keys | ForEach-Object {`
        if ($certificateConfig[$_].FixedEndPoint) {
            $certificateConfig[$_].FixedEndPoint
        }
        else {
            $certificateConfig[$_].DnsName
        }
    }
    $output = $fixedEndPoints | where-object {$PSITEM -notmatch '\*.'} | Sort-Object -Descending | Foreach-Object {"{0}.{1}" -f $PSITEM, $stampEndpoint}
    Write-AzsReadinessLog -Message ("Resolved fixed endpoints {0}" -f $fixedEndPoints -join ',')
    return $output
}
# SIG # Begin signature block
# MIIjkgYJKoZIhvcNAQcCoIIjgzCCI38CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCQxtFCZ9lWjFgN
# SyiZaGP4R3nWcb23pfwAZSS7oCWPLqCCDYEwggX/MIID56ADAgECAhMzAAACUosz
# qviV8znbAAAAAAJSMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjEwOTAyMTgzMjU5WhcNMjIwOTAxMTgzMjU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDQ5M+Ps/X7BNuv5B/0I6uoDwj0NJOo1KrVQqO7ggRXccklyTrWL4xMShjIou2I
# sbYnF67wXzVAq5Om4oe+LfzSDOzjcb6ms00gBo0OQaqwQ1BijyJ7NvDf80I1fW9O
# L76Kt0Wpc2zrGhzcHdb7upPrvxvSNNUvxK3sgw7YTt31410vpEp8yfBEl/hd8ZzA
# v47DCgJ5j1zm295s1RVZHNp6MoiQFVOECm4AwK2l28i+YER1JO4IplTH44uvzX9o
# RnJHaMvWzZEpozPy4jNO2DDqbcNs4zh7AWMhE1PWFVA+CHI/En5nASvCvLmuR/t8
# q4bc8XR8QIZJQSp+2U6m2ldNAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUNZJaEUGL2Guwt7ZOAu4efEYXedEw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDY3NTk3MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAFkk3
# uSxkTEBh1NtAl7BivIEsAWdgX1qZ+EdZMYbQKasY6IhSLXRMxF1B3OKdR9K/kccp
# kvNcGl8D7YyYS4mhCUMBR+VLrg3f8PUj38A9V5aiY2/Jok7WZFOAmjPRNNGnyeg7
# l0lTiThFqE+2aOs6+heegqAdelGgNJKRHLWRuhGKuLIw5lkgx9Ky+QvZrn/Ddi8u
# TIgWKp+MGG8xY6PBvvjgt9jQShlnPrZ3UY8Bvwy6rynhXBaV0V0TTL0gEx7eh/K1
# o8Miaru6s/7FyqOLeUS4vTHh9TgBL5DtxCYurXbSBVtL1Fj44+Od/6cmC9mmvrti
# yG709Y3Rd3YdJj2f3GJq7Y7KdWq0QYhatKhBeg4fxjhg0yut2g6aM1mxjNPrE48z
# 6HWCNGu9gMK5ZudldRw4a45Z06Aoktof0CqOyTErvq0YjoE4Xpa0+87T/PVUXNqf
# 7Y+qSU7+9LtLQuMYR4w3cSPjuNusvLf9gBnch5RqM7kaDtYWDgLyB42EfsxeMqwK
# WwA+TVi0HrWRqfSx2olbE56hJcEkMjOSKz3sRuupFCX3UroyYf52L+2iVTrda8XW
# esPG62Mnn3T8AuLfzeJFuAbfOSERx7IFZO92UPoXE1uEjL5skl1yTZB3MubgOA4F
# 8KoRNhviFAEST+nG8c8uIsbZeb08SeYQMqjVEmkwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVZzCCFWMCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAlKLM6r4lfM52wAAAAACUjAN
# BglghkgBZQMEAgEFAKCBrjAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgopy4MhYb
# eG9TzWSDBHquxriU9ntIW1XS/tOsZYNhD5swQgYKKwYBBAGCNwIBDDE0MDKgFIAS
# AE0AaQBjAHIAbwBzAG8AZgB0oRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQCya2cxUXIQjEmOgIESYUBLI4ZOtokVYHJfCEIk8wGg
# RKh9bxgzglYQ+FBj5XDJ50c8VXOWpGw9n74KhM+2H+YAbcXQwt4Nax+l6TT2NW2b
# gVrLMTxuhUnIbr6GLv5MNg+o2DGgsLf6GQIDXDjJs6P8LsKiLKnoaTavBAlA7TYv
# Cp1Slxr9BRB/xf9Q9PuVZAk5J4IgV1ENQ6ZueNCI8X1iEIuu8TizNEzZKsIkL3Hn
# QGlOC2OXMpgNf8y7B+YAT1iyadE3zbaNLfmtyrWd98uwph/qVHDW8eRXgy4q84H6
# 5VdfJK4U/11i61IApz+m60wLn4XvXvqJj2EAc3dt3wsyoYIS8TCCEu0GCisGAQQB
# gjcDAwExghLdMIIS2QYJKoZIhvcNAQcCoIISyjCCEsYCAQMxDzANBglghkgBZQME
# AgEFADCCAVUGCyqGSIb3DQEJEAEEoIIBRASCAUAwggE8AgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEIOXkti59NslczGeECAfMgC3DmWtaIkSNM/2rUwD+
# FFxQAgZhvMAePJEYEzIwMjIwMTA1MTIxMTI5LjgxMlowBIACAfSggdSkgdEwgc4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1p
# Y3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMg
# VFNTIEVTTjo0NjJGLUUzMTktM0YyMDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgU2VydmljZaCCDkQwggT1MIID3aADAgECAhMzAAABWHBaIve+luYDAAAA
# AAFYMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MB4XDTIxMDExNDE5MDIxNFoXDTIyMDQxMTE5MDIxNFowgc4xCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVy
# YXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo0NjJG
# LUUzMTktM0YyMDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vydmlj
# ZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKEfC5dg9auw0KAFGwv1
# 7yMFG8SfqgUUFC8Dzwa8mrps0eyhRQ2Nv9K7/sz/fVE1o/1fZp4q4SGitcsjPGtO
# njWx45VIFTINQpdoOhmsPdnFy3gBXpMGtTfXqLnnUE4+VmKC2vAhOZ06U6vt5Cc0
# cJoqEJtzOWRwEaz8BoX2nCX1RBXkH3PiAu7tWJv3V8zhRSPLFmeiJ+CIway04AUg
# mrwXEQHvJHgb6PiLCxgE2VABCDNT5CVyieNapcZiKx16QbDle7KOwkjMEIKkcxR+
# 32dDMtzCtpIUDgrKxmjx+Gm94jHieohOHUuhl3u3hlAYfv2SA/86T1UNAiBQg3Wu
# 9xsCAwEAAaOCARswggEXMB0GA1UdDgQWBBRLcNkbfZ0cGB/u536ge5Mn06L5WDAf
# BgNVHSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBH
# hkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNU
# aW1TdGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUF
# BzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0
# YVBDQV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsG
# AQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IBAQA53ygDWovQrh8fuliNXW0CUBTzfA4S
# l4h+IPEh5lNdrhDFy6T4MA9jup1zzlFkpYrUc0sTfQCAOnAjmunPgnmaS5bSf2VH
# 8Mg34U2qgPLInMAkGaBs/BzabJ65YKe1P5IKZN7Wj2bRfCK03ES8kS7g6YQH67ix
# MCQCLDreWDKJYsNs0chNpJOAzyJeGfyRUe+TUUbFwjsC/18KmYODVgpRSYZx0W7j
# rGqlJVEehuwpSIsGOYCBMnJDNdKnP+13Cg68cVtCNX6kJdvUFH0ZiuPMlBYD7GrC
# PqARlSn+vxffMivu2DMJJLkeywxSfD52sDV+NBf5IniuKFcE9y0m9m2jMIIGcTCC
# BFmgAwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJv
# b3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1WhcN
# MjUwNzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCASIw
# DQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkdDbx3EYo6IOz8E5f1+n9plGt0
# VBDVpQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMnBDEfQRsalR3OCROOfGEwWbEw
# RA/xYIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeGMoQe
# dGFnkV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8RsEnHSRnEnIaIYqvS2SJUGKx
# Xf13Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v0Ev9buWayrGo8noqCjHw2k4G
# kbaICDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN/LzAyURdXhacAQVPIk0CAwEA
# AaOCAeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ80N7
# fEYbxTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMC
# AYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvX
# zpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20v
# cGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYI
# KwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDCBoAYDVR0g
# AQH/BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYIKwYB
# BQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0AGUA
# bQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAAfmiFEN4sbgmD+BcQM9naOh
# IW+z66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4vceoniXj+bzta1RXCCtRgkQS
# +7lTjMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzymXlK
# kVIArzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8z+0DpZaPWSm8tv0E4XCfMkon
# /VWvL/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVKC5Em4jnsGUpxY517IW3DnKOi
# PPp/fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs9/S/
# fmNZJQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF0M2n0O99g/DhO3EJ3110mCII
# YdqwUB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+YWtvd6mBy6cJrDm77MbL2IK0
# cs0d9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt6o3gMy4SKfXAL1QnIffIrE7a
# KLixqduWsqdCosnPGUFN4Ib5KpqjEWYw07t0MkvfY3v1mYovG8chr1m1rtxEPJdQ
# cdeh0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc1bN+
# NR4Iuto229Nfj950iEkSoYIC0jCCAjsCAQEwgfyhgdSkgdEwgc4xCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBP
# cGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo0
# NjJGLUUzMTktM0YyMDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZaIjCgEBMAcGBSsOAwIaAxUAqckrcxrn0Qshpuozjp+l+DSfNL+ggYMwgYCk
# fjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIF
# AOV/ohcwIhgPMjAyMjAxMDUwODUwMzFaGA8yMDIyMDEwNjA4NTAzMVowdzA9Bgor
# BgEEAYRZCgQBMS8wLTAKAgUA5X+iFwIBADAKAgEAAgIozQIB/zAHAgEAAgIQ+DAK
# AgUA5YDzlwIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIB
# AAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBABPx/4Ut/29gApwX
# AEsyAczNHLqVvQIEvvWC8kB5G7ERyH/ibiL1Zfls6d/lDBFa9/4vq93dBYdAs6El
# D9zpbnFXpIYntiFyaNi+3LtXM7psgxVDi4FenVfFPBEPU0mjGgwKVRkoCdV0PFG6
# pbBq3bKnHnFKBFvOaRzQu+beHM04MYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTACEzMAAAFYcFoi976W5gMAAAAAAVgwDQYJYIZIAWUD
# BAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0B
# CQQxIgQgoRik/UuTp0PJpXutupUBMZaiLxTYFcYErcK7N6VkWNUwgfoGCyqGSIb3
# DQEJEAIvMYHqMIHnMIHkMIG9BCDySjONbIY1l2zKT4ba4sCI4WkBC6sIfR9uSVNV
# x3DTBzCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB
# WHBaIve+luYDAAAAAAFYMCIEIBv89EWWazbb5AonEHGKNrqdJ9lMThx1cmuw09Wn
# 5x5QMA0GCSqGSIb3DQEBCwUABIIBAJyY4IIv+kXRVoMrE0EhQdZF06gr5VCA2vWZ
# k2u7Wk2XgPVfBTglNHnFJ8xKpkVpFYloxTXdt5/PR1VYOX3lFJtQXeouIo56DXMX
# o4kZ1BTOv4ZQdoHoyMUtJnXOAX6X1u60DLbHdF2xUj6DAp87LLZc+WtBd0OtLoet
# kjbAy0ZcukGIZROM14t4/+1Tz4RvHjY3aNO9vZ3OEAI0+xb0AJwexBvTRrX7alCK
# uGF12kJiMdfsLwpGaBf/YD2GtUSZTlPRUIIScwg6Yiiz4rIV5wAnlD7fn2HLjKW5
# IJaK8SM6QPOKVZWIufO/UqELekyARO3kIhnctZAgUQ7YK2XdcF0=
# SIG # End signature block
