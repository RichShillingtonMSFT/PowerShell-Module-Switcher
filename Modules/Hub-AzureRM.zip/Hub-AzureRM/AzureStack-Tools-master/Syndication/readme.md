# Offline Marketplace Syndication

The Syndication tool is now available as a module on the PowerShell Gallery. Please refer to [the official documenation](https://docs.microsoft.com/en-us/azure-stack/operator/azure-stack-download-azure-marketplace-item?view=azs-2002&pivots=state-disconnected) on how to download marketplace items for Azure Stack Hub.

