# Azure Stack Portal User Data Clear scripts
Please refer to https://aka.ms/azsportalclear for more information.
