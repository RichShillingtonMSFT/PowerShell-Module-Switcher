---
Module Name: AzureRM.BootStrapper
Module Guid: 30d8a5cf-3ee5-49ce-b9b0-a4d000d65161
Download Help Link: {{Please enter FwLink manually}}
Help Version: {{Please enter version of help manually (X.X.X.X) format}}
Locale: en-US
---

# AzureRM.BootStrapper Module
## Description
{{Manually Enter Description Here}}

## AzureRM.BootStrapper Cmdlets
### [Get-AzureRmModule](Get-AzureRmModule.md)
{{Manually Enter Get-AzureRmModule Description Here}}

### [Get-AzureRmProfile](Get-AzureRmProfile.md)
{{Manually Enter Get-AzureRmProfile Description Here}}

### [Get-ModuleVersion](Get-ModuleVersion.md)
{{Manually Enter Get-ModuleVersion Description Here}}

### [Install-AzureRmProfile](Install-AzureRmProfile.md)
{{Manually Enter Install-AzureRmProfile Description Here}}

### [Remove-AzureRmDefaultProfile](Remove-AzureRmDefaultProfile.md)
{{Manually Enter Remove-AzureRmDefaultProfile Description Here}}

### [Set-AzureRmDefaultProfile](Set-AzureRmDefaultProfile.md)
{{Manually Enter Set-AzureRmDefaultProfile Description Here}}

### [Set-BootstrapRepo](Set-BootstrapRepo.md)
{{Manually Enter Set-BootstrapRepo Description Here}}

### [Uninstall-AzureRmProfile](Uninstall-AzureRmProfile.md)
{{Manually Enter Uninstall-AzureRmProfile Description Here}}

### [Update-AzureRmProfile](Update-AzureRmProfile.md)
{{Manually Enter Update-AzureRmProfile Description Here}}

### [Use-AzureRmProfile](Use-AzureRmProfile.md)
{{Manually Enter Use-AzureRmProfile Description Here}}

