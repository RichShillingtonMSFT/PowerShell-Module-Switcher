Import-Module -Name AzureRM.Bootstrapper
$RollupModule = 'AzureRM'
InModuleScope AzureRM.Bootstrapper {
    $ProfileMap = (Get-AzProfile)
    $ProfileCachePath = Get-ProfileCachePath

    # Helper function to uninstall all profiles
    function Remove-InstalledProfile {
        $installedProfiles = Get-ProfilesInstalled -ProfileMap $ProfileMap
        if ($installedProfiles.Keys -ne $null)
        {
            foreach ($profile in $installedProfiles.Keys)
            {
                Write-Host "Removing profile $profile"
                Uninstall-AzureRmProfile -Profile $profile -Force -ErrorAction SilentlyContinue
            }
            
            $profiles = (Get-ProfilesInstalled -ProfileMap $ProfileMap)
            if ($profiles.Count -ne 0)
            {
                Throw "Uninstallation was not successful: Profile(s) $(@($profiles.Keys) -join ',') were not uninstalled correctly."
            }
        }
    }

    Describe "A machine with no profile installed can install profile" {

        # Using Install-AzureRmProfile
        Context "New Profile Install - Latest" {
            # Arrange
            # Uninstall previously installed profiles
            Remove-InstalledProfile       

            # Launch the test in a new powershell session
            # Create a new PS session
            $session = New-PSSession

            # Act
            # Install latest version
            Invoke-Command -Session $session -ScriptBlock { Install-AzureRmProfile -Profile 'Latest' -Force } 

            # Assert 
            It "Should return Latest Profile" {
                $result = Invoke-Command -Session $session -ScriptBlock { Get-AzureRmProfile } 
                $result[0].Contains('Latest') | Should Be $true
            }

            # Clean up
            Remove-PSSession -Session $session
        } 

        # Using Use-AzureRmProfile
        Context "New Profile Install - 2016-04-consistent" {
            # Arrange
            # Uninstall previously installed profiles
            Remove-InstalledProfile

            # Create a new PS session
            $session = New-PSSession

            # Act
            # Install profile '2016-04-consistent'
            Invoke-Command -Session $session -ScriptBlock { Use-AzureRmProfile -Profile '2016-04-consistent' -Force }

            # Assert
            It "Should return 2016-04-consistent" {
                $result = Invoke-Command -Session $session -ScriptBlock { Get-AzureRmProfile } 
                $result[0].Contains('2016-04-consistent') | Should Be $true
            }

            # Clean up
            Remove-PSSession -Session $session
        }
    }

    Describe "Add: A Machine with a Profile installed can install latest profile" {
        InModuleScope AzureRM.Bootstrapper {

            Context "Profile 2016-04-consistent already installed" {
                # Arrange
                # Create a new PS session
                $session = New-PSSession

                # Ensure 2016-09-consistent is installed
                $profilesInstalled = Invoke-Command -Session $session -ScriptBlock { Get-AzureRmProfile } 
                $profilesInstalled[0].Contains('2016-04-consistent') | Should Be $true

                # Act
                # Install profile 'Latest'
                Invoke-Command -Session $session -ScriptBlock { Use-AzureRmProfile -Profile 'Latest' -Force }
                $result = Invoke-Command -Session $session -ScriptBlock { Get-AzureRmProfile }

                # Assert
                It "Should return 2016-09-consistent & Latest" {
                    ($result -like "*latest*") -ne $null | Should Be $true 
                    ($result -like "*2016-04-consistent*") -ne $null | Should Be $true
                }

                # Clean up
                Remove-PSSession -Session $session
            }
        }
    }

    Describe "Attempting to use already installed profile will import the modules to the current session" {
        InModuleScope AzureRM.Bootstrapper {
            Context "Profile Latest is installed" {
                # Should import Latest profile to current session
                # Arrange
                # Create a new PS session
                $session = New-PSSession

                # Ensure profile Latest is installed
                $profilesInstalled = Invoke-Command -Session $session -ScriptBlock { Get-AzureRmProfile } 
                ($profilesInstalled -like "*latest*") -ne $null | Should Be $true

                # Act
                Invoke-Command -Session $session -ScriptBlock { Use-AzureRmProfile -Profile 'Latest' -Force }

                # Get the version of the Latest profile
                $ProfileMap = Get-AzProfile
                $latestVersion = $ProfileMap.'Latest'.$RollupModule

                # Assert
                It "Should return AzureRm module Latest version" {
                    # Get-module script block
                    $getModule = {
                        Param($RollupModule)
                        Get-Module -Name $RollupModule 
                    }

                    $modules = Invoke-Command -Session $session -ScriptBlock $getModule -ArgumentList $RollupModule
                
                    $modules.Name | Should Be $RollupModule
                    $modules.version | Should Be $latestVersion
                }

                # Cleanup
                Invoke-Command -Session $session -ScriptBlock { Uninstall-AzureRmProfile -Profile 'Latest' -Force -ea SilentlyContinue }
                Remove-PSSession -Session $session
            }
        }
    }

    Describe "User can update their machine to a latest profile" {
        InModuleScope AzureRM.Bootstrapper {
            # Using Use-AzureRmProfile
            Context "Profile 2016-09-consistent is installed: Use-AzureRmProfile" {
                # Should refresh profile map from Azure end point and update modules.
                # Arrange
                # Create a new PS session
                $session = New-PSSession

                # Check if '2016-04-consistent' is installed
                $profilesInstalled = Invoke-Command -Session $session -ScriptBlock { Get-AzureRmProfile } 
                ($profilesInstalled -like "*2016-04-consistent*") -ne $null | Should Be $true

                # Remove latest profile map from cache for testing if it updates from online.
                $latestMap = Get-LatestProfileMapPath
                if (($latestMap -ne $null) -and (Test-Path $latestMap.FullName))
                {
                    Remove-Item -Path $latestMap.FullName -Force
                }
                
                # Act
                Invoke-Command -Session $session -ScriptBlock { Get-AzureRmProfile -Update }
                Invoke-Command -Session $session -ScriptBlock { Use-AzureRmProfile -Profile 'Latest' -Force }
        
                # Assert
                It "Should return 2016-04-consistent & Latest" {
                    $result = Invoke-Command -Session $session -ScriptBlock { Get-AzureRmProfile }
                    ($result -like "*latest*") -ne $null | Should Be $true 
                    ($result -like "*2016-04-consistent*") -ne $null | Should Be $true
                }

                It "Latest version of modules are imported" {
                    # Get the version of the Latest profile
                    $ProfileMap = Get-AzProfile
                    $latestVersion = $ProfileMap.'Latest'.$RollupModule
                
                    # Get-module script block
                    $getModule = {
                        Param($RollupModule)
                        Get-Module -Name $RollupModule 
                    }

                    $modules = Invoke-Command -Session $session -ScriptBlock $getModule -ArgumentList $RollupModule
                
                    # Are latest modules imported?
                    $modules.Name | Should Be $RollupModule
                    $modules.version | Should Be $latestVersion
                }
            
                It "Last Write Time should be less than 5 minutes" {
                    # Get LastWriteTime for ProfileMap
                    $lastWriteTime = (Get-Item -Path (Get-LatestProfileMapPath).FullName).LastWriteTime
                    (((Get-Date) - $lastWriteTime).TotalMinutes -lt 5) | Should Be $true
                }

                # Cleanup
                Remove-PSSession -Session $session
            }
        
            # Using Update-AzureRmProfile; Previous Versions do not exist
            Context "Profile 2016-04-consistent is installed: Update-AzureRmProfile" {
                # Arrange
                # Remove existing profiles
                Remove-InstalledProfile

                # Create a new PS session
                $session = New-PSSession

                # Install profile 2016-04-consistent
                Install-AzureRmProfile -Profile '2016-04-consistent' -Force

                # Ensure profile 2016-04-consistent is installed
                $profilesInstalled = Invoke-Command -Session $session -ScriptBlock { Get-AzureRmProfile } 
                ($profilesInstalled -like "*2016-04-consistent*") -ne $null | Should Be $true

                # Act
                # Update to profile 'Latest'
                Invoke-Command -Session $session -ScriptBlock { Update-AzureRmProfile -Profile 'Latest' -Force -RemovePreviousVersions }

                # Assert
                # Returns 2016-04-consistent & Latest
                It "Should Return 2016-04-consistent & Latest" {
                    $result = Invoke-Command -Session $session -ScriptBlock { Get-AzureRmProfile }
                    ($result -like "*latest*") -ne $null | Should Be $true 
                    ($result -like "*2016-04-consistent*") -ne $null | Should Be $true
                }

                It "Latest version of modules are imported" {
                    # Get the version of the Latest profile
                    $ProfileMap = Get-AzProfile
                    $latestVersion = $ProfileMap.'Latest'.$RollupModule
                
                    # Get-module script block
                    $getModule = {
                        Param($RollupModule)
                        Get-Module -Name $RollupModule 
                    }

                    $modules = Invoke-Command -Session $session -ScriptBlock $getModule -ArgumentList $RollupModule
                
                    # Are latest modules imported?
                    $modules.Name | Should Be $RollupModule
                    $modules.version | Should Be $latestVersion
                }

                Remove-PSSession -Session $session
            }
            
            # Using Update-AzureRmProfile; Previous Versions exist
            Context "Profile 2016-04-consistent is installed: Update-AzureRmProfile with PreviousVerisons" {
                # Arrange
                # Remove existing profiles
                Remove-InstalledProfile
    
                # Create a new PS session
                $session = New-PSSession

                # Install profile 2016-04-consistent
                Install-AzureRmProfile -Profile '2016-04-consistent' -Force

                # Ensure profile 2016-04-consistent is installed
                $profilesInstalled = Invoke-Command -Session $session -ScriptBlock { Get-AzureRmProfile } 
                ($profilesInstalled -like "*2016-04-consistent*") -ne $null | Should Be $true

                # Remove latest profile map from cache for testing if it updates from online.
                $latestMap = Get-LatestProfileMapPath
                if (($latestMap -ne $null) -and (Test-Path $latestMap.FullName))
                {
                    Remove-Item -Path $latestMap.FullName -Force
                }

                # Add a version of old profilemap with older versions of 'latest' profile to cache
                $testProfileMap = "{`"Latest`": { `"AzureRM`": [`"3.3.0`"], `"Azure.Storage`": [`"2.4.0`"] }}" 
                $testProfileMap | Out-File -FilePath "$ProfileCachePath\TestMap.json" -Force

                # Install the modules from that profilemap
                $testProfileMap = ($testProfileMap | ConvertFrom-Json)
                
                foreach ($Module in ($testProfileMap.'Latest' | Get-Member -MemberType NoteProperty).Name)
                {
                    $oldVersion = $testProfileMap.'Latest'.$Module
                    Install-Module $Module -RequiredVersion $oldVersion[0] -ErrorAction Stop -AllowClobber
                }

                # Act
                # Invoke Update-AzureRmProfile 'latest' with -RemovePreviousVersions
                Invoke-Command -Session $session -ScriptBlock { Get-AzureRmProfile -update }
                Invoke-Command -Session $session -ScriptBlock { Update-AzureRmProfile -Profile 'Latest' -Force -RemovePreviousVersions }

                # Assert
                # Check if new versions of 'latest' are installed
                $latestVersion = $ProfileMap.'Latest'.$RollupModule

                It "Should return latest module versions" {
                    # Get-module script block
                    $getModule = {
                        Param($RollupModule)
                        Get-AzureRmModule -Profile 'Latest' -Module $RollupModule 
                    }
                
                    $version = Invoke-Command -Session $session -ScriptBlock $getModule -ArgumentList $RollupModule
                    $version | Should Be $latestVersion
                }

                # Check if old versions of 'latest' are uninstalled
                It "Should return null for old versions" {
                    # Get-module script block
                    $getModule = {
                        Param($RollupModule)
                        Get-Module -Name $RollupModule -ListAvailable
                    }

                    $modules = Invoke-Command -Session $session -ScriptBlock $getModule -ArgumentList $RollupModule
                    foreach ($module in $modules)
                    {
                        $module.Version -eq $oldVersion | Should Be $false
                    }
                }

                # Check if the old profilemap was removed
                It "Should return false for old profile map in cache" {
                    (Test-Path "$ProfileCachePath\TestMap.json") | Should Be $false
                }
            }
        }
    }

    Describe "User can uninstall a profile" {
        InModuleScope AzureRM.Bootstrapper {
            Context "Latest profile is installed" {
                # Should uninstall latest profile
                # Arrange
                # Create a new PS session
                $session = New-PSSession

                # Check if 'Latest' is installed
                $profilesInstalled = Invoke-Command -Session $session -ScriptBlock { Get-AzureRmProfile } 
                ($profilesInstalled -like "*latest*") -ne $null | Should Be $true

                # Get the version of the Latest profile
                $ProfileMap = Get-AzProfile
                $latestVersion = $ProfileMap.'Latest'.$RollupModule

                # Act
                Invoke-Command -Session $session -ScriptBlock { Uninstall-AzureRmProfile -Profile 'Latest' -Force }
            
                # Assert
                It "Profile Latest is uninstalled" {
                    $result = Invoke-Command -Session $session -ScriptBlock { Get-AzureRmProfile }
                    if($result -ne $null)
                    {
                        $result.Contains('Latest') | Should Be $false
                    }
                    else {
                        $true
                    }
                }

                It "Available Modules should not contain uninstalled modules" {
                    $getModule = {
                        Param($RollupModule)
                        Get-Module -Name $RollupModule -ListAvailable
                    }
                    $results = Invoke-Command -Session $session -ScriptBlock $getModule -ArgumentList $RollupModule
                    
                    # Result won't be null because profile 2016-04-consistent is installed.
                    foreach ($result in $results)
                    {
                        $result.Version -eq $latestVersion | Should Be $false
                    }
                        
                }

                # Cleanup
                Remove-PSSession -Session $session
            }
        }
    }

    Describe "Install Two named profiles and selecting each" {
        InModuleScope AzureRM.Bootstrapper {
            # Get the version of the respective profile
            $ProfileMap = Get-AzProfile
            $Version1 = $ProfileMap.'Latest'.$RollupModule
            $Version2 = $ProfileMap.'2016-04-consistent'.$RollupModule

            Context "Install Two Profiles" {
                # Arrange
                # Remove all profiles
                Remove-InstalledProfile

                # Create a new PS session
                $session = New-PSSession

                # Act
                # Install Profile: 2016-08 
                Invoke-Command -Session $session -ScriptBlock { Install-AzureRmProfile -Profile 'Latest' -Force } 

                # Install Profile: 2016-04
                Invoke-Command -Session $session -ScriptBlock { Install-AzureRmProfile -Profile '2016-04-consistent' -Force } 

                # Assert 
                It "Should return Profiles Latest & 2016-04-consistent" {
                $profilesInstalled = Invoke-Command -Session $session -ScriptBlock { Get-AzureRmProfile } 
                ($profilesInstalled -like "*2016-04-consistent*") -ne $null | Should Be $true
                ($profilesInstalled -like "*latest*") -ne $null | Should Be $true
            }

                # Clean up
                Remove-PSSession -Session $session        
            }

            Context "Select diff profiles" {
                # Arrange
                # Create two new PS sessions
                $session1 = New-PSSession
                $session2 = New-PSSession

                # Act
                # Use-AzureRmProfile will import the respective versions of modules in the session
                Invoke-Command -Session $session1 -ScriptBlock { Use-AzureRmProfile -Profile 'Latest' -Force }
                Invoke-Command -Session $session2 -ScriptBlock { Use-AzureRmProfile -Profile '2016-04-consistent' -Force } 
    
                $getModule = {
                    Param($RollupModule)
                    Get-Module -Name $RollupModule
                }

                $result = Invoke-Command -Session $session1 -ScriptBlock { Get-AzureRmProfile }
                $module1 = Invoke-Command -Session $session1 -ScriptBlock $getModule -ArgumentList $RollupModule
                $module2 = Invoke-Command -Session $session2 -ScriptBlock $getModule -ArgumentList $RollupModule

                # Assert
                It "Should return Latest & 2016-04-consistent" {
                    ($result -like "*latest*") -ne $null | Should Be $true 
                    ($result -like "*2016-04-consistent*") -ne $null | Should Be $true
                }

                It "Respective versions of modules are imported" {
                    # Are respective modules imported?
                    $module1.Name | Should Be $RollupModule
                    $module1.version | Should Be $Version1

                    $module2.Name | Should Be $RollupModule
                    $module2.version | Should Be $Version2
                }

                # "Uninstall All Profiles" 
                Remove-InstalledProfile

                It "Should return null" {
                    Get-AzureRmProfile | Should Be $null
                }

                It "Modules should return null" {
                    $getModuleList = {
                        Param($RollupModule)
                        Get-Module -ListAvailable -Name $RollupModule
                    }

                    $result1 = Invoke-Command -Session $session1 -ScriptBlock $getModuleList  -ArgumentList $RollupModule
                    foreach ($result in $result1)
                    {
                        $result.Version -eq $Version1 | Should Be $false
                    }
                    $result2 = Invoke-Command -Session $session2 -ScriptBlock $getModuleList  -ArgumentList $RollupModule
                    foreach ($result in $result2)
                    {
                        $result.Version -eq $Version2 | Should Be $false
                    }
                }

                # Cleanup
                Remove-PSSession -Session $session1
                Remove-PSSession -Session $session2
            }
        }
    }

    Describe "Invalid Cases" {
        Context "Install wrong profile name" {
            # Install profile 'abcTest'
            It "Throws Invalid argument error" {
                { Install-AzureRmProfile -Profile 'abcTest' } | Should Throw
            }
        }

        Context "Install null profile name" {
            # Install profile 'null'
            It "Throws Invalid argument error" {
                { Install-AzureRmProfile -Profile $null } | Should Throw
            }
        }

        Context "Install already installed profile" {
            # Arrange
            # Create a new PS session
            $session = New-PSSession

            # Ensure profile 2016-09 is installed
            Install-AzureRmProfile -Profile '2016-04-consistent' -Force
            $installedProfile = Invoke-Command -Session $session -ScriptBlock { Get-AzureRmProfile }
            ($installedProfile -like "*2016-04-consistent*") -ne $null | Should Be $true
            
            # Act
            # Install profile '2016-04-consistent'
            $result = Invoke-Command -Session $session -ScriptBlock { Install-AzureRmProfile -Profile '2016-04-consistent' -Force } 

            # Get modules imported into the session
            $getModuleList = {
                    Param($RollupModule)
                    Get-Module -Name $RollupModule
                }
            $modules = Invoke-Command -Session $session -ScriptBlock $getModuleList  -ArgumentList $RollupModule

            It "Doesn't install/import the profile" {
                $result | Should Be $null
                $modules | Should Be $null
            }

            # Cleanup
            Remove-PSSession -Session $session
        }

        Context "Uninstall not installed profile" {
            # Arrange
            # Create a new PS session
            $session = New-PSSession

            # Ensure profile latest is not installed
            $installedProfile = Invoke-Command -Session $session -ScriptBlock { Get-AzureRmProfile }
            ($installedProfile -like "*latest*") | Should Be $null

            # Act
            # Uninstall profile 'latest'
            $result = Invoke-Command -Session $session -ScriptBlock { Uninstall-AzureRmProfile -Profile 'latest' -Force} 

            It "Doesn't uninstall/throw" {
                $result | Should Be $null
            }

            # Cleanup
            Remove-PSSession -Session $session
        }

        Context "Use-AzureRmProfile with wrong profile name" {
            # Install profile 'abcTest'
            It "Throws Invalid argument error" {
                { Use-AzureRmProfile -Profile 'abcTest' } | Should Throw
            }
        }
    }

    Describe "Failure Recovery: Attempt to install profile recovers from error" {
        InModuleScope AzureRM.Bootstrapper {
            Context "Azure ProfileMap endpoint threw exception" {
                # Arrange
                # Mock Get-ProfileMap returns error
                Mock Get-AzureProfileMap -Verifiable { throw [System.Net.WebException] }
            
                # Mock Install-Modules returns error
                Mock Install-Module -Verifiable { throw }
                Mock Get-AzureRmModule -Verifiable {}

                # Act & Assert
                It "Should not download/install the latest profile" {
                    { Get-AzureRmProfile -Update } | Should Throw
                    { Install-AzureRmProfile -Profile 'Latest' -Force } | Should Throw
                }

                It "Last Write time should not be less than 3 mins" {
                    # Get LastWriteTime for ProfileMap
                    $lastWriteTime = (Get-Item -Path (Get-LatestProfileMapPath).FullName).LastWriteTime
                    (((Get-Date) - $lastWriteTime).TotalMinutes -gt 3) | Should Be $true
                    Assert-VerifiableMock
                }
            }

            Context "Retry install after ProfileMap update" {
                # Arrange
                # Create a new PS session
                $session = New-PSSession

                # Remove ProfileMap.json to test if it is updated from online
                Remove-Item -Path (Get-LatestProfileMapPath).FullName -Force

                # Act
                # Update ProfileMap
                Invoke-Command -Session $session -ScriptBlock { Get-AzureRmProfile -Update }

                # Install profile 'Latest'
                Invoke-Command -Session $session -ScriptBlock { Use-AzureRmProfile -Profile 'Latest' -Force } 

                # Assert
                It "Installs & Imports Latest profile to the session" {
                    $getModuleList = {
                        Param($RollupModule)
                        Get-Module -Name $RollupModule
                    }
                    $modules = Invoke-Command -Session $session -ScriptBlock $getModuleList  -ArgumentList $RollupModule

                    # Get the version of the Latest profile
                    $ProfileMap = Get-AzProfile
                    $latestVersion = $ProfileMap.'Latest'.$RollupModule
                
                    # Are latest modules imported?
                    $modules.Name | Should Be $RollupModule
                    $modules.version | Should Be $latestVersion
                }

                It "Last Write time should be less than 5 mins" {
                    # Get LastWriteTime for ProfileMap
                    $lastWriteTime = (Get-Item -Path (Get-LatestProfileMapPath).FullName).LastWriteTime
                    (((Get-Date) - $lastWriteTime).TotalMinutes -lt 5) | Should Be $true
                }

                # Cleanup
                Remove-PSSession -Session $session
            }
        }
    }

    Describe "Install profiles using Scope" {
        InModuleScope AzureRM.Bootstrapper {

            Context "Using Install-AzureRmProfile: Scope 'CurrentUser'" {
                # Arrange
                # Create a new PS session
                $session = New-PSSession

                # Remove installed profiles
                Remove-InstalledProfile 

                # Act
                # Install profile Latest scope as current user
                Invoke-Command -Session $session -ScriptBlock { Install-AzureRmProfile -Profile 'Latest' -scope 'CurrentUser' -Force }

                # Assert
                It "Installs & Imports Latest profile to the session" {
                    # Get the version of the Latest profile
                    $ProfileMap = Get-AzProfile
                    $latestVersion = $ProfileMap.'Latest'.$RollupModule
                    
                    $getModuleList = {
                        Param($RollupModule, $latestVersion)
                        Get-Module -Name $RollupModule -ListAvailable | Where-Object {$_.Version -like $latestVersion}
                    }
                    $modules = Invoke-Command -Session $session -ScriptBlock $getModuleList  -ArgumentList @($RollupModule, $latestVersion)

                    # Are latest modules imported?
                    $modules.Name | Should Be $RollupModule
                    $modules.version | Should Be $latestVersion
                }
            }

            Context "Using Use-AzureRmProfile: Scope 'AllUsers'" {
                # Arrange
                # Create a new PS session
                $session = New-PSSession

                # Remove installed profiles
                Remove-InstalledProfile 

                # Act
                # Install profile 2016-04-consistent scope as all users
                Invoke-Command -Session $session -ScriptBlock { Use-AzureRmProfile -Profile '2016-04-consistent' -scope 'AllUsers' -Force }

                # Assert
                It "Installs & Imports 2016-04-consistent profile to the session" {
                    $getModuleList = {
                        Param($RollupModule)
                        Get-Module -Name $RollupModule
                    }
                    $modules = Invoke-Command -Session $session -ScriptBlock $getModuleList  -ArgumentList $RollupModule

                    # Get the version of the 2016-04-consistent profile
                    $ProfileMap = Get-AzProfile
                    $version = $ProfileMap.'2016-04-consistent'.$RollupModule
                
                    # Are appropriate modules imported?
                    $modules.Name | Should Be $RollupModule
                    $modules.version | Should Be $version
                }
            }

            Context "Using Update-AzureRmProfile: Scope 'CurrentUser' " {
                # Arrange
                # Create a new PS session
                $session = New-PSSession

                # Remove installed profiles
                Remove-InstalledProfile 

                # Act
                # Install profile 2016-04-consistent scope as current user
                Invoke-Command -Session $session -ScriptBlock { Update-AzureRmProfile -Profile '2016-04-consistent' -scope 'CurrentUser' -Force -r }

                # Assert
                It "Installs & Imports 2016-04-consistent profile to the session" {
                    $getModuleList = {
                        Param($RollupModule)
                        Get-Module -Name $RollupModule
                    }
                    $modules = Invoke-Command -Session $session -ScriptBlock $getModuleList  -ArgumentList $RollupModule

                    # Get the version of the 2016-04-consistent profile
                    $ProfileMap = Get-AzProfile
                    $version = $ProfileMap.'2016-04-consistent'.$RollupModule
                
                    # Are correct modules imported?
                    $modules.Name | Should Be $RollupModule
                    $modules.version | Should Be $version
                }
            }
        }
    }

    Describe "Load/Import AzureRmProfile modules" {
        InModuleScope AzureRM.Bootstrapper {
        Context "Using Use-AzureRmProfile: Modules are not installed" {
                # Arrange
                # Create a new PS session
                $session = New-PSSession

                # Remove installed profiles
                Remove-InstalledProfile 

                # Act
                # Use module from Latest profile scope as current user
                Invoke-Command -Session $session -ScriptBlock { Use-AzureRmProfile -Profile '2016-04-consistent' -Module 'AzureRM.Storage' -Force -scope 'CurrentUser'}

                # Assert
                $RollupModule = 'AzureRM.Storage'
                It "Installs & Imports 2016-04-consistent profile's module to the session" {
                    $getModuleList = {
                        Param($RollupModule)
                        Get-Module -Name $RollupModule
                    }
                    $modules = Invoke-Command -Session $session -ScriptBlock $getModuleList  -ArgumentList $RollupModule

                    # Get the version of the 2016-04-consistent profile
                    $ProfileMap = Get-AzProfile
                    $version = $ProfileMap.'2016-04-consistent'.$RollupModule
                
                    # Are 2016-04-consistent modules imported?
                    $modules.Name | Should Be $RollupModule
                    $modules.version | Should Be $version
                }
            }

            Context "Using Update-AzureRmProfile: Previous version of modules are installed" {
                # Arrange
                # Create a new PS session
                $session = New-PSSession

                # Remove installed profiles
                Remove-InstalledProfile 

                # Remove latest profile map from cache for testing if it updates from online.
                $latestMap = Get-LatestProfileMapPath
                if (($latestMap -ne $null) -and (Test-Path $latestMap.FullName))
                {
                    Remove-Item -Path $latestMap.FullName -Force
                }

                # Add a version of old profilemap with older versions of 'latest' profile to cache
                $testProfileMap = "{`"Latest`": {`"Azure.Storage`": [`"2.4.0`"], `"AzureRM.Storage`": [`"2.4.0`"] }}" 
                $testProfileMap | Out-File -FilePath "$ProfileCachePath\TestMap.json" -Force

                # Install the modules from that profilemap
                $testProfileMap = ($testProfileMap | ConvertFrom-Json)
                
                foreach ($Module in ($testProfileMap.'Latest' | Get-Member -MemberType NoteProperty).Name)
                {
                    $oldVersion = $testProfileMap.'Latest'.$Module
                    Install-Module $Module -RequiredVersion $oldVersion[0] -ErrorAction Stop -AllowClobber
                }

                # Act
                # Update profile Latest with -RemovePreviousVersions
                Invoke-Command -Session $session -ScriptBlock { Get-AzureRmProfile -Update }
                Invoke-Command -Session $session -ScriptBlock { Update-AzureRmProfile -Profile 'Latest' -Module 'AzureRM.Storage', 'Azure.Storage' -Force -r }

                # Assert
                It "Installs & Imports latest profile's module ('AzureRM.Storage') to the session" {
                    $getModuleList = {
                        Param($RollupModule)
                        Get-Module -Name $RollupModule
                    }
                    $module1 = Invoke-Command -Session $session -ScriptBlock $getModuleList  -ArgumentList 'AzureRM.Storage'

                    # Get the version of the latest profile
                    $ProfileMap = Get-AzProfile
                    $version1 = $ProfileMap.'Latest'.'AzureRM.Storage'
                    
                    # Are latest modules imported?
                    $module1.Name | Should Be 'AzureRM.Storage'
                    $module1.version | Should Be $version1
                }

                It "Installs & Imports latest profile's module ('Azure.Storage') to the session" {
                    $getModuleList = {
                        Param($RollupModule)
                        Get-Module -Name $RollupModule
                    }
                    $module2 = Invoke-Command -Session $session -ScriptBlock $getModuleList  -ArgumentList 'Azure.Storage'

                    # Get the version of the latest profile
                    $ProfileMap = Get-AzProfile
                    $version2 = $ProfileMap.'Latest'.'Azure.Storage'
                
                    # Are latest modules imported?
                    $module2.Name | Should Be 'Azure.Storage'
                    $module2.version | Should Be $version2
                }

                # Check if the old profilemap was removed
                It "Should return false for old profile map in cache" {
                    (Test-Path "$ProfileCachePath\TestMap.json") | Should Be $false
                }
            }
        }
    }
}
# SIG # Begin signature block
# MIIjkQYJKoZIhvcNAQcCoIIjgjCCI34CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDNgqXRq8XBton7
# tzI2Ng/2Oe4ItNJaidYj9hkaghjgDaCCDYEwggX/MIID56ADAgECAhMzAAABh3IX
# chVZQMcJAAAAAAGHMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAwMzA0MTgzOTQ3WhcNMjEwMzAzMTgzOTQ3WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOt8kLc7P3T7MKIhouYHewMFmnq8Ayu7FOhZCQabVwBp2VS4WyB2Qe4TQBT8aB
# znANDEPjHKNdPT8Xz5cNali6XHefS8i/WXtF0vSsP8NEv6mBHuA2p1fw2wB/F0dH
# sJ3GfZ5c0sPJjklsiYqPw59xJ54kM91IOgiO2OUzjNAljPibjCWfH7UzQ1TPHc4d
# weils8GEIrbBRb7IWwiObL12jWT4Yh71NQgvJ9Fn6+UhD9x2uk3dLj84vwt1NuFQ
# itKJxIV0fVsRNR3abQVOLqpDugbr0SzNL6o8xzOHL5OXiGGwg6ekiXA1/2XXY7yV
# Fc39tledDtZjSjNbex1zzwSXAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUhov4ZyO96axkJdMjpzu2zVXOJcsw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDU4Mzg1MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAixmy
# S6E6vprWD9KFNIB9G5zyMuIjZAOuUJ1EK/Vlg6Fb3ZHXjjUwATKIcXbFuFC6Wr4K
# NrU4DY/sBVqmab5AC/je3bpUpjtxpEyqUqtPc30wEg/rO9vmKmqKoLPT37svc2NV
# BmGNl+85qO4fV/w7Cx7J0Bbqk19KcRNdjt6eKoTnTPHBHlVHQIHZpMxacbFOAkJr
# qAVkYZdz7ikNXTxV+GRb36tC4ByMNxE2DF7vFdvaiZP0CVZ5ByJ2gAhXMdK9+usx
# zVk913qKde1OAuWdv+rndqkAIm8fUlRnr4saSCg7cIbUwCCf116wUJ7EuJDg0vHe
# yhnCeHnBbyH3RZkHEi2ofmfgnFISJZDdMAeVZGVOh20Jp50XBzqokpPzeZ6zc1/g
# yILNyiVgE+RPkjnUQshd1f1PMgn3tns2Cz7bJiVUaqEO3n9qRFgy5JuLae6UweGf
# AeOo3dgLZxikKzYs3hDMaEtJq8IP71cX7QXe6lnMmXU/Hdfz2p897Zd+kU+vZvKI
# 3cwLfuVQgK2RZ2z+Kc3K3dRPz2rXycK5XCuRZmvGab/WbrZiC7wJQapgBodltMI5
# GMdFrBg9IeF7/rP4EqVQXeKtevTlZXjpuNhhjuR+2DMt/dWufjXpiW91bo3aH6Ea
# jOALXmoxgltCp1K7hrS6gmsvj94cLRf50QQ4U8Qwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVZjCCFWICAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAYdyF3IVWUDHCQAAAAABhzAN
# BglghkgBZQMEAgEFAKCBrjAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgdFBhnoZH
# rnGh7JhumqHnQZ8SoCsSzy+HttIaELq6g2AwQgYKKwYBBAGCNwIBDDE0MDKgFIAS
# AE0AaQBjAHIAbwBzAG8AZgB0oRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQAtSX93iBx0J5Nx0DiWEX2SmMq516YoXXDLYl6eRo3l
# QpT20tWEXd6gR6+XxstoAQK4RcenBseJm62mYJqwLzzOCaVrauKPgmQBRV6NlOzQ
# dSQdQ4Q+KZjuzcW+tKoFbhDyVKuCi2Y+O/Ufs06lmx5wM1gpyiNx1dhoDbjMPR0A
# MYLNmPEX97mAGKtyiSDfhlujCILDeoD3IHT5Qpoudrtl5equIrMBVZyG0tkr+/Op
# SFKyWiNdvIAxv2BqruFoTG/34WRDEnn1hM9T1mYTE6mwHVxLAGDb1Li3Yvdj2uoV
# nn48go5qZYOVE9MRY8u8Uvwj+lTih2+kUpw2KVeoYEGJoYIS8DCCEuwGCisGAQQB
# gjcDAwExghLcMIIS2AYJKoZIhvcNAQcCoIISyTCCEsUCAQMxDzANBglghkgBZQME
# AgEFADCCAVQGCyqGSIb3DQEJEAEEoIIBQwSCAT8wggE7AgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEICHyVX5qvueZW+0Qn2F9r3dtl88km7uRFNe9/27q
# jOcXAgZf25fi1XcYEjIwMjEwMTE0MjIwMzM1Ljk4WjAEgAIB9KCB1KSB0TCBzjEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWlj
# cm9zb2Z0IE9wZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBU
# U1MgRVNOOkY4N0EtRTM3NC1EN0I5MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1T
# dGFtcCBTZXJ2aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAEvsacXeVaUF4cAAAAA
# AS8wDQYJKoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAw
# HhcNMTkxMjE5MDExNTA2WhcNMjEwMzE3MDExNTA2WjCBzjELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJh
# dGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY4N0Et
# RTM3NC1EN0I5MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqHxWS9UjBcPyyfTNPacR
# 3IRn1Q0djsAJs5kDihsAe8PWFq7D0rVnaVFYb6bwCuz2Xfkagxd0+CyEzeFkpBZ+
# GsucX38YNmiKWFzYuEyo09ezTqsAnxg4MHqLQKDUIUJifI5i/LBcpjfEYk3T0OA9
# dZ9zMSbY/9reuatcysrkQVzdqHGsLnVz5S4AwpX3EnLMlUtKE/A8EmX4KN0wM8l/
# bgNlchh5zeAI3bF5qfUMUIjSBqommsx4vg6bUpjYBkwiAE8SShjU3sAjl7vJuQgv
# z4zPeKeKNvisNOReTzrO1TDLht1zUzIp7aPah1P5AgMDb4zxwxMgaUqfsTIPY01d
# TwIDAQABo4IBGzCCARcwHQYDVR0OBBYEFKaX9VGkE0WQAwOKpyipaLzmP+qWMB8G
# A1UdIwQYMBaAFNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeG
# RWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Rp
# bVN0YVBDQV8yMDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUH
# MAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3Rh
# UENBXzIwMTAtMDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYB
# BQUHAwgwDQYJKoZIhvcNAQELBQADggEBAHirqKW/ZKUa8kP/t1t+ggpkE7aLpgDB
# yTDntOkKu3b5IDHZ1wXsm9EwI+EsJKCqPI1wlGzjRwRc9st3NkwkfNy/vcAXsvqZ
# ZleDZoGMbVJzmoziOMT+fAhf4Lr+h2bn9qxTgkiUUK5RmPOp2KvXweRFVC97YfBX
# SUJcdCz5Xeb0PLID1votIiTcY4Vm7sXXVbLH/l1VeKw89M/CH0ld8wP1bXvczX5l
# nJyY7TeVRzgbUWKWCnFY12Baf8M71mGhbnI3r4FR12cnhwJwKNyDywHmuS08/ylV
# kBDtpSqQB6qj4W4KQBQB0lERIKlHnCBI+1W8U8yM40TfoNsq1/OR+IcwggZxMIIE
# WaADAgECAgphCYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9v
# dCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0y
# NTA3MDEyMTQ2NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjAN
# BgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RU
# ENWlCgCChfvtfGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBE
# D/FgiIRUQwzXTbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50
# YWeRX4FUsc+TTJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd
# /XcfPfBXday9ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaR
# togINeh4HLDpmc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQAB
# o4IB5jCCAeIwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8
# RhvFM2hahW1VMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIB
# hjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fO
# mhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9w
# a2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggr
# BgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNv
# bS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSAB
# Af8EgZUwgZIwgY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEF
# BQcCAjA0HjIgHQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBt
# AGUAbgB0AC4gHTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Eh
# b7Prpsz1Mb7PBeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7
# uVOMzPRgEop2zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqR
# UgCvOA8X9S95gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9
# Va8v/rbljjO7Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8
# +n99lmqQeKZt0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+
# Y1klD3ouOVd2onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh
# 2rBQHm+98eEA3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRy
# zR30uIUBHoD7G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoo
# uLGp25ayp0Kiyc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx
# 16HSxVXjad5XwdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341
# Hgi62jbb01+P3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY4
# N0EtRTM3NC1EN0I5MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloiMKAQEwBwYFKw4DAhoDFQAz8JkJSlyVD2p+v+vfL2iwgg9KZKCBgzCBgKR+
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA
# 46r/bzAiGA8yMDIxMDExNDIxMzU0M1oYDzIwMjEwMTE1MjEzNTQzWjB3MD0GCisG
# AQQBhFkKBAExLzAtMAoCBQDjqv9vAgEAMAoCAQACAiOHAgH/MAcCAQACAhDyMAoC
# BQDjrFDvAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEA
# AgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAZp1FWkcgUxvIdTdy
# ZuRYBlPZH8ytRbJSLpo6l2wajoT4F4Ob8fp0vTIWakmyAHFXTJ3eSd9aFbd78NYf
# PeJtTnIA4x5TQ8Kc1mIKSOT9ju1811DNeoF7j0cn8GynKH+7s9ss6AiLYBDTtyUb
# zIKAaRcUT4o/bIOyXZ3aorb60I0xggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGlt
# ZS1TdGFtcCBQQ0EgMjAxMAITMwAAAS+xpxd5VpQXhwAAAAABLzANBglghkgBZQME
# AgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJ
# BDEiBCCcvM9TvkEnxxacdD6aGmk6Bp55vrxRFPet8L97+uZJjDCB+gYLKoZIhvcN
# AQkQAi8xgeowgecwgeQwgb0EIELlF5wZm+6Ce9VeDzTOWsa/W5Xfks2T4f10GPcK
# EU+9MIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAEv
# sacXeVaUF4cAAAAAAS8wIgQgmJkX16oLBzQ7MMblYwo5WZ5NH3rSlJo53JYjYsE0
# boEwDQYJKoZIhvcNAQELBQAEggEAgmDiYf/Wjv+rHV5NVoaHAzQoDrZEkr0MTVnl
# vj8wIcgAvvRlS7STqyl3yEA6airlMl1kG5JL4fnv252d5qxc+pOkIbYUjk8Wti/g
# 0KpVO7ZZYRRu1apMhYIxQMUKFfSQUclaQTGpb6JfKaOoIR+V94RSbULMDXMGMNP+
# xCCeI/7IgN/nvR61jGjlqvCnKTfVb9gR96VhlhSpyoIh19QJAxvVUre70wtAGdit
# 2NgFpyCCAjT4A30NYHvZBy6fuXgUBIMqyhve3d2KhbrmaoXBa773rN05JT/wowMT
# UjGTSioF13b0/1L7d/zo2f1P/82prVhiDgxWn0YyrN0B2nQjuw==
# SIG # End signature block
